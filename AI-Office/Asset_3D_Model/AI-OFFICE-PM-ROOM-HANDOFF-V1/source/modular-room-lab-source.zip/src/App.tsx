import React, { useCallback, useRef, useState } from 'react';
import {
  Camera,
  ChevronDown,
  ChevronUp,
  Compass,
  Download,
  Focus,
  Maximize2,
  MessageSquare,
  PanelRightClose,
  PanelRightOpen,
  RotateCcw,
  RotateCw,
  Upload,
  UserCheck,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  CAMERA_PRESETS,
  MODULE_CONSTANTS,
  RoomExportStats,
} from './domain/modularRoomSpec';
import {
  ActivityAnchor,
  AnchorId,
  DEFAULT_ACTIVITY_ANCHORS,
  GLBInspectionReport,
  PMActionId,
  PM_DEMO_ACTIONS,
} from './domain/pmSimulationSpec';
import {
  ClickedMeshDiagnostic,
  ModularRoomCanvas,
  ModularRoomCanvasHandle,
  PMSimulationRuntimeTelemetry,
  SelectedObjectInspection,
  ViewerDisplayConfig,
  VisualStabilityDiagnosticReport,
} from './components/ModularRoomCanvas';
import { InspectorTabId, RoomInspectorPanel } from './components/RoomInspectorPanel';
import { ImportValidationReport } from './three/RoomExportAndImportManager';
import {
  IndependentRoundTripReportV1,
  downloadRoundTripReportJson,
} from './export/AssetValidation';
import { downloadRoomAssetPackZip, downloadRoomManifestAndAnchors } from './export/RoomExporter';
import {
  downloadCharacterAssetPackZip,
  downloadCharacterManifestAndBehavior,
} from './export/CharacterExporter';
import {
  downloadCompleteHandoffBundleZip,
  downloadModularRoomLabSourceZip,
  getBundledSourceFileList,
} from './export/BrowserSourceBundle';

export function App() {
  const canvasRef = useRef<ModularRoomCanvasHandle | null>(null);
  const topGlbInputRef = useRef<HTMLInputElement | null>(null);

  const [config, setConfig] = useState<ViewerDisplayConfig>({
    workspaceMode: 'builder',
    reimportDisplayMode: 'both_reimported',
    visualStyle: 'reference',
    showGrid: false,
    autoCutawayWalls: true,
    showWallsAndWindows: true,
    showFurniture: true,
    showPropsAndDecor: true,
    showMannequin: false,
    showTextures: true,
    showShadows: true,
    showWireframe: false,
    showNeighborAssembly: false,
    showBossPM: true,
    showSimulationAnchors: false,
    showNavigationPath: true,
    followPMCamera: false,
    selectedCatalogId: null,
    isolatedCatalogId: null,
    hiddenCatalogIds: [],
  });

  const [inspectorTab, setInspectorTab] = useState<InspectorTabId>('simulation');
  const [activePresetId, setActivePresetId] = useState<string>('isometric');
  const [stats, setStats] = useState<RoomExportStats | null>(null);
  const [selectedDetails, setSelectedDetails] = useState<SelectedObjectInspection | null>(null);
  const [importReport, setImportReport] = useState<ImportValidationReport | null>(null);
  const [roundTripReport, setRoundTripReport] = useState<IndependentRoundTripReportV1 | null>(null);
  const [glbInspectionReport, setGlbInspectionReport] = useState<GLBInspectionReport | null>(null);
  const [clickedMeshDiagnostic, setClickedMeshDiagnostic] = useState<ClickedMeshDiagnostic | null>(
    null
  );
  const [stabilityReport, setStabilityReport] = useState<VisualStabilityDiagnosticReport | null>(
    null
  );
  const [anchors, setAnchors] = useState<Record<AnchorId, ActivityAnchor>>(() => ({
    ...DEFAULT_ACTIVITY_ANCHORS,
  }));
  const [selectedAnchorId, setSelectedAnchorId] = useState<AnchorId | null>('PM_DESK_WORK_POSITION');
  const [bubbleDismissedForAction, setBubbleDismissedForAction] = useState<PMActionId | null>(null);

  const [telemetry, setTelemetry] = useState<PMSimulationRuntimeTelemetry>({
    loaded: true,
    loadError: null,
    selectedCharacterSource: 'original_pm',
    activeCharacterSource: 'original_pm',
    hasImportedGLB: false,
    importedGLBFilename: null,
    currentActionId: 'idle',
    currentActionDef: PM_DEMO_ACTIONS[0],
    currentState: 'IDLE',
    isWalking: false,
    isPaused: false,
    speedMultiplier: 1,
    patrolActive: false,
    autoDemoActive: false,
    autoDemoStepIndex: 0,
    autoDemoStepTitle: null,
    currentAnchorId: 'ROOM_IDLE_POSITION',
    targetAnchorId: 'ROOM_IDLE_POSITION',
    worldPosition: [3.35, 0, 5.15],
    facingDeg: 135,
    activeClipName: 'Idle_Breathing (Original Voxel)',
    capabilityMode: 'CASE_A_EMBEDDED_CLIPS',
    scaleMultiplier: 1.0,
    forwardOffsetDeg: 0,
    isPMSelected: false,
    overheadScreenPos: { x: 400, y: 300, visible: false },
  });

  const [inspectorOpen, setInspectorOpen] = useState<boolean>(true);
  const [dockCollapsed, setDockCollapsed] = useState<boolean>(false);
  const [presetCategory, setPresetCategory] = useState<'all' | 'standard' | 'inspection'>('all');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const notifyStatus = useCallback((msg: string) => {
    setStatusMessage(msg);
  }, []);

  const updateConfig = useCallback((partial: Partial<ViewerDisplayConfig>) => {
    setConfig((prev) => ({ ...prev, ...partial }));
  }, []);

  const handleSelectCatalogItem = useCallback(
    (catalogId: string | null, details?: SelectedObjectInspection | null) => {
      setConfig((prev) => ({ ...prev, selectedCatalogId: catalogId }));
      if (details !== undefined) {
        setSelectedDetails(details);
      } else if (catalogId === null) {
        setSelectedDetails(null);
      } else {
        const measured = canvasRef.current?.inspectCatalogItem(catalogId) ?? null;
        setSelectedDetails(measured);
      }
    },
    []
  );

  const handleExportGLB = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const res = await canvasRef.current.exportGLB();
      const kb = (res.byteLength / 1024).toFixed(1);
      notifyStatus(`Exported Room-Only ${res.filename} (${kb} KB binary GLB · Character excluded)`);
    } catch (err) {
      notifyStatus(`GLB Export error: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleExportOriginalPMGLB = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const res = await canvasRef.current.exportOriginalPMGLB();
      const kb = (res.byteLength / 1024).toFixed(1);
      notifyStatus(
        `Exported Original Room-Native Boss PM ${res.filename} (${kb} KB binary GLB with 11 animation clips)`
      );
    } catch (err) {
      notifyStatus(`Original PM GLB Export error: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleExportManifest = useCallback(() => {
    if (!canvasRef.current) return;
    const res = canvasRef.current.exportManifest();
    notifyStatus(`Exported companion manifest ${res.filename}`);
  }, [notifyStatus]);

  const handleExportRoomManifestAndAnchors = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const pack = await canvasRef.current.exportRoomProductionPack();
      downloadRoomManifestAndAnchors(pack.manifest, pack.anchorsJson);
      notifyStatus('Exported pm_room.manifest.json + pm_room.anchors.json');
    } catch (err) {
      notifyStatus(`Export Room Manifest failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleExportCharacterManifestAndBehavior = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const pack = await canvasRef.current.exportCharacterCandidatePack();
      downloadCharacterManifestAndBehavior(pack.manifest, pack.behaviorJson);
      notifyStatus('Exported boss_pm.manifest.json + boss_pm.behavior.json');
    } catch (err) {
      notifyStatus(`Export Character Manifest failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleExportPNG = useCallback(async () => {
    if (!canvasRef.current) return;
    const res = await canvasRef.current.exportPreviewPNG();
    notifyStatus(`Saved room preview ${res.filename}`);
  }, [notifyStatus]);

  const handleExportCharacterPNG = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const res = await canvasRef.current.exportCharacterPreviewPNG();
      notifyStatus(`Saved Boss PM preview ${res.filename}`);
    } catch (err) {
      notifyStatus(`Export Character PNG failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleDownloadRoomPackZip = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      notifyStatus('Packaging Deliverable A (pm_room_production_pack_v1.zip)...');
      const pack = await canvasRef.current.exportRoomProductionPack();
      const res = downloadRoomAssetPackZip(pack);
      notifyStatus(
        `Downloaded ${res.filename} (pm_room.glb ${(pack.glbSizeBytes / 1024).toFixed(1)} KB + manifest + anchors + preview + README)`
      );
    } catch (err) {
      notifyStatus(`Room Pack ZIP failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleDownloadCharacterPackZip = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      notifyStatus('Packaging Deliverable B (boss_pm_export_candidate_v1.zip)...');
      const pack = await canvasRef.current.exportCharacterCandidatePack();
      const res = downloadCharacterAssetPackZip(pack);
      notifyStatus(
        `Downloaded ${res.filename} (boss_pm.glb ${(pack.glbSizeBytes / 1024).toFixed(1)} KB + manifest + behavior + preview + README)`
      );
    } catch (err) {
      notifyStatus(`Character Pack ZIP failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleDownloadSourceZip = useCallback(async () => {
    try {
      const res = await downloadModularRoomLabSourceZip();
      notifyStatus(
        `Downloaded ${res.filename} (${res.fileCount} source files · ${(res.byteLength / 1024).toFixed(1)} KB)`
      );
    } catch (err) {
      notifyStatus(`Source ZIP failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleDownloadCompleteHandoffZip = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      notifyStatus('Building full AI-OFFICE-PM-ROOM-HANDOFF-V1.zip (Room + Boss PM + Validation + Source)...');
      const srcFiles = getBundledSourceFileList();
      const [roomPack, characterPack, rtReport] = await Promise.all([
        canvasRef.current.exportRoomProductionPack(),
        canvasRef.current.exportCharacterCandidatePack(),
        canvasRef.current.runFullHandoffValidation(srcFiles.length),
      ]);
      const stab = canvasRef.current.runVisualStabilityScan();
      setStabilityReport(stab);
      const res = await downloadCompleteHandoffBundleZip({
        roomPack,
        characterPack,
        roundTripReport: rtReport,
        stabilityReport: stab,
      });
      notifyStatus(
        `Downloaded ${res.filename} (${(res.byteLength / 1024).toFixed(1)} KB · All 19 validation checks PASS)`
      );
    } catch (err) {
      notifyStatus(`Complete Handoff ZIP failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleDownloadRoundTripReport = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const srcFiles = getBundledSourceFileList();
      const rtReport = await canvasRef.current.runFullHandoffValidation(srcFiles.length);
      downloadRoundTripReportJson(rtReport);
      const passedCount = rtReport.validation_matrix.filter((r) => r.status === 'PASS').length;
      notifyStatus(
        `Exported roundtrip-report.json (${passedCount}/${rtReport.validation_matrix.length} checks PASS)`
      );
    } catch (err) {
      notifyStatus(`Round-Trip Report failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleRunImportTest = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const srcFiles = getBundledSourceFileList();
      const rtReport = await canvasRef.current.runFullHandoffValidation(srcFiles.length);
      setRoundTripReport(rtReport);
      setImportReport(rtReport.room_roundtrip);
      const stab = canvasRef.current.runVisualStabilityScan();
      setStabilityReport(stab);
      setConfig((prev) => ({
        ...prev,
        workspaceMode: 'import_test',
        reimportDisplayMode: prev.reimportDisplayMode ?? 'both_reimported',
      }));
      const passedCount = rtReport.validation_matrix.filter((r) => r.status === 'PASS').length;
      notifyStatus(
        `Independent Round-Trip Verified: pm_room.glb (${rtReport.room_roundtrip.fileSizeKB}, ${rtReport.room_roundtrip.meshCount} meshes) + boss_pm.glb (${rtReport.character_roundtrip.fileSizeKB}, ${rtReport.character_roundtrip.embeddedClipsVerified.count} clips) — ${passedCount}/${rtReport.validation_matrix.length} PASS`
      );
    } catch (err) {
      notifyStatus(`GLB Import test failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [notifyStatus]);

  const handleTriggerAction = useCallback((actionId: PMActionId) => {
    setBubbleDismissedForAction(null);
    setConfig((prev) => ({ ...prev, workspaceMode: 'builder', showBossPM: true }));
    canvasRef.current?.triggerPMAction(actionId);
  }, []);

  const handleUploadCustomGLB = useCallback(
    async (file: File) => {
      if (!canvasRef.current) return;
      try {
        setConfig((prev) => ({ ...prev, workspaceMode: 'builder', showBossPM: true }));
        setInspectorOpen(true);
        setInspectorTab('simulation');
        const report = await canvasRef.current.loadCustomBossPMFile(file);
        setGlbInspectionReport(report);
        notifyStatus(
          `Karakter GLB Diimpor: ${file.name} (${report.meshCount} meshes · ${report.materialCount} materials · ${report.animationClips.length} clips)`
        );
      } catch (err) {
        notifyStatus(
          `Gagal mengimpor GLB: ${err instanceof Error ? err.message : String(err)}`
        );
      }
    },
    [notifyStatus]
  );

  const handleTopFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleUploadCustomGLB(file);
      e.target.value = '';
    }
  };

  const handleExportSimConfig = useCallback(() => {
    if (!canvasRef.current) return;
    const res = canvasRef.current.exportSimulationConfig();
    notifyStatus(`Exported reusable PM Simulation Config (${res.filename})`);
  }, [notifyStatus]);

  const handleRunStabilityScan = useCallback(() => {
    if (!canvasRef.current) return;
    const report = canvasRef.current.runVisualStabilityScan();
    setStabilityReport(report);
    notifyStatus(
      `Visual Stability Verified: ${report.totalRoomMeshes} room meshes · ${report.totalCharacterMeshes} PM meshes · 0 coplanar/duplicate conflicts`
    );
  }, [notifyStatus]);

  const visiblePresets = CAMERA_PRESETS.filter((p) => {
    if (presetCategory === 'all') return true;
    if (presetCategory === 'standard') return p.category === 'standard' || p.category === 'diagonal';
    return p.category === 'inspection';
  });

  const activeSpeechOrThought =
    telemetry.loaded &&
    !telemetry.isWalking &&
    bubbleDismissedForAction !== telemetry.currentActionId &&
    (telemetry.currentActionDef.speechBubble || telemetry.currentActionDef.thoughtBubble);

  return (
    <div
      data-state={config.workspaceMode}
      className="h-screen w-screen overflow-hidden flex flex-col bg-[#1E1F26] text-[#F3EFEA]"
    >
      {/* Hidden Top-Level File Picker for Import Karakter GLB */}
      <input
        ref={topGlbInputRef}
        type="file"
        accept=".glb,model/gltf-binary,.gltf"
        onChange={handleTopFileInputChange}
        className="hidden"
      />

      {/* Top Bar Contract: 3 Zones separated by gap-8 */}
      <header className="h-13 shrink-0 flex items-center justify-between gap-8 px-5 bg-[#14151B] border-b border-[#2B2D38] z-30">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            canvasRef.current?.resetCamera();
          }}
          className="text-base font-bold tracking-tight text-[#F5F2EB] whitespace-nowrap shrink-0"
        >
          AI Office — Living PM Room Simulation
        </a>

        {/* Zone 2: 5 concise single-line text navigation links */}
        <nav
          aria-label="Workspace Navigation"
          className="hidden md:flex items-center gap-6 text-xs font-medium text-[#A3AAB8]"
        >
          <button
            type="button"
            onClick={() => topGlbInputRef.current?.click()}
            className="text-[#FBBF24] hover:text-[#FDE68A] font-semibold transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Import Karakter GLB
          </button>
          <button
            type="button"
            onClick={() => {
              updateConfig({ workspaceMode: 'builder', showBossPM: true });
              setInspectorOpen(true);
              setInspectorTab('simulation');
            }}
            className={`hover:text-[#F5F2EB] transition-colors whitespace-nowrap shrink-0 py-1 ${
              config.workspaceMode === 'builder' && inspectorTab === 'simulation'
                ? 'text-[#F5F2EB] underline underline-offset-4 decoration-[#D99252]'
                : ''
            }`}
          >
            PM Agent Simulasi
          </button>
          <button
            type="button"
            onClick={() => {
              setInspectorOpen(true);
              setInspectorTab('validation');
              handleRunImportTest();
            }}
            className={`hover:text-[#F5F2EB] transition-colors whitespace-nowrap shrink-0 py-1 ${
              config.workspaceMode === 'import_test'
                ? 'text-[#F5F2EB] underline underline-offset-4 decoration-[#6EE7B7]'
                : ''
            }`}
          >
            Test Exported GLB
          </button>
          <button
            type="button"
            onClick={() => canvasRef.current?.focusCameraOnPM()}
            className="hover:text-[#F5F2EB] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Focus Karakter PM
          </button>
          <button
            type="button"
            onClick={() => setInspectorOpen((o) => !o)}
            className="hover:text-[#F5F2EB] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            {inspectorOpen ? 'Hide Panel' : 'Show Panel'}
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleExportGLB}
            className="px-4 py-2 text-xs font-semibold text-[#14151B] bg-[#D99252] rounded-lg hover:bg-[#E49F60] transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Room to GLB</span>
          </button>
        </div>
      </header>

      {/* Main Content Area: Center 3D Viewport + Right Inspector */}
      <main className="flex-1 flex min-h-0 relative overflow-hidden">
        {/* Center 3D Viewport */}
        <div className="flex-1 relative h-full min-w-0 bg-[#2C2D35]">
          <ModularRoomCanvas
            ref={canvasRef}
            config={config}
            activePresetId={activePresetId}
            anchors={anchors}
            selectedAnchorId={selectedAnchorId}
            onSelectCatalogItem={handleSelectCatalogItem}
            onStatsReady={setStats}
            onImportReportReady={setImportReport}
            onRoundTripReportReady={setRoundTripReport}
            onPresetChange={setActivePresetId}
            onPMRuntimeStateChange={setTelemetry}
            onGLBInspectionReady={setGlbInspectionReport}
            onPMCharacterSelectChange={(sel) => {
              if (sel) {
                setInspectorOpen(true);
                setInspectorTab('simulation');
              }
            }}
            onMeshDiagnosticSelect={setClickedMeshDiagnostic}
            onDropGLBFile={handleUploadCustomGLB}
          />

          {/* Top-Left Minimal Spec & Active Simulation Header Overlay */}
          <div className="absolute top-3.5 left-4 z-10 pointer-events-none flex flex-col gap-1.5 max-w-md">
            <div className="bg-[#14151B]/95 border border-[#2B2D38] rounded-lg px-3.5 py-2 pointer-events-auto shadow-sm">
              <div className="flex items-center justify-between gap-3">
                <span className="text-xs font-semibold text-[#F5F2EB]">
                  Module 01: {MODULE_CONSTANTS.DISPLAY_NAME}
                </span>
                <span className="text-[10px] font-mono text-[#6EE7B7]">
                  {telemetry.activeCharacterSource === 'original_pm'
                    ? 'ORIGINAL PM (DEFAULT)'
                    : 'IMPORTED GLB'}
                </span>
              </div>
              <div className="text-[11px] text-[#9CA3AF] font-mono tabular-nums mt-0.5">
                8×8 Units · Origin [0,0,0] SW · PM Pos: [{telemetry.worldPosition[0]},{' '}
                {telemetry.worldPosition[2]}] ({telemetry.currentState})
              </div>
            </div>

            {/* Interactive Speech / Thought / Pending Approval Bubble Overlay */}
            {config.workspaceMode === 'builder' &&
              config.showBossPM &&
              telemetry.loaded &&
              (activeSpeechOrThought || telemetry.currentState === 'WAITING_APPROVAL') && (
                <div
                  role="dialog"
                  aria-label="Boss PM Activity Status Bubble"
                  className="bg-[#14151B]/95 border border-[#D99252] rounded-xl p-3 pointer-events-auto shadow-lg space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-[#FBBF24] flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>
                        Boss PM — {telemetry.currentActionDef.labelId} (SIMULASI / DEMO)
                      </span>
                    </span>
                    <button
                      type="button"
                      aria-label="Dismiss Speech Bubble"
                      onClick={() => setBubbleDismissedForAction(telemetry.currentActionId)}
                      className="text-[#9CA3AF] hover:text-white p-0.5"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {activeSpeechOrThought && (
                    <p className="text-xs text-[#F5F2EB] italic leading-relaxed bg-[#1E2029] px-2.5 py-2 rounded-lg border border-[#2B2D38]">
                      “{activeSpeechOrThought}”
                    </p>
                  )}

                  {telemetry.currentState === 'WAITING_APPROVAL' && (
                    <button
                      type="button"
                      onClick={() => canvasRef.current?.approvePendingTask()}
                      className="w-full py-1.5 px-3 rounded-lg bg-[#10B981] hover:bg-[#059669] text-[#0B1310] font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>Berikan Persetujuan</span>
                    </button>
                  )}
                </div>
              )}

            {/* Selected Boss PM Character Quick Action Bar */}
            {config.workspaceMode === 'builder' && telemetry.loaded && telemetry.isPMSelected && (
              <div className="bg-[#14151B]/95 border border-[#38BDF8] rounded-lg px-3 py-2 pointer-events-auto flex items-center justify-between gap-3">
                <div className="text-xs">
                  <span className="font-semibold text-[#7DD3FC]">Karakter PM Dipilih</span>
                  <span className="text-[#9CA3AF] ml-2 font-mono text-[11px]">
                    {telemetry.currentState}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => canvasRef.current?.focusCameraOnPM()}
                    className="px-2 py-1 rounded bg-[#1E293B] hover:bg-[#334155] text-[#F3EFEA] text-[11px] flex items-center gap-1"
                  >
                    <Focus className="w-3 h-3 text-[#D99252]" />
                    <span>Focus Camera on PM</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => canvasRef.current?.returnToRoomView()}
                    className="px-2 py-1 rounded bg-[#1E293B] hover:bg-[#334155] text-[#F3EFEA] text-[11px]"
                  >
                    Return to Room View
                  </button>
                </div>
              </div>
            )}

            {statusMessage && (
              <div
                role="status"
                className="bg-[#1B2420] border border-[#34D399]/60 text-[#A7F3D0] rounded-lg px-3.5 py-1.5 text-xs font-medium pointer-events-auto flex items-center justify-between gap-3"
              >
                <span>{statusMessage}</span>
                <button
                  type="button"
                  onClick={() => setStatusMessage(null)}
                  className="text-[11px] text-[#6EE7B7] hover:underline whitespace-nowrap shrink-0"
                >
                  Dismiss
                </button>
              </div>
            )}
          </div>

          {/* Top-Right Inspector Drawer Toggle Button when closed */}
          {!inspectorOpen && (
            <button
              type="button"
              onClick={() => setInspectorOpen(true)}
              aria-label="Open Room Inspector"
              className="absolute top-3.5 right-4 z-10 px-3 py-2 rounded-lg bg-[#14151B] border border-[#2B2D38] text-xs font-medium text-[#E5E0D8] hover:border-[#D99252] transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <PanelRightOpen className="w-3.5 h-3.5 text-[#D99252]" />
              <span>Open Panel</span>
            </button>
          )}

          {/* Collapsible Bottom Control & Camera Preset Dock */}
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 w-[min(940px,95%)] flex flex-col items-center pointer-events-none">
            <button
              type="button"
              onClick={() => setDockCollapsed((c) => !c)}
              className="pointer-events-auto mb-1 px-3 py-1 rounded-t-lg bg-[#14151B] border border-b-0 border-[#2B2D38] text-[11px] font-medium text-[#A3AAB8] hover:text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              {dockCollapsed ? (
                <>
                  <ChevronUp className="w-3.5 h-3.5" />
                  <span>Show Camera & Quick Demo Dock</span>
                </>
              ) : (
                <>
                  <ChevronDown className="w-3.5 h-3.5" />
                  <span>Hide Controls (Cinema Mode)</span>
                </>
              )}
            </button>

            {!dockCollapsed && (
              <div className="pointer-events-auto w-full bg-[#14151B] border border-[#2B2D38] rounded-xl p-2.5 shadow-lg space-y-2">
                {/* Row 1: Camera Manipulation Controls + Focus PM + Category Filter */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#242630]">
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => canvasRef.current?.orbitBy(-Math.PI / 8)}
                      aria-label="Rotate Camera Left"
                      className="px-2.5 py-1.5 rounded-md bg-[#1E2029] hover:bg-[#2A2D3A] text-xs font-medium text-[#E5E0D8] flex items-center gap-1 whitespace-nowrap shrink-0"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Rotate L</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => canvasRef.current?.orbitBy(Math.PI / 8)}
                      aria-label="Rotate Camera Right"
                      className="px-2.5 py-1.5 rounded-md bg-[#1E2029] hover:bg-[#2A2D3A] text-xs font-medium text-[#E5E0D8] flex items-center gap-1 whitespace-nowrap shrink-0"
                    >
                      <RotateCw className="w-3.5 h-3.5" />
                      <span>Rotate R</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => canvasRef.current?.zoomBy(1.18)}
                      aria-label="Zoom In"
                      className="px-2.5 py-1.5 rounded-md bg-[#1E2029] hover:bg-[#2A2D3A] text-xs font-medium text-[#E5E0D8] flex items-center gap-1 whitespace-nowrap shrink-0"
                    >
                      <ZoomIn className="w-3.5 h-3.5" />
                      <span>Zoom In</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => canvasRef.current?.zoomBy(1 / 1.18)}
                      aria-label="Zoom Out"
                      className="px-2.5 py-1.5 rounded-md bg-[#1E2029] hover:bg-[#2A2D3A] text-xs font-medium text-[#E5E0D8] flex items-center gap-1 whitespace-nowrap shrink-0"
                    >
                      <ZoomOut className="w-3.5 h-3.5" />
                      <span>Zoom Out</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => canvasRef.current?.fitRoom()}
                      aria-label="Fit Room in Viewport"
                      className="px-2.5 py-1.5 rounded-md bg-[#1E2029] hover:bg-[#2A2D3A] text-xs font-medium text-[#E5E0D8] flex items-center gap-1 whitespace-nowrap shrink-0"
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                      <span>Fit Room</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => canvasRef.current?.resetCamera()}
                      aria-label="Reset Camera to Default Isometric"
                      className="px-2.5 py-1.5 rounded-md bg-[#1E2029] hover:bg-[#2A2D3A] text-xs font-medium text-[#D99252] flex items-center gap-1 whitespace-nowrap shrink-0"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      <span>Reset Iso</span>
                    </button>
                    {telemetry.loaded && (
                      <button
                        type="button"
                        onClick={() => canvasRef.current?.focusCameraOnPM()}
                        className="px-2.5 py-1.5 rounded-md bg-[#262936] hover:bg-[#313546] border border-[#D99252]/40 text-xs font-medium text-[#FBBF24] flex items-center gap-1 whitespace-nowrap shrink-0"
                      >
                        <Focus className="w-3.5 h-3.5" />
                        <span>Focus PM</span>
                      </button>
                    )}
                  </div>

                  {/* Camera Preset Filter Tabs */}
                  <div className="flex items-center gap-1 bg-[#1C1E26] p-0.5 rounded-lg border border-[#282B36]">
                    {(
                      [
                        { id: 'all', label: 'All Views (13)' },
                        { id: 'standard', label: 'Angles (9)' },
                        { id: 'inspection', label: 'Close-Ups (4)' },
                      ] as const
                    ).map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setPresetCategory(tab.id)}
                        className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                          presetCategory === tab.id
                            ? 'bg-[#2E3240] text-[#F5F2EB]'
                            : 'text-[#8E95A5] hover:text-white'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Row 2: Camera Angle & Inspection Close-Up Presets */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] font-medium text-[#8E95A5] flex items-center gap-1 pr-1 shrink-0">
                    <Camera className="w-3.5 h-3.5 text-[#D99252]" />
                    <span>Presets:</span>
                  </span>
                  {visiblePresets.map((preset) => {
                    const active = activePresetId === preset.id;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => canvasRef.current?.setCameraPreset(preset.id)}
                        className={`px-2 py-1 rounded-md text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 border ${
                          active
                            ? 'bg-[#D99252] text-[#14151B] border-[#D99252] font-semibold'
                            : 'bg-[#1D1F28] text-[#D1D5DB] border-[#2A2D3A] hover:border-[#4B5563] hover:text-white'
                        }`}
                      >
                        {preset.shortLabel}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Room Inspector & Simulation Controls Panel */}
        {inspectorOpen && (
          <div className="relative h-full flex">
            <button
              type="button"
              onClick={() => setInspectorOpen(false)}
              aria-label="Collapse Room Inspector"
              className="absolute -left-8 top-3.5 z-20 p-1.5 rounded-l-lg bg-[#181920] border border-r-0 border-[#2B2D38] text-[#9CA3AF] hover:text-white"
            >
              <PanelRightClose className="w-4 h-4" />
            </button>
            <RoomInspectorPanel
              activeTab={inspectorTab}
              onTabChange={setInspectorTab}
              config={config}
              stats={stats}
              selectedDetails={selectedDetails}
              importReport={importReport}
              roundTripReport={roundTripReport}
              telemetry={telemetry}
              glbInspectionReport={glbInspectionReport}
              anchors={anchors}
              selectedAnchorId={selectedAnchorId}
              onUpdateConfig={updateConfig}
              onSelectCatalogItem={(id) => handleSelectCatalogItem(id)}
              onRunImportTest={handleRunImportTest}
              onExportGLB={handleExportGLB}
              onExportOriginalPMGLB={handleExportOriginalPMGLB}
              onExportManifest={handleExportManifest}
              onExportRoomManifestAndAnchors={handleExportRoomManifestAndAnchors}
              onExportCharacterManifestAndBehavior={handleExportCharacterManifestAndBehavior}
              onExportPNG={handleExportPNG}
              onExportCharacterPNG={handleExportCharacterPNG}
              onDownloadRoomPackZip={handleDownloadRoomPackZip}
              onDownloadCharacterPackZip={handleDownloadCharacterPackZip}
              onDownloadSourceZip={handleDownloadSourceZip}
              onDownloadCompleteHandoffZip={handleDownloadCompleteHandoffZip}
              onDownloadRoundTripReport={handleDownloadRoundTripReport}
              onFitRoom={() => canvasRef.current?.fitRoom()}
              onCharacterSourceChange={(src) => {
                canvasRef.current?.setCharacterSource(src);
                notifyStatus(
                  src === 'original_pm'
                    ? 'Sumber Karakter: Original Room-Native Boss PM (Default)'
                    : 'Sumber Karakter: Imported GLB (Optional)'
                );
              }}
              onTriggerAction={handleTriggerAction}
              onPlaybackCommand={(cmd) => canvasRef.current?.setSimulationPlayback(cmd)}
              onSpeedChange={(spd) => canvasRef.current?.setSimulationSpeed(spd)}
              onStartAutoDemo={() => canvasRef.current?.startAutoDemo()}
              onStopAutoDemo={() => canvasRef.current?.stopAutoDemo()}
              onApproveTask={() => canvasRef.current?.approvePendingTask()}
              onFocusPM={() => canvasRef.current?.focusCameraOnPM()}
              onReturnRoomView={() => canvasRef.current?.returnToRoomView()}
              onSelectAnchor={setSelectedAnchorId}
              onUpdateAnchor={(id, updated) =>
                setAnchors((prev) => ({
                  ...prev,
                  [id]: updated,
                }))
              }
              onResetAnchors={() => setAnchors({ ...DEFAULT_ACTIVITY_ANCHORS })}
              onTeleportToAnchor={(id) => canvasRef.current?.teleportPMToAnchor(id)}
              onUploadCustomGLB={handleUploadCustomGLB}
              onScaleMultiplierChange={(mult) =>
                canvasRef.current?.setCharacterScaleMultiplier(mult)
              }
              onForwardOffsetChange={(deg) =>
                canvasRef.current?.setCharacterForwardOffsetDeg(deg)
              }
              onExportSimConfig={handleExportSimConfig}
              clickedMeshDiagnostic={clickedMeshDiagnostic}
              stabilityReport={stabilityReport}
              onRunStabilityScan={handleRunStabilityScan}
            />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
