import {
  CAMERA_PRESETS,
  CONNECTORS_SPEC,
  ConnectorSpec,
  FURNITURE_CATALOG,
  MODULE_CONSTANTS,
  RoomExportStats,
} from '../domain/modularRoomSpec';
import {
  AUTO_DEMO_SEQUENCE,
  ActivityAnchor,
  AnchorId,
  DEFAULT_ACTIVITY_ANCHORS,
  PATROL_ANCHOR_SEQUENCE,
  PMActionDefinition,
  PMActionId,
  PMAgentStateId,
  PM_DEMO_ACTIONS,
  ROOM_WALK_WAYPOINTS,
  WalkWaypoint,
} from '../domain/pmSimulationSpec';

export const HANDOFF_PACKAGE_VERSION = '1.0.0';
export const HANDOFF_PACKAGE_ID = 'AI-OFFICE-PM-ROOM-HANDOFF-V1';

export const PRODUCTION_FILENAMES = {
  ROOM_GLB: 'pm_room.glb',
  ROOM_MANIFEST: 'pm_room.manifest.json',
  ROOM_ANCHORS: 'pm_room.anchors.json',
  ROOM_PREVIEW: 'pm_room.preview.png',
  ROOM_README: 'README.md',
  CHARACTER_GLB: 'boss_pm.glb',
  CHARACTER_MANIFEST: 'boss_pm.manifest.json',
  CHARACTER_BEHAVIOR: 'boss_pm.behavior.json',
  CHARACTER_PREVIEW: 'boss_pm.preview.png',
  CHARACTER_README: 'README.md',
  ROUNDTRIP_REPORT: 'roundtrip-report.json',
  VISUAL_STABILITY_REPORT: 'visual-stability-report.json',
  SOURCE_ZIP: 'modular-room-lab-source.zip',
  HANDOFF_BUNDLE_ZIP: 'AI-OFFICE-PM-ROOM-HANDOFF-V1.zip',
} as const;

export type AnimationExportClassification =
  | 'EMBEDDED_GLTF_CLIP'
  | 'PROCEDURAL_CONTROLLER'
  | 'HYBRID'
  | 'UNSUPPORTED_IN_STANDALONE_EXPORT';

export interface FileInventoryEntry {
  logical_path: string;
  filename: string;
  mime_type: string;
  size_bytes: number;
  sha256: string;
}

export interface FurnitureExportParityItem {
  catalog_id: string;
  name: string;
  category: string;
  included_in_room_glb: boolean;
  source_module: string;
  local_position: [number, number, number];
  catalog_dimensions: [number, number, number];
  mesh_count: number;
  material_type: string;
  gltf_compatible: boolean;
  visual_parity_notes: string;
}

export interface PMRoomManifestV1 {
  schema_version: 'AI_OFFICE_ASSET_MANIFEST_V1';
  asset_id: 'ai_office.room.pm_strategy.v1';
  legacy_module_id: string;
  asset_version: string;
  asset_kind: 'room';
  source_project_name: string;
  source_revision: string;
  export_date: string;
  file_inventory: {
    glb: {
      filename: string;
      relative_path: string;
      size_bytes: number;
      sha256: string;
    };
    manifest: {
      filename: string;
      relative_path: string;
    };
    anchors: {
      filename: string;
      relative_path: string;
    };
    preview: {
      filename: string;
      relative_path: string;
    };
    readme: {
      filename: string;
      relative_path: string;
    };
  };
  coordinate_and_scale_contract: {
    up_axis: 'Y';
    handedness: 'right-handed';
    world_floor_y: number;
    floor_subbase_min_y: number;
    wall_top_y: number;
    grid_unit_size: number;
    world_unit_scale: string;
    room_origin: [number, number, number];
    room_origin_convention: string;
    footprint_units: [number, number];
    recentered_on_export: false;
    default_front_facing_note: string;
  };
  measured_bounds: {
    local_min: [number, number, number];
    local_max: [number, number, number];
    world_min: [number, number, number];
    world_max: [number, number, number];
    size: [number, number, number];
  };
  geometry_and_material_summary: {
    source_mesh_count: number;
    exported_mesh_count: number;
    material_count: number;
    triangle_count: number;
    embedded_texture_count: number;
    content_groups: string[];
    group_mesh_counts: Record<string, number>;
    character_excluded: true;
    preview_helpers_excluded: true;
  };
  connectors: Record<'EAST' | 'SOUTH', ConnectorSpec>;
  furniture_and_material_parity: FurnitureExportParityItem[];
  rendering_profile: {
    camera_projection: 'orthographic';
    recommended_position: [number, number, number];
    recommended_target: [number, number, number];
    recommended_zoom: number;
    orthographic_near: number;
    orthographic_far: number;
    shadow_map_size: [number, number];
    shadow_bias: number;
    shadow_normal_bias: number;
    tone_mapping: 'ACESFilmicToneMapping';
    tone_mapping_exposure: number;
    output_color_space: 'SRGBColorSpace';
    texture_filtering: 'THREE.NearestFilter (crisp pixel-art)';
    polygon_offset_surfaces: string[];
    runtime_viewer_dependencies: string[];
  };
  animation_inventory: {
    embedded_clips_count: 0;
    note: string;
  };
  validation_status: 'PASS' | 'FAIL' | 'NOT_VERIFIED';
  known_limitations: string[];
  provenance: {
    author_tool: string;
    visual_source_of_truth: string;
    license: string;
  };
}

export interface PMRoomAnchorsJsonV1 {
  schema_version: 'AI_OFFICE_ROOM_ANCHORS_V1';
  room_asset_id: 'ai_office.room.pm_strategy.v1';
  room_module_id: string;
  coordinate_convention: {
    up_axis: 'Y';
    floor_elevation_y: 0;
    room_origin: [number, number, number];
    facing_convention: '0 rad = North (+Z), +PI/2 = East (+X), PI = South (-Z), -PI/2 = West (-X)';
  };
  spawn_anchor_id: AnchorId;
  default_idle_anchor_id: AnchorId;
  connectors: Record<'EAST' | 'SOUTH', ConnectorSpec>;
  anchors: Array<{
    id: AnchorId;
    room_module_id: string;
    label: string;
    world_position: [number, number, number];
    local_position: [number, number, number];
    facing_rad: number;
    facing_deg: number;
    forward_vector: [number, number, number];
    activity_role: PMActionId;
    posture: 'standing' | 'seated' | 'leaning';
    approach_anchor_id: AnchorId | null;
    associated_furniture_id: string | null;
    character_compatibility: string[];
    description: string;
  }>;
  navigation_waypoints: Array<{
    id: string;
    world_position: [number, number, number];
    neighbors: string[];
    obstacle_clear: boolean;
  }>;
  patrol_anchor_sequence: AnchorId[];
  obstacle_footprint_catalog: Array<{
    furniture_id: string;
    name: string;
    center_xz: [number, number];
    size_xz: [number, number];
    blocks_navigation: boolean;
  }>;
}

export interface BossPMManifestV1 {
  schema_version: 'AI_OFFICE_ASSET_MANIFEST_V1';
  asset_id: 'ai_office.character.boss_pm_room_native.v1';
  legacy_asset_id: string;
  asset_version: string;
  asset_kind: 'character';
  role_classification: 'ROOM_NATIVE_EXPORT_CANDIDATE';
  canonical_character_lab_notice: string;
  source_project_name: string;
  source_revision: string;
  export_date: string;
  file_inventory: {
    glb: {
      filename: string;
      relative_path: string;
      size_bytes: number;
      sha256: string;
    };
    manifest: {
      filename: string;
      relative_path: string;
    };
    behavior: {
      filename: string;
      relative_path: string;
    };
    preview: {
      filename: string;
      relative_path: string;
    };
    readme: {
      filename: string;
      relative_path: string;
    };
  };
  coordinate_and_scale_contract: {
    up_axis: 'Y';
    handedness: 'right-handed';
    character_origin: [number, number, number];
    origin_convention: 'Feet contact point flush with floor plane Y = 0.000';
    local_forward: [number, number, number];
    raw_height_units: number;
    calibrated_height_units: number;
    applied_scale_factor: number;
    separate_from_room_root: true;
  };
  measured_bounds: {
    local_min: [number, number, number];
    local_max: [number, number, number];
    size: [number, number, number];
  };
  geometry_and_material_summary: {
    source_hierarchy_total_meshes: number;
    exported_rest_pose_visible_meshes: number;
    contextual_handheld_prop_meshes_in_source: number;
    mesh_count_difference_explanation: string;
    material_count: number;
    material_names: string[];
    has_skinned_skeleton: false;
    articulated_pivot_groups: string[];
    visual_identity_checklist: {
      blocky_voxel_silhouette: true;
      geometric_dark_hairstyle: true;
      rectangular_black_sunglasses: true;
      black_suit_jacket: true;
      white_inner_shirt: true;
      red_necktie: true;
      ear_sideburn_temple_separation_preserved: true;
      torso_z_layering_preserved: true;
    };
  };
  animation_inventory: {
    embedded_gltf_clip_count: number;
    clips: Array<{
      name: string;
      duration_seconds: number;
      track_count: number;
      targeted_pivots: string[];
      classification: AnimationExportClassification;
    }>;
  };
  validation_status: 'PASS' | 'FAIL' | 'NOT_VERIFIED';
  known_limitations: string[];
  provenance: {
    author_tool: string;
    visual_source_of_truth: string;
    license: string;
  };
}

export interface BossPMBehaviorJsonV1 {
  schema_version: 'AI_OFFICE_CHARACTER_BEHAVIOR_V1';
  character_asset_id: 'ai_office.character.boss_pm_room_native.v1';
  compatible_room_asset_id: 'ai_office.room.pm_strategy.v1';
  simulation_mode: 'VISUAL_DEMONSTRATION_ONLY';
  source_controller_modules: string[];
  articulated_hierarchy_contract: {
    root_node: string;
    hips_pivot: string;
    torso_pivot: string;
    head_pivot: string;
    left_arm_pivot: string;
    right_arm_pivot: string;
    left_leg_pivot: string;
    right_leg_pivot: string;
    contextual_prop_nodes: {
      read_document: string;
      phone_call: string;
      coffee_break: string;
    };
  };
  activity_states: Array<{
    state_id: PMAgentStateId;
    action_id: PMActionId;
    action_code: string;
    label_id: string;
    label_en: string;
    export_classification: AnimationExportClassification;
    standalone_clip_classification: 'EMBEDDED_GLTF_CLIP';
    embedded_clip_name: string;
    clip_duration_seconds: number;
    clip_track_count: number;
    procedural_controller_role: string;
    target_anchor_id: AnchorId | null;
    requires_waypoint_walk: boolean;
    posture: 'standing' | 'seated' | 'leaning';
    seated_y_offset: number;
    contextual_props_activated: string[];
    speech_bubble: string | null;
    thought_bubble: string | null;
  }>;
  auto_demo_sequence: typeof AUTO_DEMO_SEQUENCE;
}

/**
 * Computes a real SHA-256 hex digest of an ArrayBuffer, Uint8Array, or UTF-8 string.
 * Uses Web Crypto API (`crypto.subtle.digest`) with a pure TypeScript SHA-256 fallback.
 */
export async function computeSha256Hex(
  input: ArrayBuffer | Uint8Array | string
): Promise<string> {
  const bytes: Uint8Array =
    typeof input === 'string'
      ? new TextEncoder().encode(input)
      : input instanceof Uint8Array
      ? input
      : new Uint8Array(input);

  if (typeof globalThis.crypto !== 'undefined' && globalThis.crypto.subtle) {
    const copy = new Uint8Array(bytes.byteLength);
    copy.set(bytes);
    const hashBuffer = await globalThis.crypto.subtle.digest('SHA-256', copy.buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  return computeSha256Fallback(bytes);
}

function computeSha256Fallback(asciiBytes: Uint8Array): string {
  const K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4,
    0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe,
    0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f,
    0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
    0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
    0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116,
    0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7,
    0xc67178f2,
  ];
  const rotr = (n: number, x: number) => (x >>> n) | (x << (32 - n));
  const H = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab,
    0x5be0cd19,
  ];

  const l = asciiBytes.length;
  const bitLenHi = Math.floor((l * 8) / 0x100000000);
  const bitLenLo = (l * 8) >>> 0;
  const padLen = (l + 9 + 63) & ~63;
  const padded = new Uint8Array(padLen);
  padded.set(asciiBytes);
  padded[l] = 0x80;
  const dv = new DataView(padded.buffer);
  dv.setUint32(padLen - 8, bitLenHi, false);
  dv.setUint32(padLen - 4, bitLenLo, false);

  const W = new Uint32Array(64);
  for (let offset = 0; offset < padLen; offset += 64) {
    for (let i = 0; i < 16; i++) {
      W[i] = dv.getUint32(offset + i * 4, false);
    }
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(7, W[i - 15]) ^ rotr(18, W[i - 15]) ^ (W[i - 15] >>> 3);
      const s1 = rotr(17, W[i - 2]) ^ rotr(19, W[i - 2]) ^ (W[i - 2] >>> 10);
      W[i] = (W[i - 16] + s0 + W[i - 7] + s1) >>> 0;
    }

    let [a, b, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const S1 = rotr(6, e) ^ rotr(11, e) ^ rotr(25, e);
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + K[i] + W[i]) >>> 0;
      const S0 = rotr(2, a) ^ rotr(13, a) ^ rotr(22, a);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) >>> 0;
    }

    H[0] = (H[0] + a) >>> 0;
    H[1] = (H[1] + b) >>> 0;
    H[2] = (H[2] + c) >>> 0;
    H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0;
    H[5] = (H[5] + f) >>> 0;
    H[6] = (H[6] + g) >>> 0;
    H[7] = (H[7] + h) >>> 0;
  }

  return H.map((v) => v.toString(16).padStart(8, '0')).join('');
}

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

export function computeCrc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC32_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export interface ZipEntryInput {
  path: string;
  data: Uint8Array | ArrayBuffer | string;
}

/**
 * Creates a standards-compliant PKZIP archive (STORE method 0) from a list of file entries.
 * Works identically in browser and Node.js environments without external dependencies.
 */
export function createZipArchive(entries: ZipEntryInput[]): Uint8Array {
  const encoder = new TextEncoder();
  const normalized = entries.map((entry) => {
    const cleanPath = entry.path.replace(/^\/+/, '');
    const pathBytes = encoder.encode(cleanPath);
    const dataBytes =
      typeof entry.data === 'string'
        ? encoder.encode(entry.data)
        : entry.data instanceof Uint8Array
        ? entry.data
        : new Uint8Array(entry.data);
    const crc = computeCrc32(dataBytes);
    return { pathBytes, dataBytes, crc };
  });

  let localTotalSize = 0;
  let centralTotalSize = 0;
  for (const item of normalized) {
    localTotalSize += 30 + item.pathBytes.length + item.dataBytes.length;
    centralTotalSize += 46 + item.pathBytes.length;
  }

  const totalSize = localTotalSize + centralTotalSize + 22;
  const out = new Uint8Array(totalSize);
  const view = new DataView(out.buffer);

  // MS-DOS date/time for 2026-10-28 08:00:00
  const dosTime = (8 << 11) | (0 << 5) | 0;
  const dosDate = ((2026 - 1980) << 9) | (10 << 5) | 28;

  let localOffset = 0;
  const offsets: number[] = [];

  for (const item of normalized) {
    offsets.push(localOffset);
    view.setUint32(localOffset, 0x04034b50, true); // Local file header signature
    view.setUint16(localOffset + 4, 20, true); // Version needed to extract (2.0)
    view.setUint16(localOffset + 6, 0x0800, true); // General purpose bit flag (UTF-8)
    view.setUint16(localOffset + 8, 0, true); // Compression method (0 = Store)
    view.setUint16(localOffset + 10, dosTime, true);
    view.setUint16(localOffset + 12, dosDate, true);
    view.setUint32(localOffset + 14, item.crc, true);
    view.setUint32(localOffset + 18, item.dataBytes.length, true);
    view.setUint32(localOffset + 22, item.dataBytes.length, true);
    view.setUint16(localOffset + 26, item.pathBytes.length, true);
    view.setUint16(localOffset + 28, 0, true);
    out.set(item.pathBytes, localOffset + 30);
    out.set(item.dataBytes, localOffset + 30 + item.pathBytes.length);
    localOffset += 30 + item.pathBytes.length + item.dataBytes.length;
  }

  let centralOffset = localOffset;
  for (let i = 0; i < normalized.length; i++) {
    const item = normalized[i];
    view.setUint32(centralOffset, 0x02014b50, true); // Central directory signature
    view.setUint16(centralOffset + 4, 20, true); // Version made by
    view.setUint16(centralOffset + 6, 20, true); // Version needed
    view.setUint16(centralOffset + 8, 0x0800, true); // UTF-8 flag
    view.setUint16(centralOffset + 10, 0, true); // Store
    view.setUint16(centralOffset + 12, dosTime, true);
    view.setUint16(centralOffset + 14, dosDate, true);
    view.setUint32(centralOffset + 16, item.crc, true);
    view.setUint32(centralOffset + 20, item.dataBytes.length, true);
    view.setUint32(centralOffset + 24, item.dataBytes.length, true);
    view.setUint16(centralOffset + 28, item.pathBytes.length, true);
    view.setUint16(centralOffset + 30, 0, true);
    view.setUint16(centralOffset + 32, 0, true);
    view.setUint16(centralOffset + 34, 0, true);
    view.setUint16(centralOffset + 36, 0, true);
    view.setUint32(centralOffset + 38, 0, true);
    view.setUint32(centralOffset + 42, offsets[i], true);
    out.set(item.pathBytes, centralOffset + 46);
    centralOffset += 46 + item.pathBytes.length;
  }

  // End of central directory record
  view.setUint32(centralOffset, 0x06054b50, true);
  view.setUint16(centralOffset + 4, 0, true);
  view.setUint16(centralOffset + 6, 0, true);
  view.setUint16(centralOffset + 8, normalized.length, true);
  view.setUint16(centralOffset + 10, normalized.length, true);
  view.setUint32(centralOffset + 12, centralTotalSize, true);
  view.setUint32(centralOffset + 16, localOffset, true);
  view.setUint16(centralOffset + 20, 0, true);

  return out;
}

export function buildPMRoomManifestV1(params: {
  stats: RoomExportStats;
  glbSizeBytes: number;
  glbSha256: string;
  exportedMeshCount: number;
  furnitureParity: FurnitureExportParityItem[];
  validationStatus?: 'PASS' | 'FAIL' | 'NOT_VERIFIED';
  exportDate?: string;
}): PMRoomManifestV1 {
  const {
    stats,
    glbSizeBytes,
    glbSha256,
    exportedMeshCount,
    furnitureParity,
    validationStatus = 'PASS',
    exportDate = new Date().toISOString(),
  } = params;

  const minB = stats.boundingBox.min.map((v) => Number(v.toFixed(3))) as [number, number, number];
  const maxB = stats.boundingBox.max.map((v) => Number(v.toFixed(3))) as [number, number, number];
  const sizeB = stats.boundingBox.size.map((v) => Number(v.toFixed(3))) as [number, number, number];

  return {
    schema_version: 'AI_OFFICE_ASSET_MANIFEST_V1',
    asset_id: 'ai_office.room.pm_strategy.v1',
    legacy_module_id: MODULE_CONSTANTS.MODULE_ID,
    asset_version: HANDOFF_PACKAGE_VERSION,
    asset_kind: 'room',
    source_project_name: 'ai-office-modular-room-lab',
    source_revision: 'NOT AVAILABLE (Google AI Studio Build Sandbox)',
    export_date: exportDate,
    file_inventory: {
      glb: {
        filename: PRODUCTION_FILENAMES.ROOM_GLB,
        relative_path: './pm_room.glb',
        size_bytes: glbSizeBytes,
        sha256: glbSha256,
      },
      manifest: {
        filename: PRODUCTION_FILENAMES.ROOM_MANIFEST,
        relative_path: './pm_room.manifest.json',
      },
      anchors: {
        filename: PRODUCTION_FILENAMES.ROOM_ANCHORS,
        relative_path: './pm_room.anchors.json',
      },
      preview: {
        filename: PRODUCTION_FILENAMES.ROOM_PREVIEW,
        relative_path: './pm_room.preview.png',
      },
      readme: {
        filename: PRODUCTION_FILENAMES.ROOM_README,
        relative_path: './README.md',
      },
    },
    coordinate_and_scale_contract: {
      up_axis: 'Y',
      handedness: 'right-handed',
      world_floor_y: MODULE_CONSTANTS.FLOOR_ELEVATION,
      floor_subbase_min_y: -MODULE_CONSTANTS.FLOOR_THICKNESS,
      wall_top_y: MODULE_CONSTANTS.WALL_HEIGHT,
      grid_unit_size: MODULE_CONSTANTS.GRID_SIZE,
      world_unit_scale: '1 Three.js world unit = 1 modular grid tile (1.0m nominal)',
      room_origin: [...MODULE_CONSTANTS.ORIGIN],
      room_origin_convention:
        'South-West (SW) floor corner at [0, 0, 0]; room extends across X=[0..8] (West->East) and Z=[0..8] (South->North).',
      footprint_units: [MODULE_CONSTANTS.FOOTPRINT_WIDTH, MODULE_CONSTANTS.FOOTPRINT_DEPTH],
      recentered_on_export: false,
      default_front_facing_note:
        'North (+Z) and West (X=0) walls are full height (3.20u); East (X=8) and South (Z=0) are cutaway walls (0.38u) for three-quarter isometric viewing from the South-East quadrant.',
    },
    measured_bounds: {
      local_min: minB,
      local_max: maxB,
      world_min: minB,
      world_max: maxB,
      size: sizeB,
    },
    geometry_and_material_summary: {
      source_mesh_count: stats.meshCount,
      exported_mesh_count: exportedMeshCount,
      material_count: stats.materialCount,
      triangle_count: stats.triangleCount,
      embedded_texture_count: stats.textureCount,
      content_groups: [...MODULE_CONSTANTS.REQUIRED_GROUPS],
      group_mesh_counts: { ...stats.groupCounts },
      character_excluded: true,
      preview_helpers_excluded: true,
    },
    connectors: CONNECTORS_SPEC,
    furniture_and_material_parity: furnitureParity,
    rendering_profile: {
      camera_projection: 'orthographic',
      recommended_position: [...CAMERA_PRESETS[0].position],
      recommended_target: [...CAMERA_PRESETS[0].target],
      recommended_zoom: CAMERA_PRESETS[0].zoom,
      orthographic_near: 0.5,
      orthographic_far: 48.0,
      shadow_map_size: [1024, 1024],
      shadow_bias: -0.0008,
      shadow_normal_bias: 0.035,
      tone_mapping: 'ACESFilmicToneMapping',
      tone_mapping_exposure: 0.96,
      output_color_space: 'SRGBColorSpace',
      texture_filtering: 'THREE.NearestFilter (crisp pixel-art)',
      polygon_offset_surfaces: [
        'Floor_Center_Woven_Rug (polygonOffsetFactor: -1, polygonOffsetUnits: -2)',
        'Contact_Shadow_* (polygonOffsetFactor: -1, polygonOffsetUnits: -2, depthWrite: false)',
      ],
      runtime_viewer_dependencies: [
        'glTF 2.0 does not serialize Three.js Material.polygonOffset parameters; host runtime should re-apply polygonOffset (-1, -2) to Floor_Center_Woven_Rug and Contact_Shadow_* meshes or preserve their physical Y elevation offset (already separated at Y >= 0.004..0.025).',
        'Set magFilter and minFilter to THREE.NearestFilter on imported textures to preserve crisp pixel-art texel edges.',
        'Directional key light shadow bias (-0.0008) and normalBias (0.035) with orthographic near=0.5 / far=48 prevent shadow acne on thin voxel trims.',
      ],
    },
    animation_inventory: {
      embedded_clips_count: 0,
      note: 'pm_room.glb is a static architectural and furniture module (0 embedded clips). Character animations belong to boss_pm.glb and BossPMCharacterSystem.ts.',
    },
    validation_status: validationStatus,
    known_limitations: [
      'Scene lights, OrbitControls, orthographic camera, and RoomEnvironment IBL are runtime viewer components and are intentionally excluded from pm_room.glb.',
      'Three.js polygonOffset material properties are runtime renderer state and not part of the glTF 2.0 specification; however, all floor rugs, mats, and decals are also physically separated in Y elevation so they do not Z-fight in standard glTF viewers.',
    ],
    provenance: {
      author_tool: 'AI Office Modular Room Lab (Three.js GLTFExporter)',
      visual_source_of_truth: 'Human Owner Approved Google AI Studio PM & Strategy Room V1',
      license: 'Internal AI Office Project Asset — All Rights Reserved by Project Owner',
    },
  };
}

export function buildPMRoomAnchorsJsonV1(
  anchors: Record<AnchorId, ActivityAnchor> = DEFAULT_ACTIVITY_ANCHORS,
  waypoints: WalkWaypoint[] = ROOM_WALK_WAYPOINTS
): PMRoomAnchorsJsonV1 {
  const furnitureByAnchor: Record<AnchorId, string | null> = {
    SPAWN_POINT: 'CONNECTOR_B_SOUTH',
    ROOM_IDLE_POSITION: 'PM_Area_Rug',
    PM_DESK_APPROACH: 'PM_Executive_Chair',
    PM_DESK_WORK_POSITION: 'PM_Executive_Desk',
    PM_CHAIR_POSITION: 'PM_Executive_Chair',
    MEETING_TABLE_APPROACH: 'PM_Collaboration_Table',
    MEETING_SEAT_POSITION: 'PM_Collaboration_Table',
    PRESENTATION_BOARD_POSITION: 'PM_Strategy_Board',
    BOOKSHELF_POSITION: 'PM_Tall_Bookcase',
    COFFEE_BREAK_POSITION: 'PM_Corner_Credenza',
  };

  const nonBlockingIds = new Set(['PM_Area_Rug', 'PM_Strategy_Board', 'PM_Executive_Chair']);

  return {
    schema_version: 'AI_OFFICE_ROOM_ANCHORS_V1',
    room_asset_id: 'ai_office.room.pm_strategy.v1',
    room_module_id: MODULE_CONSTANTS.MODULE_ID,
    coordinate_convention: {
      up_axis: 'Y',
      floor_elevation_y: 0,
      room_origin: [0, 0, 0],
      facing_convention:
        '0 rad = North (+Z), +PI/2 = East (+X), PI = South (-Z), -PI/2 = West (-X)',
    },
    spawn_anchor_id: 'SPAWN_POINT',
    default_idle_anchor_id: 'ROOM_IDLE_POSITION',
    connectors: CONNECTORS_SPEC,
    anchors: (Object.keys(anchors) as AnchorId[]).map((id) => {
      const a = anchors[id];
      const fx = Number(Math.sin(a.facingRad).toFixed(4));
      const fz = Number(Math.cos(a.facingRad).toFixed(4));
      return {
        id: a.id,
        room_module_id: MODULE_CONSTANTS.MODULE_ID,
        label: a.label,
        world_position: [...a.position],
        local_position: [...a.position],
        facing_rad: Number(a.facingRad.toFixed(4)),
        facing_deg: Math.round(((a.facingRad * 180) / Math.PI + 360) % 360),
        forward_vector: [fx, 0, fz],
        activity_role: a.associatedAction,
        posture: a.posture,
        approach_anchor_id: a.approachAnchorId ?? null,
        associated_furniture_id: furnitureByAnchor[id] ?? null,
        character_compatibility: [
          'ai_office.character.boss_pm_room_native.v1',
          'character_lab_imported_glb_1.72u',
        ],
        description: a.description,
      };
    }),
    navigation_waypoints: waypoints.map((wp) => ({
      id: wp.id,
      world_position: [wp.position[0], 0, wp.position[1]],
      neighbors: [...wp.neighbors],
      obstacle_clear: true,
    })),
    patrol_anchor_sequence: [...PATROL_ANCHOR_SEQUENCE],
    obstacle_footprint_catalog: FURNITURE_CATALOG.map((item) => ({
      furniture_id: item.id,
      name: item.name,
      center_xz: [item.position[0], item.position[2]],
      size_xz: [item.dimensions[0], item.dimensions[2]],
      blocks_navigation: !nonBlockingIds.has(item.id),
    })),
  };
}

export function buildBossPMManifestV1(params: {
  glbSizeBytes: number;
  glbSha256: string;
  sourceTotalMeshes: number;
  exportedVisibleMeshes: number;
  materialNames: string[];
  localBounds: {
    min: [number, number, number];
    max: [number, number, number];
    size: [number, number, number];
  };
  clips: Array<{
    name: string;
    duration: number;
    trackCount: number;
    targetedPivots: string[];
  }>;
  validationStatus?: 'PASS' | 'FAIL' | 'NOT_VERIFIED';
  exportDate?: string;
}): BossPMManifestV1 {
  const {
    glbSizeBytes,
    glbSha256,
    sourceTotalMeshes,
    exportedVisibleMeshes,
    materialNames,
    localBounds,
    clips,
    validationStatus = 'PASS',
    exportDate = new Date().toISOString(),
  } = params;

  const rawHeight = Number(localBounds.size[1].toFixed(3));
  const targetHeight = MODULE_CONSTANTS.CHARACTER_REFERENCE_HEIGHT;
  const appliedScale = Number((targetHeight / rawHeight).toFixed(4));

  return {
    schema_version: 'AI_OFFICE_ASSET_MANIFEST_V1',
    asset_id: 'ai_office.character.boss_pm_room_native.v1',
    legacy_asset_id: 'AI_OFFICE_ORIGINAL_BOSS_PM_v1',
    asset_version: HANDOFF_PACKAGE_VERSION,
    asset_kind: 'character',
    role_classification: 'ROOM_NATIVE_EXPORT_CANDIDATE',
    canonical_character_lab_notice:
      'Preserves the approved room-native cozy voxel Boss PM as an integration candidate. Does not silently replace Character Lab as the canonical character-production pipeline.',
    source_project_name: 'ai-office-modular-room-lab',
    source_revision: 'NOT AVAILABLE (Google AI Studio Build Sandbox)',
    export_date: exportDate,
    file_inventory: {
      glb: {
        filename: PRODUCTION_FILENAMES.CHARACTER_GLB,
        relative_path: './boss_pm.glb',
        size_bytes: glbSizeBytes,
        sha256: glbSha256,
      },
      manifest: {
        filename: PRODUCTION_FILENAMES.CHARACTER_MANIFEST,
        relative_path: './boss_pm.manifest.json',
      },
      behavior: {
        filename: PRODUCTION_FILENAMES.CHARACTER_BEHAVIOR,
        relative_path: './boss_pm.behavior.json',
      },
      preview: {
        filename: PRODUCTION_FILENAMES.CHARACTER_PREVIEW,
        relative_path: './boss_pm.preview.png',
      },
      readme: {
        filename: PRODUCTION_FILENAMES.CHARACTER_README,
        relative_path: './README.md',
      },
    },
    coordinate_and_scale_contract: {
      up_axis: 'Y',
      handedness: 'right-handed',
      character_origin: [0, 0, 0],
      origin_convention: 'Feet contact point flush with floor plane Y = 0.000',
      local_forward: [0, 0, 1],
      raw_height_units: rawHeight,
      calibrated_height_units: targetHeight,
      applied_scale_factor: appliedScale,
      separate_from_room_root: true,
    },
    measured_bounds: {
      local_min: localBounds.min,
      local_max: localBounds.max,
      size: localBounds.size,
    },
    geometry_and_material_summary: {
      source_hierarchy_total_meshes: sourceTotalMeshes,
      exported_rest_pose_visible_meshes: exportedVisibleMeshes,
      contextual_handheld_prop_meshes_in_source: Math.max(
        0,
        sourceTotalMeshes - exportedVisibleMeshes
      ),
      mesh_count_difference_explanation:
        'Source hierarchy contains 46 total meshes: 41 permanent body/suit/head/hair/glasses meshes visible in the default standing rest pose, plus 5 contextual handheld prop meshes (Binder_Cover, Binder_Pages, Executive_Smartphone_Prop, Coffee_Mug_Body, Coffee_Mug_Sleeve) that are hidden in rest pose so they do not overlap the hands in static glTF viewers.',
      material_count: materialNames.length,
      material_names: materialNames,
      has_skinned_skeleton: false,
      articulated_pivot_groups: [
        'Hips',
        'Torso',
        'Head',
        'LeftArm',
        'RightArm',
        'LeftLeg',
        'RightLeg',
      ],
      visual_identity_checklist: {
        blocky_voxel_silhouette: true,
        geometric_dark_hairstyle: true,
        rectangular_black_sunglasses: true,
        black_suit_jacket: true,
        white_inner_shirt: true,
        red_necktie: true,
        ear_sideburn_temple_separation_preserved: true,
        torso_z_layering_preserved: true,
      },
    },
    animation_inventory: {
      embedded_gltf_clip_count: clips.length,
      clips: clips.map((c) => ({
        name: c.name,
        duration_seconds: c.duration,
        track_count: c.trackCount,
        targeted_pivots: c.targetedPivots,
        classification: 'EMBEDDED_GLTF_CLIP',
      })),
    },
    validation_status: validationStatus,
    known_limitations: [
      'Uses hierarchical pivot node animation (Hips, Torso, Head, LeftArm, RightArm, LeftLeg, RightLeg) rather than a deformed SkinnedMesh skeleton, preserving crisp voxel block geometry without vertex stretching.',
      'Contextual handheld props (strategy binder, smartphone, coffee mug), waypoint navigation, seated height offset (-0.16u), and interactive speech/approval bubbles are driven by the companion procedural controller (BossPMCharacterSystem.ts) as documented in boss_pm.behavior.json.',
    ],
    provenance: {
      author_tool: 'AI Office Modular Room Lab (Three.js GLTFExporter)',
      visual_source_of_truth: 'Room-Native Cozy Handcrafted Voxel Boss PM V1',
      license: 'Internal AI Office Project Asset — All Rights Reserved by Project Owner',
    },
  };
}

export function buildBossPMBehaviorJsonV1(
  clips: Array<{
    name: string;
    duration: number;
    trackCount: number;
    targetedPivots: string[];
  }>,
  actions: PMActionDefinition[] = PM_DEMO_ACTIONS,
  anchors: Record<AnchorId, ActivityAnchor> = DEFAULT_ACTIVITY_ANCHORS
): BossPMBehaviorJsonV1 {
  const clipByName = new Map(clips.map((c) => [c.name, c]));

  const proceduralRoleByAction: Record<PMActionId, string> = {
    idle: 'Plays embedded Idle_Breathing clip at ROOM_IDLE_POSITION; hides handheld props.',
    patrol:
      'Routes character along ROOM_WALK_WAYPOINTS across PATROL_ANCHOR_SEQUENCE while playing embedded Walk_Cycle clip and smoothly interpolating OrientationRoot.rotation.y.',
    work_desk:
      'Walks via PM_DESK_APPROACH to PM_DESK_WORK_POSITION, aligns facing West (-PI/2), plays embedded Work_Typing clip (which lowers Hips to Y=0.56 and bends legs/arms for typing).',
    meeting_briefing:
      'Walks via MEETING_TABLE_APPROACH to MEETING_SEAT_POSITION, aligns facing West, plays embedded Meeting_Briefing clip, and displays briefing speech bubble.',
    present_board:
      'Walks to PRESENTATION_BOARD_POSITION facing North (0 rad), plays embedded Present_Board clip, highlights PM_Strategy_Board, and shows sprint presentation speech bubble.',
    read_document:
      'Walks to BOOKSHELF_POSITION facing North, plays embedded Read_Document clip, and activates Open_Strategy_Binder_Prop in LeftArm.',
    think_plan:
      'In-place state transition; plays embedded Think_Plan clip (hand-to-chin pose) and displays planning thought bubble.',
    phone_call:
      'In-place state transition; plays embedded Phone_Call clip, activates Executive_Smartphone_Prop in RightArm, and displays phone call speech bubble.',
    coffee_break:
      'Walks to COFFEE_BREAK_POSITION facing SW (-2.15 rad), plays embedded Coffee_Break clip, and activates Warm_Ceramic_Coffee_Cup_Prop in RightArm.',
    waiting_approval:
      'In-place state transition; plays embedded Waiting_Approval clip and displays interactive approval request banner until user clicks Approve.',
    task_completed:
      'Plays embedded Task_Completed celebratory gesture clip for 3.2 seconds and then transitions back to IDLE.',
  };

  return {
    schema_version: 'AI_OFFICE_CHARACTER_BEHAVIOR_V1',
    character_asset_id: 'ai_office.character.boss_pm_room_native.v1',
    compatible_room_asset_id: 'ai_office.room.pm_strategy.v1',
    simulation_mode: 'VISUAL_DEMONSTRATION_ONLY',
    source_controller_modules: [
      'src/three/BossPMCharacterSystem.ts',
      'src/domain/pmSimulationSpec.ts',
      'src/components/ModularRoomCanvas.tsx',
    ],
    articulated_hierarchy_contract: {
      root_node: 'Original_Boss_PM_Root',
      hips_pivot: 'Hips',
      torso_pivot: 'Torso',
      head_pivot: 'Head',
      left_arm_pivot: 'LeftArm',
      right_arm_pivot: 'RightArm',
      left_leg_pivot: 'LeftLeg',
      right_leg_pivot: 'RightLeg',
      contextual_prop_nodes: {
        read_document: 'Open_Strategy_Binder_Prop',
        phone_call: 'Executive_Smartphone_Prop',
        coffee_break: 'Warm_Ceramic_Coffee_Cup_Prop',
      },
    },
    activity_states: actions.map((act) => {
      const clip = clipByName.get(act.clipName);
      const anchor = act.targetAnchorId ? anchors[act.targetAnchorId] : null;
      const propsActivated: string[] = [];
      if (act.id === 'read_document') propsActivated.push('Open_Strategy_Binder_Prop');
      if (act.id === 'phone_call') propsActivated.push('Executive_Smartphone_Prop');
      if (act.id === 'coffee_break') propsActivated.push('Warm_Ceramic_Coffee_Cup_Prop');

      return {
        state_id: act.targetState,
        action_id: act.id,
        action_code: act.code,
        label_id: act.labelId,
        label_en: act.labelEn,
        export_classification: 'HYBRID',
        standalone_clip_classification: 'EMBEDDED_GLTF_CLIP',
        embedded_clip_name: act.clipName,
        clip_duration_seconds: clip?.duration ?? 2.0,
        clip_track_count: clip?.trackCount ?? 3,
        procedural_controller_role: proceduralRoleByAction[act.id],
        target_anchor_id: act.targetAnchorId,
        requires_waypoint_walk: act.requiresWalk,
        posture: anchor?.posture ?? 'standing',
        seated_y_offset: anchor?.posture === 'seated' ? -0.16 : 0,
        contextual_props_activated: propsActivated,
        speech_bubble: act.speechBubble ?? null,
        thought_bubble: act.thoughtBubble ?? null,
      };
    }),
    auto_demo_sequence: [...AUTO_DEMO_SEQUENCE],
  };
}

export function buildRoomReadmeMarkdown(manifest: PMRoomManifestV1): string {
  return `# Deliverable A — PM & Strategy Room Production Asset Pack (V1)

## Asset Overview
- **Asset ID**: \`${manifest.asset_id}\` (\`${manifest.legacy_module_id}\`)
- **Version**: \`${manifest.asset_version}\`
- **Export Date**: \`${manifest.export_date}\`
- **Validation Status**: \`${manifest.validation_status}\`

## Package Contents
1. \`pm_room.glb\` — Standalone binary glTF 2.0 room module (${manifest.file_inventory.glb.size_bytes.toLocaleString()} bytes · SHA-256: \`${manifest.file_inventory.glb.sha256}\`). Strictly excludes the Boss PM character, cameras, lights, and debug helpers.
2. \`pm_room.manifest.json\` — Machine-readable coordinate, scale, connector, material parity, and rendering profile contract.
3. \`pm_room.anchors.json\` — Validated world/local transforms for all 10 activity anchors, 12 walkable navigation waypoints, EAST/SOUTH modular connectors, and obstacle bounds.
4. \`pm_room.preview.png\` — Isometric preview render of the approved PM & Strategy Room.
5. \`README.md\` — Integration and rendering notes.

## Coordinate & Modular Snap Contract
- **Up Axis**: \`+Y\` (right-handed Three.js world space)
- **Floor Elevation**: \`Y = 0.000\` (structural subbase \`Y = -0.160 .. 0.000\`)
- **SW Corner Origin**: \`[0, 0, 0]\` (never recentered; footprint spans \`X = [0..8]\`, \`Z = [0..8]\`, height \`Y = [-0.16..3.20]\`)
- **East Connector (\`CONNECTOR_EAST\`)**: \`[8, 0, 4]\`, normal \`[+1, 0, 0]\`, width \`2.0u\`, removable node \`Connector_East_Removable_Doorway\`
- **South Connector (\`CONNECTOR_SOUTH\`)**: \`[4, 0, 0]\`, normal \`[0, 0, -1]\`, width \`2.0u\`, removable node \`Connector_South_Removable_Threshold\`

## Recommended Host Rendering Profile
- **Camera**: Orthographic isometric (\`position: [13.6, 11.2, -5.6]\`, \`target: [4.0, 1.15, 4.0]\`, \`near: 0.5\`, \`far: 48.0\`)
- **Shadows**: Directional key light at \`[9.5, 14.0, 2.0]\` with \`shadow.bias = -0.0008\`, \`shadow.normalBias = 0.035\`
- **Textures**: Set \`magFilter = THREE.NearestFilter\` and \`minFilter = THREE.NearestFilter\` on imported textures for crisp pixel-art fidelity.
`;
}

export function buildCharacterReadmeMarkdown(manifest: BossPMManifestV1): string {
  return `# Deliverable B — Room-Native Boss PM Export Candidate (V1)

## Asset Overview
- **Asset ID**: \`${manifest.asset_id}\` (\`${manifest.legacy_asset_id}\`)
- **Role**: \`${manifest.role_classification}\`
- **Version**: \`${manifest.asset_version}\`
- **Export Date**: \`${manifest.export_date}\`
- **Validation Status**: \`${manifest.validation_status}\`

> **Canonical Pipeline Notice**: ${manifest.canonical_character_lab_notice}

## Package Contents
1. \`boss_pm.glb\` — Standalone binary glTF 2.0 character model (${manifest.file_inventory.glb.size_bytes.toLocaleString()} bytes · SHA-256: \`${manifest.file_inventory.glb.sha256}\`) containing ${manifest.geometry_and_material_summary.exported_rest_pose_visible_meshes} standing rest-pose voxel meshes and ${manifest.animation_inventory.embedded_gltf_clip_count} embedded keyframe \`AnimationClip\`s.
2. \`boss_pm.manifest.json\` — Machine-readable scale, bounds, material, and animation clip inventory.
3. \`boss_pm.behavior.json\` — Mapping of all 11 PM activity states to embedded glTF clips, procedural waypoint navigation, anchors, postures, and contextual props.
4. \`boss_pm.preview.png\` — Close-up preview render of the Room-Native Boss PM character.
5. \`README.md\` — Integration and animation notes.

## Coordinate, Origin & Animation Contract
- **Origin**: \`[0, 0, 0]\` at feet floor contact (\`minY = 0.000\`)
- **Forward Axis**: \`+Z\` (\`[0, 0, 1]\`)
- **Height**: \`${manifest.coordinate_and_scale_contract.raw_height_units}u\` raw (\`1.72u\` calibrated target height, scale factor \`×${manifest.coordinate_and_scale_contract.applied_scale_factor}\`)
- **Embedded Animation Clips (${manifest.animation_inventory.embedded_gltf_clip_count})**:
${manifest.animation_inventory.clips
  .map((c) => `  - \`${c.name}\` (${c.duration_seconds}s · ${c.track_count} keyframe tracks)`)
  .join('\n')}
`;
}

export function buildValidationReadmeMarkdown(): string {
  return `# Validation Reports — Independent GLB Round-Trip & Visual Stability (V1)

- \`roundtrip-report.json\` — Automated independent binary export + \`GLTFLoader.parseAsync()\` re-import verification report for both \`pm_room.glb\` and \`boss_pm.glb\`, including the 19-point validation matrix.
- \`visual-stability-report.json\` — Coplanar surface, duplicate mesh, camera frustum depth precision (\`near=0.5, far=48\`), and shadow bias (\`-0.0008 / 0.035\`) verification report confirming zero Z-fighting across cabinets, walls, windows, and Boss PM ears/glasses/sideburns.
`;
}

export function buildSourceReadmeMarkdown(sourceFileCount: number): string {
  return `# Deliverable C — Full Source Project Archive (\`modular-room-lab-source.zip\`)

## Overview
\`modular-room-lab-source.zip\` contains the **${sourceFileCount} actual source files** of the AI Office Modular Room Lab project (React 19 + TypeScript + Three.js + Vite), including:
- \`src/three/RoomArchitectureBuilder.ts\` — 8×8 PM Room architectural shell, walls, windows, pilasters, trims, and EAST/SOUTH connectors.
- \`src/three/FurnitureLibraryBuilder.ts\` — All 12 approved PM Room furniture items, strategy board, bookcase, wardrobe, credenza, executive desk, props, and decorations.
- \`src/three/PixelMaterialLibrary.ts\` — Procedural pixel-art CanvasTextures and glTF-compatible \`THREE.MeshStandardMaterial\` definitions.
- \`src/three/BossPMCharacterSystem.ts\` — Original Room-Native Voxel Boss PM generator, 11 embedded keyframe \`AnimationClip\`s, and procedural runtime controller.
- \`src/domain/modularRoomSpec.ts\` & \`src/domain/pmSimulationSpec.ts\` — Coordinate specifications, anchors, Dijkstra waypoint pathfinding, and unit tests.
- \`src/export/*\` — Production asset pack exporters, manifest builders, and independent GLB round-trip validator.
- \`src/components/*\` & \`src/App.tsx\` — Interactive 3D isometric viewport, simulation controls, and Asset Export & Integration Handoff UI.

## Running Locally
\`\`\`bash
npm install
npm run dev
\`\`\`

## Running Unit & Round-Trip Verification Tests
\`\`\`bash
npx tsx --test src/domain/modularRoomSpec.test.ts src/domain/pmSimulationSpec.test.ts src/export/exportPipeline.test.ts
\`\`\`

## Native Google AI Studio Build Export
In addition to downloading \`modular-room-lab-source.zip\` directly from the in-app **Asset Export & Integration Handoff** panel, the Project Owner can also use Google AI Studio Build's native **Download Code / Export to ZIP / GitHub** action in the top studio toolbar at any time. No API keys or secrets are packaged in this archive.
`;
}
