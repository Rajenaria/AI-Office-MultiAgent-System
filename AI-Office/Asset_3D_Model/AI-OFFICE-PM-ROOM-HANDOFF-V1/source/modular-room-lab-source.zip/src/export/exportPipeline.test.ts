import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildBossPMBehaviorJsonV1,
  buildBossPMManifestV1,
  buildPMRoomAnchorsJsonV1,
  computeSha256Hex,
  createZipArchive,
} from './AssetManifestBuilder';
import {
  DEFAULT_ACTIVITY_ANCHORS,
  PM_DEMO_ACTIONS,
  ROOM_WALK_WAYPOINTS,
} from '../domain/pmSimulationSpec';
import { exportOriginalBossPMToGLBBuffer } from '../three/BossPMCharacterSystem';
import { inspectOriginalBossPMForExport } from './CharacterExporter';
import { parseAndValidateCharacterGLBBuffer } from './AssetValidation';

test('computeSha256Hex computes accurate 64-character SHA-256 hex digest', async () => {
  const bytes = new TextEncoder().encode('AI-OFFICE-PM-ROOM-HANDOFF-V1');
  const sha = await computeSha256Hex(bytes);
  assert.equal(sha.length, 64);
  assert.match(sha, /^[0-9a-f]{64}$/);
});

test('createZipArchive produces valid PKZIP archive with local and central directory headers', () => {
  const archive = createZipArchive([
    { path: 'room-pack/README.md', data: '# PM Room Pack\n' },
    { path: 'room-pack/data.json', data: JSON.stringify({ ok: true }) },
  ]);
  assert.ok(archive.byteLength > 100);
  // PK\x03\x04 local file header magic
  assert.equal(archive[0], 0x50);
  assert.equal(archive[1], 0x4b);
  assert.equal(archive[2], 0x03);
  assert.equal(archive[3], 0x04);
});

test('buildPMRoomAnchorsJsonV1 and buildBossPMBehaviorJsonV1 include all anchors and 11 activities', () => {
  const anchorsJson = buildPMRoomAnchorsJsonV1(DEFAULT_ACTIVITY_ANCHORS, ROOM_WALK_WAYPOINTS);
  assert.equal(anchorsJson.room_asset_id, 'ai_office.room.pm_strategy.v1');
  assert.equal(anchorsJson.anchors.length, 10);
  assert.equal(anchorsJson.navigation_waypoints.length, 12);

  const inspected = inspectOriginalBossPMForExport();
  const behaviorJson = buildBossPMBehaviorJsonV1(
    inspected.clips,
    PM_DEMO_ACTIONS,
    DEFAULT_ACTIVITY_ANCHORS
  );
  assert.equal(behaviorJson.character_asset_id, 'ai_office.character.boss_pm_room_native.v1');
  assert.equal(behaviorJson.activity_states.length, 11);
  assert.ok(
    behaviorJson.activity_states.some((s) => s.embedded_clip_name === 'Idle_Breathing')
  );
  assert.ok(behaviorJson.activity_states.some((s) => s.embedded_clip_name === 'Walk_Cycle'));
});

test('Original Boss PM exports to binary GLB and passes independent GLTFLoader round-trip validation', async () => {
  // Minimal browser FileReader polyfill for Three.js GLTFExporter in Node test environment
  if (typeof globalThis.FileReader === 'undefined') {
    class NodeFileReaderPolyfill {
      result: ArrayBuffer | string | null = null;
      onloadend: (() => void) | null = null;
      onload: (() => void) | null = null;
      onerror: ((err: unknown) => void) | null = null;
      readAsArrayBuffer(blob: Blob) {
        blob
          .arrayBuffer()
          .then((buf) => {
            this.result = buf;
            if (this.onload) this.onload();
            if (this.onloadend) this.onloadend();
          })
          .catch((err) => {
            if (this.onerror) this.onerror(err);
          });
      }
      readAsDataURL(blob: Blob) {
        blob
          .arrayBuffer()
          .then((buf) => {
            const b64 = Buffer.from(buf).toString('base64');
            this.result = `data:${blob.type || 'application/octet-stream'};base64,${b64}`;
            if (this.onload) this.onload();
            if (this.onloadend) this.onloadend();
          })
          .catch((err) => {
            if (this.onerror) this.onerror(err);
          });
      }
    }
    (globalThis as unknown as { FileReader: unknown }).FileReader = NodeFileReaderPolyfill;
  }

  const inspection = inspectOriginalBossPMForExport();
  assert.equal(inspection.sourceTotalMeshes, 46);
  assert.equal(inspection.exportedVisibleMeshes, 41);
  assert.equal(inspection.clips.length, 11);

  const glbBuffer = await exportOriginalBossPMToGLBBuffer();
  assert.ok(glbBuffer.byteLength > 20000);

  const sha = await computeSha256Hex(glbBuffer);
  const manifest = buildBossPMManifestV1({
    glbSizeBytes: glbBuffer.byteLength,
    glbSha256: sha,
    sourceTotalMeshes: inspection.sourceTotalMeshes,
    exportedVisibleMeshes: inspection.exportedVisibleMeshes,
    materialNames: inspection.materialNames,
    localBounds: inspection.localBounds,
    clips: inspection.clips,
    validationStatus: 'PASS',
  });
  assert.equal(manifest.geometry_and_material_summary.source_hierarchy_total_meshes, 46);
  assert.equal(manifest.geometry_and_material_summary.exported_rest_pose_visible_meshes, 41);
  assert.equal(manifest.animation_inventory.embedded_gltf_clip_count, 11);

  const reimported = await parseAndValidateCharacterGLBBuffer(
    glbBuffer,
    inspection.sourceTotalMeshes
  );
  assert.equal(reimported.report.loadSuccess, true);
  assert.equal(reimported.report.importedMeshCount, 41);
  assert.equal(reimported.report.embeddedClipsVerified.count, 11);
  assert.equal(reimported.report.feetGroundedAtZero, true);
  assert.equal(reimported.report.heightMatchesSpec, true);
  assert.equal(reimported.report.roomGeometryExcluded, true);
});
