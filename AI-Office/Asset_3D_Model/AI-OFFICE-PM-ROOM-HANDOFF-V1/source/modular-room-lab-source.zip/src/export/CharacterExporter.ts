import * as THREE from 'three';
import {
  ActivityAnchor,
  AnchorId,
  DEFAULT_ACTIVITY_ANCHORS,
  PM_DEMO_ACTIONS,
} from '../domain/pmSimulationSpec';
import {
  buildOriginalRoomNativeBossPMSceneAndClips,
  exportOriginalBossPMToGLBBuffer,
} from '../three/BossPMCharacterSystem';
import {
  triggerBinaryDownload,
  triggerDataUrlDownload,
  triggerJsonDownload,
} from '../three/RoomExportAndImportManager';
import {
  BossPMBehaviorJsonV1,
  BossPMManifestV1,
  PRODUCTION_FILENAMES,
  buildBossPMBehaviorJsonV1,
  buildBossPMManifestV1,
  buildCharacterReadmeMarkdown,
  computeSha256Hex,
  createZipArchive,
} from './AssetManifestBuilder';
import { dataUrlToUint8Array } from './RoomExporter';

export interface CharacterExportCandidatePackResult {
  glbBuffer: ArrayBuffer;
  glbSizeBytes: number;
  glbSha256: string;
  sourceTotalMeshes: number;
  exportedVisibleMeshes: number;
  materialNames: string[];
  localBounds: {
    min: [number, number, number];
    max: [number, number, number];
    size: [number, number, number];
  };
  clips: Array<{
    name: string;
    duration: number;
    trackCount: number;
    targetedPivots: string[];
  }>;
  manifest: BossPMManifestV1;
  behaviorJson: BossPMBehaviorJsonV1;
  readmeMarkdown: string;
  previewDataUrl: string | null;
}

/**
 * Inspects the Original Room-Native Boss PM scene and animation clips to record
 * exact mesh counts, material names, bounding box, and embedded keyframe clip details.
 */
export function inspectOriginalBossPMForExport(): {
  sourceTotalMeshes: number;
  exportedVisibleMeshes: number;
  materialNames: string[];
  localBounds: {
    min: [number, number, number];
    max: [number, number, number];
    size: [number, number, number];
  };
  clips: Array<{
    name: string;
    duration: number;
    trackCount: number;
    targetedPivots: string[];
  }>;
} {
  const { scene, animations } = buildOriginalRoomNativeBossPMSceneAndClips();
  scene.updateMatrixWorld(true);

  let sourceTotalMeshes = 0;
  let exportedVisibleMeshes = 0;
  const materialNameSet = new Set<string>();

  const isVisibleInHierarchy = (obj: THREE.Object3D): boolean => {
    let curr: THREE.Object3D | null = obj;
    while (curr) {
      if (!curr.visible) return false;
      curr = curr.parent;
    }
    return true;
  };

  scene.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      sourceTotalMeshes++;
      if (isVisibleInHierarchy(obj)) {
        exportedVisibleMeshes++;
      }
      const m = obj as THREE.Mesh;
      const mats = Array.isArray(m.material) ? m.material : [m.material];
      for (const mat of mats) {
        if (mat) materialNameSet.add(mat.name || mat.type);
      }
    }
  });

  const box = new THREE.Box3().setFromObject(scene);
  const size = new THREE.Vector3();
  box.getSize(size);

  const clips = animations.map((clip) => {
    const pivots = new Set<string>();
    for (const track of clip.tracks) {
      const dotIdx = track.name.indexOf('.');
      const nodeName = dotIdx > 0 ? track.name.slice(0, dotIdx) : track.name;
      pivots.add(nodeName);
    }
    return {
      name: clip.name,
      duration: Number(clip.duration.toFixed(2)),
      trackCount: clip.tracks.length,
      targetedPivots: Array.from(pivots),
    };
  });

  return {
    sourceTotalMeshes,
    exportedVisibleMeshes,
    materialNames: Array.from(materialNameSet),
    localBounds: {
      min: [
        Number(box.min.x.toFixed(3)),
        Number(box.min.y.toFixed(3)),
        Number(box.min.z.toFixed(3)),
      ],
      max: [
        Number(box.max.x.toFixed(3)),
        Number(box.max.y.toFixed(3)),
        Number(box.max.z.toFixed(3)),
      ],
      size: [
        Number(size.x.toFixed(3)),
        Number(size.y.toFixed(3)),
        Number(size.z.toFixed(3)),
      ],
    },
    clips,
  };
}

/**
 * Generates Deliverable B (Room-Native Boss PM Export Candidate Pack).
 */
export async function buildCharacterExportCandidatePack(
  anchors: Record<AnchorId, ActivityAnchor> = DEFAULT_ACTIVITY_ANCHORS,
  previewDataUrl: string | null = null,
  validationStatus: 'PASS' | 'FAIL' | 'NOT_VERIFIED' = 'PASS'
): Promise<CharacterExportCandidatePackResult> {
  const inspected = inspectOriginalBossPMForExport();
  const glbBuffer = await exportOriginalBossPMToGLBBuffer();
  const glbSha256 = await computeSha256Hex(glbBuffer);

  const manifest = buildBossPMManifestV1({
    glbSizeBytes: glbBuffer.byteLength,
    glbSha256,
    sourceTotalMeshes: inspected.sourceTotalMeshes,
    exportedVisibleMeshes: inspected.exportedVisibleMeshes,
    materialNames: inspected.materialNames,
    localBounds: inspected.localBounds,
    clips: inspected.clips,
    validationStatus,
  });

  const behaviorJson = buildBossPMBehaviorJsonV1(inspected.clips, PM_DEMO_ACTIONS, anchors);
  const readmeMarkdown = buildCharacterReadmeMarkdown(manifest);

  return {
    glbBuffer,
    glbSizeBytes: glbBuffer.byteLength,
    glbSha256,
    ...inspected,
    manifest,
    behaviorJson,
    readmeMarkdown,
    previewDataUrl,
  };
}

export function downloadCharacterAssetPackZip(
  pack: CharacterExportCandidatePackResult
): {
  filename: string;
  byteLength: number;
} {
  const prefix = 'production/characters/boss_pm_room_native';
  const entries = [
    {
      path: `${prefix}/${PRODUCTION_FILENAMES.CHARACTER_GLB}`,
      data: pack.glbBuffer,
    },
    {
      path: `${prefix}/${PRODUCTION_FILENAMES.CHARACTER_MANIFEST}`,
      data: JSON.stringify(pack.manifest, null, 2),
    },
    {
      path: `${prefix}/${PRODUCTION_FILENAMES.CHARACTER_BEHAVIOR}`,
      data: JSON.stringify(pack.behaviorJson, null, 2),
    },
    {
      path: `${prefix}/${PRODUCTION_FILENAMES.CHARACTER_README}`,
      data: pack.readmeMarkdown,
    },
  ];

  if (pack.previewDataUrl) {
    entries.push({
      path: `${prefix}/${PRODUCTION_FILENAMES.CHARACTER_PREVIEW}`,
      data: dataUrlToUint8Array(pack.previewDataUrl),
    });
  }

  const zipBytes = createZipArchive(entries);
  const filename = 'boss_pm_export_candidate_v1.zip';
  triggerBinaryDownload(zipBytes.buffer as ArrayBuffer, filename, 'application/zip');
  return { filename, byteLength: zipBytes.byteLength };
}

export function downloadCharacterManifestAndBehavior(
  manifest: BossPMManifestV1,
  behaviorJson: BossPMBehaviorJsonV1
): void {
  triggerJsonDownload(manifest, PRODUCTION_FILENAMES.CHARACTER_MANIFEST);
  setTimeout(() => {
    triggerJsonDownload(behaviorJson, PRODUCTION_FILENAMES.CHARACTER_BEHAVIOR);
  }, 180);
}

export function downloadCharacterPreviewPng(dataUrl: string): void {
  triggerDataUrlDownload(dataUrl, PRODUCTION_FILENAMES.CHARACTER_PREVIEW);
}
