import * as THREE from 'three';

export type VisualStyleMode = 'reference' | 'clean' | 'pixel';

export interface MaterialLibraryInstance {
  materials: Record<string, THREE.MeshStandardMaterial>;
  textures: Record<string, THREE.CanvasTexture>;
  setVisualMode: (mode: VisualStyleMode, texturesEnabled: boolean) => void;
  dispose: () => void;
}

// Deterministic PRNG so procedural pixel textures are 100% reproducible
function createSeededRandom(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function configurePixelTexture(canvas: HTMLCanvasElement, name: string): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.name = name;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.needsUpdate = true;
  return tex;
}

function createOakFloorTexture(): THREE.CanvasTexture {
  // 256x256 crisp pixel art for the 8x8 floor (32 pixels per world unit)
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = createSeededRandom(4201);

  const plankPalette = [
    '#B0682E',
    '#A35E26',
    '#BC7337',
    '#965320',
    '#B66E32',
    '#8D4B1B',
    '#C27A3E',
  ];
  const grainDark = '#6E3812';
  const grainLight = '#CF8A4E';
  const seamColor = '#47230C';

  ctx.fillStyle = '#A35E26';
  ctx.fillRect(0, 0, size, size);

  const plankHeight = 8; // 32 rows of planks across 8 units
  const numRows = size / plankHeight;

  for (let row = 0; row < numRows; row++) {
    const y = row * plankHeight;
    let x = -Math.floor(rand() * 24);

    while (x < size) {
      const plankLen = 32 + Math.floor(rand() * 3) * 16; // 32, 48, or 64 px
      const baseColor = plankPalette[Math.floor(rand() * plankPalette.length)];

      const drawX = Math.max(0, x);
      const drawW = Math.min(size - drawX, x + plankLen - drawX);

      if (drawW > 0) {
        ctx.fillStyle = baseColor;
        ctx.fillRect(drawX, y, drawW, plankHeight);

        // Top subtle highlight pixel strip
        ctx.fillStyle = grainLight;
        ctx.globalAlpha = 0.25;
        ctx.fillRect(drawX, y + 1, drawW, 1);

        // Intentional pixel grain clusters inside plank
        ctx.globalAlpha = 0.5;
        const grainCount = 2 + Math.floor(rand() * 4);
        for (let g = 0; g < grainCount; g++) {
          const gx = drawX + 2 + Math.floor(rand() * Math.max(1, drawW - 6));
          const gy = y + 2 + Math.floor(rand() * (plankHeight - 3));
          const gw = 3 + Math.floor(rand() * 6);
          ctx.fillStyle = rand() > 0.35 ? grainDark : grainLight;
          ctx.fillRect(gx, gy, Math.min(gw, drawX + drawW - gx), 1);
        }
        ctx.globalAlpha = 1.0;

        // Vertical plank joint seam
        if (x + plankLen < size) {
          ctx.fillStyle = seamColor;
          ctx.fillRect(x + plankLen - 1, y, 1, plankHeight);
        }
      }
      x += plankLen;
    }

    // Horizontal seam between plank rows
    ctx.fillStyle = seamColor;
    ctx.fillRect(0, y + plankHeight - 1, size, 1);
  }

  return configurePixelTexture(canvas, 'Tex_Pixel_Oak_Floor');
}

function createWarmWallTexture(): THREE.CanvasTexture {
  const w = 128;
  const h = 128;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  const rand = createSeededRandom(1337);

  // Stepped cozy warm toasted-beige plaster bands (matching reference walls)
  const bands = [
    { stop: 0, color: '#D6B89C' },
    { stop: 16, color: '#CFB093' },
    { stop: 64, color: '#C8A88A' },
    { stop: 104, color: '#BFA082' },
  ];

  for (let i = 0; i < bands.length; i++) {
    const nextStop = i + 1 < bands.length ? bands[i + 1].stop : h;
    ctx.fillStyle = bands[i].color;
    ctx.fillRect(0, bands[i].stop, w, nextStop - bands[i].stop);
  }

  // Subtle pixel plaster dither clusters
  ctx.fillStyle = '#B59476';
  for (let i = 0; i < 90; i++) {
    const px = Math.floor(rand() * w);
    const py = Math.floor(rand() * h);
    ctx.fillRect(px, py, 2, 1);
  }

  return configurePixelTexture(canvas, 'Tex_Pixel_Warm_Wall');
}

function createWindowVistaTexture(): THREE.CanvasTexture {
  const w = 96;
  const h = 96;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // Crisp pixel daylight sky
  ctx.fillStyle = '#8CC8F6';
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = '#A8D8FA';
  ctx.fillRect(0, 28, w, h - 28);
  ctx.fillStyle = '#C4E6FC';
  ctx.fillRect(0, 56, w, h - 56);

  // Pixel clouds
  ctx.fillStyle = '#F7FBFF';
  ctx.fillRect(14, 14, 28, 8);
  ctx.fillRect(20, 10, 16, 4);
  ctx.fillRect(56, 22, 24, 6);
  ctx.fillRect(60, 18, 14, 4);

  // Distant balcony railing (like reference window)
  ctx.fillStyle = '#BCCCE0';
  ctx.fillRect(0, 62, w, 4);
  ctx.fillRect(0, 84, w, 6);
  for (let bx = 4; bx < w; bx += 8) {
    ctx.fillRect(bx, 66, 3, 18);
  }

  // Sunlit green pixel foliage clusters on sides of window
  const greens = ['#4A8F30', '#63B042', '#7EC850', '#387322'];
  const leaves = [
    [0, 36, 18, 28, 0],
    [4, 24, 14, 16, 1],
    [6, 42, 16, 18, 2],
    [76, 30, 20, 34, 0],
    [72, 44, 18, 22, 1],
    [78, 20, 18, 16, 2],
    [16, 68, 24, 20, 3],
  ];
  for (const [lx, ly, lw, lh, ci] of leaves) {
    ctx.fillStyle = greens[ci];
    ctx.fillRect(lx, ly, lw, lh);
  }

  return configurePixelTexture(canvas, 'Tex_Pixel_Window_Vista');
}

function createStrategyBoardTexture(): THREE.CanvasTexture {
  const w = 160;
  const h = 96;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // Porcelain off-white board surface
  ctx.fillStyle = '#F7F4EE';
  ctx.fillRect(0, 0, w, h);

  // Subtle pixel grid
  ctx.fillStyle = '#E6E0D5';
  for (let gx = 8; gx < w; gx += 8) {
    ctx.fillRect(gx, 0, 1, h);
  }
  for (let gy = 8; gy < h; gy += 8) {
    ctx.fillRect(0, gy, w, 1);
  }

  // Top header bar (AI Office Roadmap & Sprint Columns)
  ctx.fillStyle = '#35435A';
  ctx.fillRect(6, 6, w - 12, 12);

  // Header status blocks
  const colColors = ['#D97757', '#E5A93C', '#4D9B82', '#5B7BA6'];
  const colWidth = 34;
  for (let c = 0; c < 4; c++) {
    const cx = 8 + c * (colWidth + 3);
    ctx.fillStyle = colColors[c];
    ctx.fillRect(cx, 8, 24, 8);

    // Column divider line
    if (c > 0) {
      ctx.fillStyle = '#CFC7B8';
      ctx.fillRect(cx - 2, 20, 1, 48);
    }
  }

  // Bottom Gantt / Milestone timeline section
  ctx.fillStyle = '#EAE3D7';
  ctx.fillRect(6, 70, w - 12, 20);
  ctx.fillStyle = '#5B7BA6';
  ctx.fillRect(12, 74, 42, 4);
  ctx.fillStyle = '#4D9B82';
  ctx.fillRect(48, 80, 56, 4);
  ctx.fillStyle = '#D97757';
  ctx.fillRect(96, 74, 48, 4);

  return configurePixelTexture(canvas, 'Tex_Pixel_Strategy_Board');
}

function createMonitorScreenTexture(): THREE.CanvasTexture {
  const w = 96;
  const h = 64;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // Crisp pixel desktop / PM workspace UI matching reference blue monitor
  ctx.fillStyle = '#2B5B84';
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = '#3B78A8';
  ctx.fillRect(2, 2, w - 4, h - 8);

  // Left sidebar
  ctx.fillStyle = '#1E3F5C';
  ctx.fillRect(4, 4, 20, h - 12);
  ctx.fillStyle = '#6CC2F7';
  ctx.fillRect(7, 8, 14, 3);
  ctx.fillRect(7, 14, 11, 3);
  ctx.fillRect(7, 20, 13, 3);

  // Main PM Roadmap window
  ctx.fillStyle = '#F4F6F8';
  ctx.fillRect(27, 6, 63, 44);
  ctx.fillStyle = '#E26D5C';
  ctx.fillRect(31, 12, 24, 5);
  ctx.fillStyle = '#F2B84B';
  ctx.fillRect(42, 21, 30, 5);
  ctx.fillStyle = '#52B788';
  ctx.fillRect(55, 30, 28, 5);
  ctx.fillStyle = '#4EA8DE';
  ctx.fillRect(31, 39, 38, 5);

  // Bottom taskbar
  ctx.fillStyle = '#19324A';
  ctx.fillRect(0, h - 6, w, 6);

  return configurePixelTexture(canvas, 'Tex_Pixel_Monitor_UI');
}

function createWovenRugTexture(): THREE.CanvasTexture {
  const w = 128;
  const h = 128;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  const rand = createSeededRandom(9001);

  // Deep slate-indigo rug matching the reference room's central rug!
  ctx.fillStyle = '#3B4F73';
  ctx.fillRect(0, 0, w, h);

  // Outer dark navy border
  ctx.fillStyle = '#2A3956';
  ctx.fillRect(0, 0, w, 6);
  ctx.fillRect(0, h - 6, w, 6);
  ctx.fillRect(0, 0, 6, h);
  ctx.fillRect(w - 6, 0, 6, h);

  // Inner warm cream/amber pixel trim line
  ctx.fillStyle = '#C9B38C';
  ctx.fillRect(8, 8, w - 16, 2);
  ctx.fillRect(8, h - 10, w - 16, 2);
  ctx.fillRect(8, 8, 2, h - 16);
  ctx.fillRect(w - 10, 8, 2, h - 16);

  // Subtle woven pixel texture inside
  for (let y = 12; y < h - 12; y += 2) {
    for (let x = 12; x < w - 12; x += 2) {
      if (rand() > 0.65) {
        ctx.fillStyle = rand() > 0.5 ? '#435980' : '#334566';
        ctx.fillRect(x, y, 2, 1);
      }
    }
  }

  return configurePixelTexture(canvas, 'Tex_Pixel_Woven_Rug');
}

function createPosterArtTexture(variant: 1 | 2): THREE.CanvasTexture {
  const w = 48;
  const h = 64;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // White mat board
  ctx.fillStyle = '#F5EFE6';
  ctx.fillRect(0, 0, w, h);

  if (variant === 1) {
    // Warm sunset strategy poster (like the left poster in reference)
    ctx.fillStyle = '#2B3A55';
    ctx.fillRect(4, 4, w - 8, h - 8);
    ctx.fillStyle = '#E05A47';
    ctx.fillRect(10, 12, 28, 22);
    ctx.fillStyle = '#F4B942';
    ctx.fillRect(16, 18, 16, 16);
    ctx.fillStyle = '#E8D7C3';
    ctx.fillRect(8, 40, 32, 14);
  } else {
    // Cool sky & golden geometric poster (like the right poster in reference)
    ctx.fillStyle = '#4A90C2';
    ctx.fillRect(4, 4, w - 8, h - 8);
    ctx.fillStyle = '#F7F3E9';
    ctx.fillRect(12, 10, 24, 18);
    ctx.fillStyle = '#F2A93B';
    ctx.fillRect(8, 32, 32, 20);
    ctx.fillStyle = '#D96B43';
    ctx.fillRect(14, 38, 20, 10);
  }

  return configurePixelTexture(canvas, `Tex_Pixel_Poster_${variant}`);
}

export function createPixelMaterialLibrary(): MaterialLibraryInstance {
  const textures: Record<string, THREE.CanvasTexture> = {
    oakFloor: createOakFloorTexture(),
    warmWall: createWarmWallTexture(),
    windowVista: createWindowVistaTexture(),
    strategyBoard: createStrategyBoardTexture(),
    monitorUI: createMonitorScreenTexture(),
    wovenRug: createWovenRugTexture(),
    poster1: createPosterArtTexture(1),
    poster2: createPosterArtTexture(2),
  };

  const materials: Record<string, THREE.MeshStandardMaterial> = {
    oakFloor: new THREE.MeshStandardMaterial({
      name: 'Mat_Oak_Plank_Floor',
      color: 0xffffff,
      map: textures.oakFloor,
      roughness: 0.72,
      metalness: 0.04,
    }),
    floorSubbase: new THREE.MeshStandardMaterial({
      name: 'Mat_Floor_Subbase_Dark',
      color: 0x3b2d26,
      roughness: 0.88,
      metalness: 0.02,
    }),
    warmWall: new THREE.MeshStandardMaterial({
      name: 'Mat_Painted_Beige_Wall',
      color: 0xffffff,
      map: textures.warmWall,
      roughness: 0.85,
      metalness: 0.02,
    }),
    wallExterior: new THREE.MeshStandardMaterial({
      name: 'Mat_Wall_Exterior_Casing',
      color: 0x56443a,
      roughness: 0.85,
      metalness: 0.02,
    }),
    wallCapDark: new THREE.MeshStandardMaterial({
      name: 'Mat_Wall_Cutaway_TopCap',
      color: 0x3d2e27,
      roughness: 0.8,
      metalness: 0.05,
    }),
    woodTrim: new THREE.MeshStandardMaterial({
      name: 'Mat_Muted_Brown_Trim',
      color: 0x69452c,
      roughness: 0.68,
      metalness: 0.05,
    }),
    warmOakWood: new THREE.MeshStandardMaterial({
      name: 'Mat_Warm_Oak_Furniture',
      color: 0xc87d40,
      roughness: 0.58,
      metalness: 0.06,
    }),
    honeyOakLight: new THREE.MeshStandardMaterial({
      name: 'Mat_Honey_Oak_Light',
      color: 0xd99252,
      roughness: 0.55,
      metalness: 0.05,
    }),
    darkWalnutWood: new THREE.MeshStandardMaterial({
      name: 'Mat_Dark_Walnut_Wood',
      color: 0x7a4424,
      roughness: 0.52,
      metalness: 0.08,
    }),
    espressoWood: new THREE.MeshStandardMaterial({
      name: 'Mat_Espresso_Cabinet_Wood',
      color: 0x4f2c18,
      roughness: 0.6,
      metalness: 0.06,
    }),
    windowFrameCream: new THREE.MeshStandardMaterial({
      name: 'Mat_Window_Frame_Cream',
      color: 0xd0c0ae,
      roughness: 0.68,
      metalness: 0.04,
    }),
    windowVista: new THREE.MeshStandardMaterial({
      name: 'Mat_Window_Daylight_Vista',
      color: 0xffffff,
      map: textures.windowVista,
      emissive: new THREE.Color(0x90caf9),
      emissiveMap: textures.windowVista,
      emissiveIntensity: 0.1,
      roughness: 0.55,
      metalness: 0.0,
    }),
    windowGlass: new THREE.MeshStandardMaterial({
      name: 'Mat_Window_Glass_Pane',
      color: 0xcceeff,
      transparent: true,
      opacity: 0.18,
      roughness: 0.2,
      metalness: 0.08,
      depthWrite: false,
    }),
    sofaCocoaFabric: new THREE.MeshStandardMaterial({
      name: 'Mat_Sofa_Cocoa_Fabric',
      color: 0x5c4338,
      roughness: 0.88,
      metalness: 0.02,
    }),
    sofaCushionLight: new THREE.MeshStandardMaterial({
      name: 'Mat_Sofa_Cushion_Warm',
      color: 0x6e5246,
      roughness: 0.86,
      metalness: 0.02,
    }),
    chairSlateFabric: new THREE.MeshStandardMaterial({
      name: 'Mat_Chair_Slate_Fabric',
      color: 0x4a5d75,
      roughness: 0.84,
      metalness: 0.03,
    }),
    executiveLeather: new THREE.MeshStandardMaterial({
      name: 'Mat_Executive_Chair_Leather',
      color: 0x47362e,
      roughness: 0.45,
      metalness: 0.1,
    }),
    wovenRug: new THREE.MeshStandardMaterial({
      name: 'Mat_Woven_Area_Rug',
      color: 0xffffff,
      map: textures.wovenRug,
      roughness: 0.92,
      metalness: 0.0,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    }),
    darkMetal: new THREE.MeshStandardMaterial({
      name: 'Mat_Dark_Architectural_Metal',
      color: 0x2c3038,
      roughness: 0.38,
      metalness: 0.24,
    }),
    brushedBrass: new THREE.MeshStandardMaterial({
      name: 'Mat_Brushed_Brass_Accent',
      color: 0xd4a84f,
      roughness: 0.32,
      metalness: 0.25,
    }),
    chromeSilver: new THREE.MeshStandardMaterial({
      name: 'Mat_Brushed_Silver_Metal',
      color: 0xb8c0c8,
      roughness: 0.3,
      metalness: 0.25,
    }),
    strategyBoardSurface: new THREE.MeshStandardMaterial({
      name: 'Mat_Strategy_Board_Canvas',
      color: 0xffffff,
      map: textures.strategyBoard,
      roughness: 0.42,
      metalness: 0.04,
    }),
    monitorScreen: new THREE.MeshStandardMaterial({
      name: 'Mat_Monitor_Screen_UI',
      color: 0xffffff,
      map: textures.monitorUI,
      emissive: new THREE.Color(0x4ea8de),
      emissiveMap: textures.monitorUI,
      emissiveIntensity: 0.28,
      roughness: 0.25,
      metalness: 0.08,
    }),
    paperCream: new THREE.MeshStandardMaterial({
      name: 'Mat_Cream_Paper_Stack',
      color: 0xf4efe6,
      roughness: 0.85,
      metalness: 0.0,
    }),
    noteCoral: new THREE.MeshStandardMaterial({
      name: 'Mat_Sticky_Note_Coral',
      color: 0xe06d53,
      roughness: 0.78,
      metalness: 0.0,
    }),
    noteAmber: new THREE.MeshStandardMaterial({
      name: 'Mat_Sticky_Note_Amber',
      color: 0xebb349,
      roughness: 0.78,
      metalness: 0.0,
    }),
    noteSage: new THREE.MeshStandardMaterial({
      name: 'Mat_Sticky_Note_Sage',
      color: 0x5ca87c,
      roughness: 0.78,
      metalness: 0.0,
    }),
    noteSky: new THREE.MeshStandardMaterial({
      name: 'Mat_Sticky_Note_Sky',
      color: 0x5c9bd6,
      roughness: 0.78,
      metalness: 0.0,
    }),
    plantFoliageDark: new THREE.MeshStandardMaterial({
      name: 'Mat_Plant_Foliage_Deep',
      color: 0x3b7a34,
      roughness: 0.75,
      metalness: 0.02,
    }),
    plantFoliageMid: new THREE.MeshStandardMaterial({
      name: 'Mat_Plant_Foliage_Mid',
      color: 0x569e46,
      roughness: 0.72,
      metalness: 0.02,
    }),
    plantFoliageBright: new THREE.MeshStandardMaterial({
      name: 'Mat_Plant_Foliage_Highlight',
      color: 0x76c258,
      roughness: 0.7,
      metalness: 0.02,
    }),
    terracottaPot: new THREE.MeshStandardMaterial({
      name: 'Mat_Terracotta_Planter',
      color: 0xc2653c,
      roughness: 0.76,
      metalness: 0.02,
    }),
    ceramicCream: new THREE.MeshStandardMaterial({
      name: 'Mat_Ceramic_Cream_Mug',
      color: 0xf2ece1,
      roughness: 0.35,
      metalness: 0.05,
    }),
    lampShadeWarm: new THREE.MeshStandardMaterial({
      name: 'Mat_Warm_Lamp_Shade',
      color: 0xf5deb3,
      emissive: new THREE.Color(0xf59e0b),
      emissiveIntensity: 0.18,
      roughness: 0.68,
      metalness: 0.0,
    }),
    contactShadow: new THREE.MeshStandardMaterial({
      name: 'Mat_Baked_Contact_Shadow',
      color: 0x241308,
      transparent: true,
      opacity: 0.32,
      roughness: 0.95,
      metalness: 0.0,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -2,
    }),
    posterArt1: new THREE.MeshStandardMaterial({
      name: 'Mat_Framed_Poster_Sunset',
      color: 0xffffff,
      map: textures.poster1,
      roughness: 0.55,
      metalness: 0.02,
    }),
    posterArt2: new THREE.MeshStandardMaterial({
      name: 'Mat_Framed_Poster_Isometric',
      color: 0xffffff,
      map: textures.poster2,
      roughness: 0.55,
      metalness: 0.02,
    }),
    connectorFrame: new THREE.MeshStandardMaterial({
      name: 'Mat_Modular_Connector_Threshold',
      color: 0x8c5832,
      roughness: 0.62,
      metalness: 0.08,
    }),
  };

  // Store original maps and colors for mode switching
  const originalMaps = new Map<THREE.MeshStandardMaterial, THREE.Texture | null>();
  const originalColors = new Map<THREE.MeshStandardMaterial, number>();
  const cleanClayColors: Record<string, number> = {
    oakFloor: 0xc2834b,
    warmWall: 0xe4d2be,
    windowVista: 0xbee3f8,
    strategyBoardSurface: 0xf5f2eb,
    monitorScreen: 0x3b78a8,
    wovenRug: 0x3b4f73,
    posterArt1: 0xd96b43,
    posterArt2: 0x4a90c2,
  };

  Object.entries(materials).forEach(([key, mat]) => {
    originalMaps.set(mat, mat.map);
    originalColors.set(mat, mat.color.getHex());
    if (cleanClayColors[key]) {
      mat.userData.cleanColor = cleanClayColors[key];
    }
  });

  const setVisualMode = (mode: VisualStyleMode, texturesEnabled: boolean) => {
    const showMaps = mode !== 'clean' && texturesEnabled;
    Object.entries(materials).forEach(([key, mat]) => {
      const origMap = originalMaps.get(mat) ?? null;
      if (origMap) {
        mat.map = showMaps ? origMap : null;
        if (!showMaps && cleanClayColors[key]) {
          mat.color.setHex(cleanClayColors[key]);
        } else {
          mat.color.setHex(originalColors.get(mat) ?? 0xffffff);
        }
      }
      if (mode === 'pixel') {
        mat.roughness = Math.min(0.95, (mat.roughness || 0.6) + 0.08);
      }
      mat.needsUpdate = true;
    });
  };

  const dispose = () => {
    Object.values(materials).forEach((m) => m.dispose());
    Object.values(textures).forEach((t) => t.dispose());
  };

  return {
    materials,
    textures,
    setVisualMode,
    dispose,
  };
}
