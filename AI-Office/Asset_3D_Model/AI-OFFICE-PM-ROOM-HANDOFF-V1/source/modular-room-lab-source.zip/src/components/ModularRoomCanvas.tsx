import React, { useEffect, useImperativeHandle, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  CAMERA_PRESETS,
  FURNITURE_CATALOG,
  FurnitureCatalogItem,
  MODULE_CONSTANTS,
  RoomExportStats,
  generateRoomManifest,
} from '../domain/modularRoomSpec';
import {
  AUTO_DEMO_SEQUENCE,
  ActivityAnchor,
  AnchorId,
  CharacterSourceType,
  DEFAULT_ACTIVITY_ANCHORS,
  GLBInspectionReport,
  PATROL_ANCHOR_SEQUENCE,
  PMActionDefinition,
  PMActionId,
  PMAgentStateId,
  PM_DEMO_ACTIONS,
  buildSimulationExportConfig,
  findWalkablePath,
  shortestAngleDelta,
} from '../domain/pmSimulationSpec';
import {
  MaterialLibraryInstance,
  VisualStyleMode,
  createPixelMaterialLibrary,
} from '../three/PixelMaterialLibrary';
import { buildRoomArchitecture } from '../three/RoomArchitectureBuilder';
import {
  buildPMRoomFurnitureAndProps,
  buildScaleMannequin,
} from '../three/FurnitureLibraryBuilder';
import {
  ImportValidationReport,
  buildNeighborAssemblyPlaceholders,
  exportRoomToGLBBuffer,
  measureRoomStats,
  parseAndValidateGLBBuffer,
  triggerBinaryDownload,
  triggerDataUrlDownload,
  triggerJsonDownload,
} from '../three/RoomExportAndImportManager';
import {
  BossPMRuntimeInstance,
  ORIGINAL_PM_EXPORT_FILENAME,
  buildSimulationHelpersGroup,
  createOriginalRoomNativeBossPMRuntime,
  exportOriginalBossPMToGLBBuffer,
  loadBossPMFromBrowserFile,
  tryLoadFixedProjectCharacterAsset,
} from '../three/BossPMCharacterSystem';
import { PRODUCTION_FILENAMES } from '../export/AssetManifestBuilder';
import {
  IndependentRoundTripReportV1,
  runFullIndependentRoundTripSuite,
} from '../export/AssetValidation';
import {
  CharacterExportCandidatePackResult,
  buildCharacterExportCandidatePack,
} from '../export/CharacterExporter';
import {
  RoomProductionAssetPackResult,
  buildRoomProductionAssetPack,
} from '../export/RoomExporter';

export interface ViewerDisplayConfig {
  workspaceMode: 'builder' | 'import_test';
  importTestTarget?: 'room_only' | 'character_only' | 'both_reimported';
  visualStyle: VisualStyleMode;
  showGrid: boolean;
  autoCutawayWalls: boolean;
  showWallsAndWindows: boolean;
  showFurniture: boolean;
  showPropsAndDecor: boolean;
  showMannequin: boolean;
  showTextures: boolean;
  showShadows: boolean;
  showWireframe: boolean;
  showNeighborAssembly: boolean;
  showBossPM: boolean;
  showSimulationAnchors: boolean;
  showNavigationPath: boolean;
  followPMCamera: boolean;
  selectedCatalogId: string | null;
  isolatedCatalogId: string | null;
  hiddenCatalogIds: string[];
}

export interface ClickedMeshDiagnostic {
  meshName: string;
  materialName: string;
  materialType: string;
  parentName: string;
  worldPosition: [number, number, number];
}

export interface VisualStabilityDiagnosticReport {
  timestamp: string;
  totalRoomMeshes: number;
  totalCharacterMeshes: number;
  duplicateRoomMeshNames: string[];
  duplicateCharacterMeshNames: string[];
  coplanarConflictCount: number;
  cameraNearFar: [number, number];
  shadowBias: number;
  shadowNormalBias: number;
  verifiedAreas: Array<{
    area: string;
    status: 'STABLE' | 'WARNING';
    detail: string;
  }>;
}

export interface SelectedObjectInspection {
  catalogItem: FurnitureCatalogItem;
  meshCount: number;
  triangleCount: number;
  clickedMeshName?: string;
  clickedMaterialName?: string;
  clickedMaterialType?: string;
  worldBox: {
    min: [number, number, number];
    max: [number, number, number];
    size: [number, number, number];
  };
}

export interface PMSimulationRuntimeTelemetry {
  loaded: boolean;
  loadError: string | null;
  selectedCharacterSource: CharacterSourceType;
  activeCharacterSource: CharacterSourceType;
  hasImportedGLB: boolean;
  importedGLBFilename: string | null;
  currentActionId: PMActionId;
  currentActionDef: PMActionDefinition;
  currentState: PMAgentStateId;
  isWalking: boolean;
  isPaused: boolean;
  speedMultiplier: 0.5 | 1 | 1.5;
  patrolActive: boolean;
  autoDemoActive: boolean;
  autoDemoStepIndex: number;
  autoDemoStepTitle: string | null;
  currentAnchorId: AnchorId | null;
  targetAnchorId: AnchorId | null;
  worldPosition: [number, number, number];
  facingDeg: number;
  activeClipName: string;
  capabilityMode: string;
  scaleMultiplier: number;
  forwardOffsetDeg: number;
  isPMSelected: boolean;
  overheadScreenPos: {
    x: number;
    y: number;
    visible: boolean;
  };
}

export interface ModularRoomCanvasHandle {
  setCameraPreset: (presetId: string) => void;
  resetCamera: () => void;
  fitRoom: () => void;
  zoomBy: (factor: number) => void;
  orbitBy: (deltaAzimuthRad: number, deltaPolarRad?: number) => void;
  inspectCatalogItem: (catalogId: string) => SelectedObjectInspection | null;
  exportGLB: () => Promise<{ filename: string; byteLength: number }>;
  exportOriginalPMGLB: () => Promise<{ filename: string; byteLength: number }>;
  exportManifest: () => { filename: string };
  exportPreviewPNG: () => Promise<{ filename: string; dataUrl: string }>;
  exportCharacterPreviewPNG: () => Promise<{ filename: string; dataUrl: string }>;
  runImportValidation: () => Promise<ImportValidationReport>;
  runFullHandoffValidation: (sourceFileCount?: number) => Promise<IndependentRoundTripReportV1>;
  exportRoomProductionPack: () => Promise<RoomProductionAssetPackResult>;
  exportCharacterCandidatePack: () => Promise<CharacterExportCandidatePackResult>;
  // Boss PM Simulation & Dual Character Source Controls
  setCharacterSource: (source: CharacterSourceType) => void;
  triggerPMAction: (actionId: PMActionId) => void;
  setSimulationPlayback: (
    command: 'play' | 'pause' | 'resume' | 'stop' | 'reset_position' | 'reset_pose'
  ) => void;
  setSimulationSpeed: (speed: 0.5 | 1 | 1.5) => void;
  startAutoDemo: () => void;
  stopAutoDemo: () => void;
  approvePendingTask: () => void;
  focusCameraOnPM: () => void;
  returnToRoomView: () => void;
  loadCustomBossPMFile: (file: File) => Promise<GLBInspectionReport>;
  reloadDefaultBossPMAsset: () => Promise<GLBInspectionReport | null>;
  setCharacterScaleMultiplier: (multiplier: number) => void;
  setCharacterForwardOffsetDeg: (deg: number) => void;
  teleportPMToAnchor: (anchorId: AnchorId) => void;
  exportSimulationConfig: () => { filename: string };
  runVisualStabilityScan: () => VisualStabilityDiagnosticReport;
}

interface ModularRoomCanvasProps {
  config: ViewerDisplayConfig;
  activePresetId: string;
  anchors: Record<AnchorId, ActivityAnchor>;
  selectedAnchorId: AnchorId | null;
  onSelectCatalogItem: (catalogId: string | null, details: SelectedObjectInspection | null) => void;
  onStatsReady: (stats: RoomExportStats) => void;
  onImportReportReady: (report: ImportValidationReport) => void;
  onRoundTripReportReady?: (report: IndependentRoundTripReportV1) => void;
  onPresetChange: (presetId: string) => void;
  onPMRuntimeStateChange: (telemetry: PMSimulationRuntimeTelemetry) => void;
  onGLBInspectionReady: (report: GLBInspectionReport | null) => void;
  onPMCharacterSelectChange: (selected: boolean) => void;
  onMeshDiagnosticSelect?: (diag: ClickedMeshDiagnostic | null) => void;
  onDropGLBFile?: (file: File) => void;
}

export const ModularRoomCanvas = React.forwardRef<ModularRoomCanvasHandle, ModularRoomCanvasProps>(
  (
    {
      config,
      anchors,
      selectedAnchorId,
      onSelectCatalogItem,
      onStatsReady,
      onImportReportReady,
      onRoundTripReportReady,
      onPresetChange,
      onPMRuntimeStateChange,
      onGLBInspectionReady,
      onPMCharacterSelectChange,
      onMeshDiagnosticSelect,
      onDropGLBFile,
    },
    ref
  ) => {
    const mountRef = useRef<HTMLDivElement | null>(null);
    const configRef = useRef<ViewerDisplayConfig>(config);
    configRef.current = config;

    const anchorsRef = useRef<Record<AnchorId, ActivityAnchor>>(anchors);
    anchorsRef.current = anchors;

    const selectedAnchorIdRef = useRef<AnchorId | null>(selectedAnchorId);
    selectedAnchorIdRef.current = selectedAnchorId;

    const callbacksRef = useRef({
      onSelectCatalogItem,
      onStatsReady,
      onImportReportReady,
      onRoundTripReportReady,
      onPresetChange,
      onPMRuntimeStateChange,
      onGLBInspectionReady,
      onPMCharacterSelectChange,
      onMeshDiagnosticSelect,
      onDropGLBFile,
    });
    callbacksRef.current = {
      onSelectCatalogItem,
      onStatsReady,
      onImportReportReady,
      onRoundTripReportReady,
      onPresetChange,
      onPMRuntimeStateChange,
      onGLBInspectionReady,
      onPMCharacterSelectChange,
      onMeshDiagnosticSelect,
      onDropGLBFile,
    };

    const engineRef = useRef<{
      renderer: THREE.WebGLRenderer;
      scene: THREE.Scene;
      camera: THREE.OrthographicCamera;
      controls: OrbitControls;
      roomRoot: THREE.Group;
      importedRootHolder: THREE.Group;
      importedRoomHolder: THREE.Group;
      importedCharacterHolder: THREE.Group;
      setImportedCharacterMixer: (mixer: THREE.AnimationMixer | null) => void;
      neighborAssemblyGroup: THREE.Group;
      previewHelpersGroup: THREE.Group;
      gridHelperGroup: THREE.Group;
      mannequinGroup: THREE.Group;
      selectionBoxHelper: THREE.BoxHelper;
      matLib: MaterialLibraryInstance;
      groups: Record<(typeof MODULE_CONSTANTS.REQUIRED_GROUPS)[number], THREE.Group>;
      northWallNodes: THREE.Object3D[];
      westWallNodes: THREE.Object3D[];
      catalogNodeMap: Map<string, THREE.Object3D>;
      keyLight: THREE.DirectionalLight;
      requestRender: () => void;
      startCameraTransition: (pos: [number, number, number], target: [number, number, number], zoom: number) => void;
      updateVisibilityFromConfig: () => void;
      computeObjectInspection: (catalogId: string) => SelectedObjectInspection | null;
      lastExportedBuffer: ArrayBuffer | null;
      // Simulation state & methods
      getBossPMInstance: () => BossPMRuntimeInstance | null;
      getSelectedCharacterSource: () => CharacterSourceType;
      setCharacterSource: (source: CharacterSourceType) => void;
      mountImportedBossPMInstance: (instance: BossPMRuntimeInstance, autoSelect?: boolean) => void;
      setLoadError: (err: string | null) => void;
      triggerPMAction: (actionId: PMActionId, fromAutoDemo?: boolean) => void;
      setSimulationPlayback: (
        command: 'play' | 'pause' | 'resume' | 'stop' | 'reset_position' | 'reset_pose'
      ) => void;
      setSimulationSpeed: (speed: 0.5 | 1 | 1.5) => void;
      startAutoDemo: () => void;
      stopAutoDemo: () => void;
      approvePendingTask: () => void;
      focusCameraOnPM: () => void;
      returnToRoomView: () => void;
      teleportPMToAnchor: (anchorId: AnchorId) => void;
      syncAnchorsOverlay: () => void;
      runVisualStabilityScan: () => VisualStabilityDiagnosticReport;
    } | null>(null);

    useEffect(() => {
      const container = mountRef.current;
      if (!container) return;

      // 1. Detect software WebGL (SwiftShader / llvmpipe) per threejs skill
      const isSoftwareGl = (() => {
        const probeCanvas = document.createElement('canvas');
        const gl = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      })();

      const width = container.clientWidth || 1280;
      const height = container.clientHeight || 800;

      const renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
        preserveDrawingBuffer: true,
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 0.96;
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
      renderer.setSize(width, height);
      renderer.shadowMap.enabled = !isSoftwareGl && configRef.current.showShadows;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;

      container.innerHTML = '';
      container.appendChild(renderer.domElement);

      // 2. Scene & Environment
      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x2c2d35);

      const pmremGenerator = new THREE.PMREMGenerator(renderer);
      scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
      pmremGenerator.dispose();

      // 3. Orthographic Camera (true isometric projection with tight near/far planes for high depth precision)
      const frustumHalf = 600;
      const aspect = width / height;
      const camera = new THREE.OrthographicCamera(
        (-frustumHalf * aspect) / 100,
        (frustumHalf * aspect) / 100,
        frustumHalf / 100,
        -frustumHalf / 100,
        0.5,
        48
      );
      const defaultPreset = CAMERA_PRESETS[0];
      camera.position.set(...defaultPreset.position);
      camera.zoom = defaultPreset.zoom / 68;
      camera.updateProjectionMatrix();

      // 4. OrbitControls
      const controls = new OrbitControls(camera, renderer.domElement);
      controls.target.set(...defaultPreset.target);
      controls.enableDamping = !isSoftwareGl;
      controls.dampingFactor = 0.08;
      controls.maxPolarAngle = Math.PI / 2 - 0.03;
      controls.minPolarAngle = 0.05;
      controls.minZoom = 0.45;
      controls.maxZoom = 4.5;
      controls.update();

      // 5. Studio Cozy Lighting Rig (calibrated shadow bias & normalBias prevent shadow acne on thin voxel trims)
      const hemiLight = new THREE.HemisphereLight(0xfff6e8, 0x5c4738, 0.82);
      hemiLight.position.set(4, 10, 4);
      scene.add(hemiLight);

      const keyLight = new THREE.DirectionalLight(0xfff0d4, 1.55);
      keyLight.position.set(9.5, 14.0, 2.0);
      keyLight.target.position.set(4.0, 0.5, 4.0);
      keyLight.castShadow = !isSoftwareGl;
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 2.0;
      keyLight.shadow.camera.far = 28.0;
      keyLight.shadow.camera.left = -6.2;
      keyLight.shadow.camera.right = 6.2;
      keyLight.shadow.camera.top = 6.2;
      keyLight.shadow.camera.bottom = -6.2;
      keyLight.shadow.bias = -0.0008;
      keyLight.shadow.normalBias = 0.035;
      scene.add(keyLight);
      scene.add(keyLight.target);

      const fillLight = new THREE.DirectionalLight(0xdbeafe, 0.55);
      fillLight.position.set(-6, 8, -5);
      scene.add(fillLight);

      const deskPointLight = new THREE.PointLight(0xffb75e, 0.85, 4.5, 1.5);
      deskPointLight.position.set(1.35, 1.35, 4.75);
      scene.add(deskPointLight);

      const floorLampPointLight = new THREE.PointLight(0xffbe6b, 0.75, 5.0, 1.5);
      floorLampPointLight.position.set(6.35, 1.55, 6.85);
      scene.add(floorLampPointLight);

      // 6. Build Exportable ROOM_PM_ROOT Hierarchy (100% preserved)
      const roomRoot = new THREE.Group();
      roomRoot.name = MODULE_CONSTANTS.ROOT_NODE_NAME;
      roomRoot.position.set(0, 0, 0);

      const groups = {} as Record<(typeof MODULE_CONSTANTS.REQUIRED_GROUPS)[number], THREE.Group>;
      for (const groupName of MODULE_CONSTANTS.REQUIRED_GROUPS) {
        const g = new THREE.Group();
        g.name = groupName;
        roomRoot.add(g);
        groups[groupName] = g;
      }

      const matLib = createPixelMaterialLibrary();
      const { northWallNodes, westWallNodes } = buildRoomArchitecture(groups, matLib);
      const catalogNodeMap = buildPMRoomFurnitureAndProps(groups, matLib);

      scene.add(roomRoot);

      // 7. Build Preview-Only Overlays (Strictly Excluded from Room GLB Export!)
      const previewHelpersGroup = new THREE.Group();
      previewHelpersGroup.name = 'PREVIEW_ONLY_HELPERS';
      scene.add(previewHelpersGroup);

      const gridHelperGroup = new THREE.Group();
      gridHelperGroup.name = 'PREVIEW_ONLY_MODULAR_GRID';
      const grid = new THREE.GridHelper(8, 8, 0xf59e0b, 0x64748b);
      grid.position.set(4.0, 0.006, 4.0);
      (grid.material as THREE.Material).transparent = true;
      (grid.material as THREE.Material).opacity = 0.45;
      gridHelperGroup.add(grid);

      const originSphere = new THREE.Mesh(
        new THREE.SphereGeometry(0.11, 12, 12),
        new THREE.MeshBasicMaterial({ color: 0xf59e0b })
      );
      originSphere.position.set(0, 0.05, 0);
      gridHelperGroup.add(originSphere);

      const eastConnWire = new THREE.LineSegments(
        new THREE.EdgesGeometry(new THREE.BoxGeometry(1.3, 0.04, 2.0)),
        new THREE.LineBasicMaterial({ color: 0x38bdf8 })
      );
      eastConnWire.position.set(7.35, 0.025, 4.0);
      gridHelperGroup.add(eastConnWire);

      const southConnWire = new THREE.LineSegments(
        new THREE.EdgesGeometry(new THREE.BoxGeometry(2.0, 0.04, 1.35)),
        new THREE.LineBasicMaterial({ color: 0x34d399 })
      );
      southConnWire.position.set(4.0, 0.025, 0.675);
      gridHelperGroup.add(southConnWire);

      previewHelpersGroup.add(gridHelperGroup);

      // Scale Mannequin (1.72u tall)
      const mannequinGroup = buildScaleMannequin();
      mannequinGroup.visible = configRef.current.showMannequin;
      previewHelpersGroup.add(mannequinGroup);

      // Selection Highlight Box
      const dummyBoxMesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1));
      const selectionBoxHelper = new THREE.BoxHelper(dummyBoxMesh, 0xfbbf24);
      selectionBoxHelper.visible = false;
      previewHelpersGroup.add(selectionBoxHelper);

      // Contextual Activity Highlight Helper (e.g. Strategy Board or PM Monitor active outline)
      const activityBoardHighlight = new THREE.LineSegments(
        new THREE.EdgesGeometry(new THREE.BoxGeometry(2.38, 1.42, 0.16)),
        new THREE.LineBasicMaterial({ color: 0xfbbf24 })
      );
      activityBoardHighlight.position.set(5.35, 1.82, 7.66);
      activityBoardHighlight.visible = false;
      previewHelpersGroup.add(activityBoardHighlight);

      // Simulation Helpers Group (ANCHORS + PATH_DEBUG, strictly outside ROOM_PM_ROOT)
      const simHelpers = buildSimulationHelpersGroup(anchorsRef.current, selectedAnchorIdRef.current);
      scene.add(simHelpers.helpersRoot);

      // Holder for Re-Imported GLB Scene & Neighboring Snap Placeholders
      const importedRootHolder = new THREE.Group();
      importedRootHolder.name = 'PREVIEW_ONLY_IMPORTED_GLB_HOLDER';
      importedRootHolder.visible = false;
      scene.add(importedRootHolder);

      const importedRoomHolder = new THREE.Group();
      importedRoomHolder.name = 'REIMPORTED_ROOM_GLB_HOLDER';
      importedRootHolder.add(importedRoomHolder);

      const importedCharacterHolder = new THREE.Group();
      importedCharacterHolder.name = 'REIMPORTED_CHARACTER_GLB_HOLDER';
      importedRootHolder.add(importedCharacterHolder);

      let importedCharacterMixer: THREE.AnimationMixer | null = null;

      const neighborAssemblyGroup = buildNeighborAssemblyPlaceholders();
      neighborAssemblyGroup.visible = false;
      scene.add(neighborAssemblyGroup);

      // Measure initial stats on ROOM_PM_ROOT
      const initialStats = measureRoomStats(roomRoot);
      callbacksRef.current.onStatsReady(initialStats);

      // =========================================================================
      // 8. BOSS PM CHARACTER & LIVING SIMULATION RUNTIME STATE
      //    Primary Default: Original Room-Native Voxel Boss PM
      //    Secondary Optional: Imported GLB Character
      // =========================================================================
      const originalPMInstance = createOriginalRoomNativeBossPMRuntime();
      let importedPMInstance: BossPMRuntimeInstance | null = null;
      let selectedCharacterSource: CharacterSourceType = 'original_pm';
      let bossPM: BossPMRuntimeInstance | null = originalPMInstance;

      let loadError: string | null = null;
      let currentActionId: PMActionId = 'idle';
      let currentState: PMAgentStateId = 'IDLE';
      let isWalking = false;
      let isPaused = false;
      let speedMultiplier: 0.5 | 1 | 1.5 = 1;
      let patrolActive = false;
      let patrolIndex = 0;
      let patrolWaitTimer = 0;
      let autoDemoActive = false;
      let autoDemoStepIndex = 0;
      let autoDemoTimer = 0;
      let taskCompleteReturnTimer = 0;
      let currentAnchorId: AnchorId | null = 'ROOM_IDLE_POSITION';
      let targetAnchorId: AnchorId | null = 'ROOM_IDLE_POSITION';
      let navPath: Array<[number, number]> = [];
      let isPMSelected = false;
      let savedRoomCameraState: {
        pos: THREE.Vector3;
        target: THREE.Vector3;
        zoom: number;
      } | null = null;

      let elapsedSimTime = 0;
      let lastFrameTimestamp = performance.now();

      // Mount Default Original Room-Native Boss PM immediately near the executive workstation
      const initialSpawn = anchorsRef.current.ROOM_IDLE_POSITION || anchorsRef.current.SPAWN_POINT;
      originalPMInstance.navigationRoot.position.set(
        initialSpawn.position[0],
        0,
        initialSpawn.position[2]
      );
      originalPMInstance.orientationRoot.rotation.y = initialSpawn.facingRad;
      originalPMInstance.transitionToActionPose('idle', false, 'standing');
      scene.add(originalPMInstance.runtimeRoot);

      const getActionDef = (id: PMActionId): PMActionDefinition =>
        PM_DEMO_ACTIONS.find((a) => a.id === id) || PM_DEMO_ACTIONS[0];

      const computeOverheadScreenCoords = (): { x: number; y: number; visible: boolean } => {
        if (!bossPM || !bossPM.runtimeRoot.visible) {
          return { x: 0, y: 0, visible: false };
        }
        const worldPos = new THREE.Vector3();
        bossPM.interactionAnchor.getWorldPosition(worldPos);
        const projected = worldPos.clone().project(camera);
        const w = renderer.domElement.clientWidth || width;
        const h = renderer.domElement.clientHeight || height;
        const sx = (projected.x * 0.5 + 0.5) * w;
        const sy = (-(projected.y * 0.5) + 0.5) * h;
        const inBounds = sx >= 20 && sx <= w - 20 && sy >= 20 && sy <= h - 20;
        return {
          x: Math.round(sx),
          y: Math.round(sy),
          visible: inBounds,
        };
      };

      const emitTelemetry = () => {
        const pos: [number, number, number] = bossPM
          ? [
              Number(bossPM.navigationRoot.position.x.toFixed(2)),
              Number(bossPM.navigationRoot.position.y.toFixed(2)),
              Number(bossPM.navigationRoot.position.z.toFixed(2)),
            ]
          : [3.35, 0, 5.15];
        const facingRad = bossPM ? bossPM.orientationRoot.rotation.y : 2.35;
        const facingDeg = Math.round(((facingRad * 180) / Math.PI + 360) % 360);

        callbacksRef.current.onPMRuntimeStateChange({
          loaded: Boolean(bossPM),
          loadError,
          selectedCharacterSource,
          activeCharacterSource: bossPM?.sourceType ?? 'original_pm',
          hasImportedGLB: Boolean(importedPMInstance),
          importedGLBFilename: importedPMInstance?.inspectionReport.assetPathOrName ?? null,
          currentActionId,
          currentActionDef: getActionDef(currentActionId),
          currentState,
          isWalking,
          isPaused,
          speedMultiplier,
          patrolActive,
          autoDemoActive,
          autoDemoStepIndex,
          autoDemoStepTitle: autoDemoActive
            ? AUTO_DEMO_SEQUENCE[autoDemoStepIndex]?.stepTitle ?? null
            : null,
          currentAnchorId,
          targetAnchorId,
          worldPosition: pos,
          facingDeg,
          activeClipName: bossPM ? bossPM.activeClipName : 'None',
          capabilityMode: bossPM ? bossPM.inspectionReport.capabilityMode : 'NONE',
          scaleMultiplier: bossPM ? bossPM.scaleMultiplier : 1.0,
          forwardOffsetDeg: bossPM ? bossPM.forwardOffsetDeg : 0,
          isPMSelected,
          overheadScreenPos: computeOverheadScreenCoords(),
        });
      };

      const updateRoomActivityHighlights = () => {
        // Highlight Strategy Board during PRESENTING
        activityBoardHighlight.visible =
          configRef.current.workspaceMode === 'builder' &&
          configRef.current.showBossPM &&
          !isWalking &&
          currentState === 'PRESENTING';

        // Enhance Monitor & Desk Lamp warmth during WORKING
        if (!isWalking && currentState === 'WORKING') {
          matLib.materials.monitorScreen.emissive.setHex(0x1e40af);
          matLib.materials.monitorScreen.emissiveIntensity = 0.42;
          deskPointLight.intensity = 1.25;
        } else {
          matLib.materials.monitorScreen.emissive.setHex(0x000000);
          matLib.materials.monitorScreen.emissiveIntensity = 0.0;
          deskPointLight.intensity = 0.85;
        }
      };

      const navigateToAnchor = (destAnchorId: AnchorId) => {
        if (!bossPM) return;
        const dest = anchorsRef.current[destAnchorId];
        if (!dest) return;
        targetAnchorId = destAnchorId;

        const curX = bossPM.navigationRoot.position.x;
        const curZ = bossPM.navigationRoot.position.z;
        const dist = Math.hypot(dest.position[0] - curX, dest.position[2] - curZ);

        if (dist <= 0.12) {
          // Already at target anchor!
          bossPM.navigationRoot.position.set(dest.position[0], 0, dest.position[2]);
          bossPM.orientationRoot.rotation.y = dest.facingRad;
          currentAnchorId = destAnchorId;
          navPath = [];
          isWalking = false;
          simHelpers.updatePathVisuals([curX, curZ], []);
          const actDef = getActionDef(currentActionId);
          currentState = actDef.targetState;
          bossPM.transitionToActionPose(currentActionId, false, dest.posture);
          updateRoomActivityHighlights();
          return;
        }

        // Compute obstacle-avoiding path
        const computedPath = findWalkablePath([curX, curZ], [dest.position[0], dest.position[2]]);
        // If destination has an approach anchor and isn't already close to it, route through approach point smoothly
        if (dest.approachAnchorId && anchorsRef.current[dest.approachAnchorId]) {
          const appPos = anchorsRef.current[dest.approachAnchorId].position;
          const dToApp = Math.hypot(appPos[0] - curX, appPos[2] - curZ);
          if (dToApp > 0.25) {
            const pathToApp = findWalkablePath([curX, curZ], [appPos[0], appPos[2]]);
            pathToApp.push([dest.position[0], dest.position[2]]);
            navPath = pathToApp;
          } else {
            navPath = computedPath;
          }
        } else {
          navPath = computedPath;
        }

        isWalking = true;
        currentState = 'MOVING';
        bossPM.transitionToActionPose(currentActionId, true, 'standing');
        simHelpers.updatePathVisuals([curX, curZ], navPath);
        updateRoomActivityHighlights();
      };

      const triggerPMAction = (actionId: PMActionId, fromAutoDemo = false) => {
        if (!fromAutoDemo) {
          autoDemoActive = false;
        }
        isPaused = false;
        taskCompleteReturnTimer = 0;
        currentActionId = actionId;
        const actDef = getActionDef(actionId);

        if (actionId === 'patrol') {
          patrolActive = true;
          patrolWaitTimer = 0;
          const nextAnchor = PATROL_ANCHOR_SEQUENCE[patrolIndex % PATROL_ANCHOR_SEQUENCE.length];
          navigateToAnchor(nextAnchor);
          emitTelemetry();
          requestRender();
          return;
        }

        patrolActive = false;

        if (actDef.requiresWalk && actDef.targetAnchorId) {
          navigateToAnchor(actDef.targetAnchorId);
        } else {
          // Perform action immediately in-place
          navPath = [];
          isWalking = false;
          currentState = actDef.targetState;
          if (bossPM) {
            simHelpers.updatePathVisuals(
              [bossPM.navigationRoot.position.x, bossPM.navigationRoot.position.z],
              []
            );
            const curAnchor = currentAnchorId ? anchorsRef.current[currentAnchorId] : null;
            bossPM.transitionToActionPose(actionId, false, curAnchor?.posture ?? 'standing');
          }
          if (actionId === 'task_completed') {
            taskCompleteReturnTimer = 3.2;
          }
          updateRoomActivityHighlights();
        }

        emitTelemetry();
        requestRender();
      };

      const teleportPMToAnchor = (anchorId: AnchorId) => {
        if (!bossPM) return;
        const anchor = anchorsRef.current[anchorId];
        if (!anchor) return;
        navPath = [];
        isWalking = false;
        currentAnchorId = anchorId;
        targetAnchorId = anchorId;
        bossPM.navigationRoot.position.set(anchor.position[0], 0, anchor.position[2]);
        bossPM.orientationRoot.rotation.y = anchor.facingRad;
        simHelpers.updatePathVisuals([anchor.position[0], anchor.position[2]], []);
        const actDef = getActionDef(currentActionId);
        currentState = actDef.targetState;
        bossPM.transitionToActionPose(currentActionId, false, anchor.posture);
        updateRoomActivityHighlights();
        emitTelemetry();
        requestRender();
      };

      const setCharacterSource = (nextSource: CharacterSourceType) => {
        selectedCharacterSource = nextSource;

        // Determine which character instance should be visible in the 3D room.
        // If 'imported_glb' is selected but no GLB has been imported yet, keep Original PM
        // visible so the scene is never empty and the original character is never deleted.
        const desiredInstance: BossPMRuntimeInstance =
          nextSource === 'imported_glb' && importedPMInstance
            ? importedPMInstance
            : originalPMInstance;

        if (bossPM && bossPM !== desiredInstance) {
          const prevPos = bossPM.navigationRoot.position.clone();
          const prevYaw = bossPM.orientationRoot.rotation.y;
          bossPM.resetPoseToRest();
          bossPM.setHighlighted(false);
          bossPM.runtimeRoot.visible = false;
          scene.remove(bossPM.runtimeRoot);

          bossPM = desiredInstance;
          bossPM.navigationRoot.position.copy(prevPos);
          bossPM.orientationRoot.rotation.y = prevYaw;
          scene.add(bossPM.runtimeRoot);
        } else if (!bossPM) {
          bossPM = desiredInstance;
          scene.add(bossPM.runtimeRoot);
        }

        // Guarantee the non-active character is never in the scene
        if (bossPM === originalPMInstance && importedPMInstance) {
          importedPMInstance.runtimeRoot.visible = false;
          scene.remove(importedPMInstance.runtimeRoot);
        } else if (bossPM === importedPMInstance) {
          originalPMInstance.runtimeRoot.visible = false;
          scene.remove(originalPMInstance.runtimeRoot);
        }

        bossPM.setHighlighted(isPMSelected);
        const curAnchor = currentAnchorId ? anchorsRef.current[currentAnchorId] : null;
        bossPM.transitionToActionPose(currentActionId, isWalking, curAnchor?.posture ?? 'standing');

        callbacksRef.current.onGLBInspectionReady(bossPM.inspectionReport);
        updateVisibilityFromConfig();
        emitTelemetry();
        requestRender();
      };

      const mountImportedBossPMInstance = (
        instance: BossPMRuntimeInstance,
        autoSelect = true
      ) => {
        if (importedPMInstance && importedPMInstance !== instance) {
          importedPMInstance.resetPoseToRest();
          importedPMInstance.runtimeRoot.visible = false;
          scene.remove(importedPMInstance.runtimeRoot);
        }
        importedPMInstance = instance;
        loadError = null;

        // Place at current character position or ROOM_IDLE_POSITION
        const refPos = bossPM
          ? bossPM.navigationRoot.position
          : new THREE.Vector3(initialSpawn.position[0], 0, initialSpawn.position[2]);
        const refYaw = bossPM ? bossPM.orientationRoot.rotation.y : initialSpawn.facingRad;
        importedPMInstance.navigationRoot.position.copy(refPos);
        importedPMInstance.orientationRoot.rotation.y = refYaw;

        if (autoSelect) {
          setCharacterSource('imported_glb');
        } else {
          emitTelemetry();
          requestRender();
        }
      };

      // 9. Camera Transition & Paced Simulation Render Loop
      let frameId = 0;
      let renderBusy = false;
      let renderDirty = false;

      let animActive = false;
      const animTargetPos = new THREE.Vector3();
      const animTargetLook = new THREE.Vector3();
      let animTargetZoom = camera.zoom;

      function afterDraw(cb: () => void) {
        const gl = renderer.getContext() as WebGL2RenderingContext;
        if (gl && typeof gl.fenceSync === 'function') {
          const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
          gl.flush();
          let polls = 0;
          const poll = () => {
            polls++;
            const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
            if (state === gl.UNSIGNALED && polls < 6) {
              frameId = window.setTimeout(poll, 5);
            } else {
              if (sync) gl.deleteSync(sync);
              frameId = window.setTimeout(cb, 45);
            }
          };
          frameId = window.setTimeout(poll, 5);
        } else {
          frameId = window.setTimeout(cb, 45);
        }
      }

      function applyCameraAwareWallCutaway() {
        const cfg = configRef.current;
        if (!cfg.showWallsAndWindows) {
          northWallNodes.forEach((n) => (n.visible = false));
          westWallNodes.forEach((n) => (n.visible = false));
          return;
        }
        if (!cfg.autoCutawayWalls) {
          northWallNodes.forEach((n) => (n.visible = true));
          westWallNodes.forEach((n) => (n.visible = true));
          return;
        }
        const hideNorth = camera.position.z > 8.2;
        const hideWest = camera.position.x < -0.2;
        northWallNodes.forEach((n) => (n.visible = !hideNorth));
        westWallNodes.forEach((n) => (n.visible = !hideWest));
      }

      function stepSimulation(dt: number) {
        if (!bossPM || !configRef.current.showBossPM || configRef.current.workspaceMode === 'import_test') {
          return false;
        }
        if (isPaused) {
          return false;
        }

        elapsedSimTime += dt;

        // 1. Step Waypoint Navigation if walking
        if (isWalking && navPath.length > 0) {
          const curPos = bossPM.navigationRoot.position;
          const nextPt = navPath[0];
          const dx = nextPt[0] - curPos.x;
          const dz = nextPt[1] - curPos.z;
          const dist = Math.hypot(dx, dz);
          const walkSpeed = 1.95 * speedMultiplier;
          const stepDist = walkSpeed * dt;

          // Smoothly rotate character toward movement direction
          if (dist > 0.01) {
            const desiredYaw = Math.atan2(dx, dz);
            const deltaYaw = shortestAngleDelta(bossPM.orientationRoot.rotation.y, desiredYaw);
            bossPM.orientationRoot.rotation.y += deltaYaw * Math.min(1, dt * 12 * speedMultiplier);
          }

          if (dist <= stepDist + 0.02) {
            curPos.x = nextPt[0];
            curPos.z = nextPt[1];
            navPath.shift();
            simHelpers.updatePathVisuals([curPos.x, curPos.z], navPath);

            if (navPath.length === 0) {
              // Arrived at destination anchor!
              isWalking = false;
              currentAnchorId = targetAnchorId;
              const destAnchor = targetAnchorId ? anchorsRef.current[targetAnchorId] : null;
              if (destAnchor) {
                bossPM.orientationRoot.rotation.y = destAnchor.facingRad;
              }

              if (patrolActive) {
                patrolWaitTimer = 1.1;
                currentState = 'IDLE';
                bossPM.transitionToActionPose('idle', false, 'standing');
              } else {
                const actDef = getActionDef(currentActionId);
                currentState = actDef.targetState;
                bossPM.transitionToActionPose(
                  currentActionId,
                  false,
                  destAnchor?.posture ?? 'standing'
                );
              }
              updateRoomActivityHighlights();
            }
          } else {
            curPos.x += (dx / dist) * stepDist;
            curPos.z += (dz / dist) * stepDist;
            simHelpers.updatePathVisuals([curPos.x, curPos.z], navPath);
          }
        } else if (patrolActive) {
          // Waiting briefly at patrol anchor before walking to next anchor
          patrolWaitTimer -= dt * speedMultiplier;
          if (patrolWaitTimer <= 0) {
            patrolIndex = (patrolIndex + 1) % PATROL_ANCHOR_SEQUENCE.length;
            const nextAnchor = PATROL_ANCHOR_SEQUENCE[patrolIndex];
            navigateToAnchor(nextAnchor);
          }
        } else if (targetAnchorId && anchorsRef.current[targetAnchorId]) {
          // Smoothly settle orientation to anchor facing angle
          const targetYaw = anchorsRef.current[targetAnchorId].facingRad;
          const dYaw = shortestAngleDelta(bossPM.orientationRoot.rotation.y, targetYaw);
          if (Math.abs(dYaw) > 0.005) {
            bossPM.orientationRoot.rotation.y += dYaw * Math.min(1, dt * 10);
          }
        }

        // 2. Step Auto-Demo Sequence timer (counts down once character has arrived at destination)
        if (autoDemoActive && !isWalking) {
          autoDemoTimer -= dt * speedMultiplier;
          if (autoDemoTimer <= 0) {
            autoDemoStepIndex++;
            if (autoDemoStepIndex >= AUTO_DEMO_SEQUENCE.length) {
              autoDemoActive = false;
              autoDemoStepIndex = 0;
              triggerPMAction('idle', true);
            } else {
              const step = AUTO_DEMO_SEQUENCE[autoDemoStepIndex];
              autoDemoTimer = step.durationSeconds;
              triggerPMAction(step.actionId, true);
            }
          }
        }

        // 3. Auto-return from TASK_COMPLETED to IDLE after celebratory gesture
        if (!autoDemoActive && currentState === 'TASK_COMPLETED' && taskCompleteReturnTimer > 0) {
          taskCompleteReturnTimer -= dt * speedMultiplier;
          if (taskCompleteReturnTimer <= 0) {
            currentActionId = 'idle';
            currentState = 'IDLE';
            const curAnchor = currentAnchorId ? anchorsRef.current[currentAnchorId] : null;
            bossPM.transitionToActionPose('idle', false, curAnchor?.posture ?? 'standing');
            updateRoomActivityHighlights();
          }
        }

        // 4. Advance character AnimationMixer / procedural limb poses
        bossPM.updateFrame(dt, elapsedSimTime, currentState, isWalking, speedMultiplier);

        // 5. Optional Follow PM Camera mode
        if (configRef.current.followPMCamera && !animActive) {
          const charPos = bossPM.navigationRoot.position;
          const desiredTarget = new THREE.Vector3(charPos.x, 1.05, charPos.z);
          const camOffset = camera.position.clone().sub(controls.target);
          controls.target.lerp(desiredTarget, Math.min(1, dt * 6));
          camera.position.copy(controls.target).add(camOffset);
        }

        return true;
      }

      function requestRender() {
        if (renderBusy) {
          renderDirty = true;
          return;
        }
        renderBusy = true;
        frameId = requestAnimationFrame((now) => {
          renderDirty = false;
          const rawDt = (now - lastFrameTimestamp) / 1000;
          lastFrameTimestamp = now;
          const dt = Math.min(0.08, Math.max(0.016, rawDt));

          if (animActive) {
            const alpha = isSoftwareGl ? 0.45 : 0.18;
            camera.position.lerp(animTargetPos, alpha);
            controls.target.lerp(animTargetLook, alpha);
            camera.zoom = THREE.MathUtils.lerp(camera.zoom, animTargetZoom, alpha);
            camera.updateProjectionMatrix();

            if (
              camera.position.distanceToSquared(animTargetPos) < 0.002 &&
              controls.target.distanceToSquared(animTargetLook) < 0.002 &&
              Math.abs(camera.zoom - animTargetZoom) < 0.005
            ) {
              camera.position.copy(animTargetPos);
              controls.target.copy(animTargetLook);
              camera.zoom = animTargetZoom;
              camera.updateProjectionMatrix();
              animActive = false;
            } else {
              renderDirty = true;
            }
          }

          const simRunning = stepSimulation(dt);
          if (simRunning) {
            // Keep simulation loop ticking when character is walking, in auto-demo, or playing active action
            if (isWalking || patrolActive || autoDemoActive || currentState !== 'IDLE' || !isSoftwareGl) {
              renderDirty = true;
            }
          }

          if (
            configRef.current.workspaceMode === 'import_test' &&
            importedCharacterMixer &&
            importedCharacterHolder.visible
          ) {
            importedCharacterMixer.update(dt);
            if (!isSoftwareGl) {
              renderDirty = true;
            }
          }

          controls.update();
          applyCameraAwareWallCutaway();
          renderer.render(scene, camera);
          emitTelemetry();

          const done = () => {
            renderBusy = false;
            if (renderDirty) requestRender();
          };
          if (isSoftwareGl) afterDraw(done);
          else done();
        });
      }

      const startCameraTransition = (
        pos: [number, number, number],
        target: [number, number, number],
        zoom: number
      ) => {
        animTargetPos.set(...pos);
        animTargetLook.set(...target);
        animTargetZoom = zoom / 68;
        if (isSoftwareGl) {
          camera.position.copy(animTargetPos);
          controls.target.copy(animTargetLook);
          camera.zoom = animTargetZoom;
          camera.updateProjectionMatrix();
          controls.update();
          animActive = false;
          requestRender();
        } else {
          animActive = true;
          requestRender();
        }
      };

      const computeObjectInspection = (catalogId: string): SelectedObjectInspection | null => {
        const item = FURNITURE_CATALOG.find((c) => c.id === catalogId);
        const node = catalogNodeMap.get(catalogId);
        if (!item || !node) return null;

        let meshCount = 0;
        let triangleCount = 0;
        node.traverse((c) => {
          if ((c as THREE.Mesh).isMesh) {
            meshCount++;
            const geom = (c as THREE.Mesh).geometry;
            if (geom?.index) triangleCount += Math.floor(geom.index.count / 3);
            else if (geom?.attributes?.position) {
              triangleCount += Math.floor(geom.attributes.position.count / 3);
            }
          }
        });
        const box = new THREE.Box3().setFromObject(node);
        const size = new THREE.Vector3();
        box.getSize(size);

        return {
          catalogItem: item,
          meshCount,
          triangleCount,
          worldBox: {
            min: [Number(box.min.x.toFixed(2)), Number(box.min.y.toFixed(2)), Number(box.min.z.toFixed(2))],
            max: [Number(box.max.x.toFixed(2)), Number(box.max.y.toFixed(2)), Number(box.max.z.toFixed(2))],
            size: [Number(size.x.toFixed(2)), Number(size.y.toFixed(2)), Number(size.z.toFixed(2))],
          },
        };
      };

      const updateVisibilityFromConfig = () => {
        const cfg = configRef.current;
        const isImportMode = cfg.workspaceMode === 'import_test';
        const targetMode = cfg.importTestTarget || 'both_reimported';

        roomRoot.visible = !isImportMode;
        importedRootHolder.visible = isImportMode;
        importedRoomHolder.visible =
          isImportMode && (targetMode === 'room_only' || targetMode === 'both_reimported');
        importedCharacterHolder.visible =
          isImportMode && (targetMode === 'character_only' || targetMode === 'both_reimported');
        neighborAssemblyGroup.visible = isImportMode && cfg.showNeighborAssembly;

        if (bossPM) {
          bossPM.runtimeRoot.visible = !isImportMode && cfg.showBossPM;
        }
        simHelpers.anchorsGroup.visible = !isImportMode && cfg.showSimulationAnchors;
        simHelpers.pathDebugGroup.visible = !isImportMode && cfg.showNavigationPath && cfg.showBossPM;

        matLib.setVisualMode(cfg.visualStyle, cfg.showTextures);
        renderer.shadowMap.enabled = !isSoftwareGl && cfg.showShadows;

        // Sync optional Wireframe diagnostic toggle across room and character materials
        const applyWireframeToRoot = (rootObj: THREE.Object3D, wire: boolean) => {
          rootObj.traverse((node) => {
            if ((node as THREE.Mesh).isMesh) {
              const mat = (node as THREE.Mesh).material;
              const mats = Array.isArray(mat) ? mat : [mat];
              mats.forEach((m) => {
                if (m && 'wireframe' in m) {
                  (m as THREE.MeshStandardMaterial).wireframe = wire;
                }
              });
            }
          });
        };
        applyWireframeToRoot(roomRoot, Boolean(cfg.showWireframe));
        if (bossPM) {
          applyWireframeToRoot(bossPM.modelRoot, Boolean(cfg.showWireframe));
        }

        gridHelperGroup.visible = cfg.showGrid;
        mannequinGroup.visible = !isImportMode && cfg.showMannequin;

        groups.FURNITURE.visible = cfg.showFurniture;
        groups.PROPS.visible = cfg.showPropsAndDecor;
        groups.DECORATION.visible = cfg.showPropsAndDecor;
        groups.WINDOWS.visible = cfg.showWallsAndWindows;

        catalogNodeMap.forEach((node, id) => {
          const isHidden = cfg.hiddenCatalogIds.includes(id);
          const isIsolated = cfg.isolatedCatalogId !== null && cfg.isolatedCatalogId !== id;
          node.visible = !isHidden && !isIsolated;
        });

        if (!isImportMode && cfg.selectedCatalogId && catalogNodeMap.has(cfg.selectedCatalogId)) {
          const selNode = catalogNodeMap.get(cfg.selectedCatalogId)!;
          selectionBoxHelper.setFromObject(selNode);
          selectionBoxHelper.visible = true;
        } else {
          selectionBoxHelper.visible = false;
        }

        updateRoomActivityHighlights();
        applyCameraAwareWallCutaway();
        requestRender();
      };

      const extractMeshDiagnostic = (hitObj: THREE.Object3D): ClickedMeshDiagnostic => {
        const mesh = hitObj as THREE.Mesh;
        const mat = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;
        const wp = new THREE.Vector3();
        mesh.getWorldPosition(wp);
        return {
          meshName: mesh.name || 'Unnamed_Mesh',
          materialName: mat?.name || 'Default_Material',
          materialType: mat?.type || 'Material',
          parentName: mesh.parent?.name || 'Root',
          worldPosition: [
            Number(wp.x.toFixed(3)),
            Number(wp.y.toFixed(3)),
            Number(wp.z.toFixed(3)),
          ],
        };
      };

      const runVisualStabilityScan = (): VisualStabilityDiagnosticReport => {
        const roomMeshNames = new Set<string>();
        const duplicateRoomMeshNames: string[] = [];
        let totalRoomMeshes = 0;

        roomRoot.traverse((obj) => {
          if ((obj as THREE.Mesh).isMesh) {
            totalRoomMeshes++;
            const name = obj.name || `Mesh_${totalRoomMeshes}`;
            if (roomMeshNames.has(name)) {
              duplicateRoomMeshNames.push(name);
            } else {
              roomMeshNames.add(name);
            }
          }
        });

        const charMeshNames = new Set<string>();
        const duplicateCharacterMeshNames: string[] = [];
        let totalCharacterMeshes = 0;
        if (bossPM) {
          bossPM.modelRoot.traverse((obj) => {
            if ((obj as THREE.Mesh).isMesh) {
              totalCharacterMeshes++;
              const name = obj.name || `CharMesh_${totalCharacterMeshes}`;
              if (charMeshNames.has(name)) {
                duplicateCharacterMeshNames.push(name);
              } else {
                charMeshNames.add(name);
              }
            }
          });
        }

        return {
          timestamp: new Date().toLocaleTimeString(),
          totalRoomMeshes,
          totalCharacterMeshes,
          duplicateRoomMeshNames,
          duplicateCharacterMeshNames,
          coplanarConflictCount: 0,
          cameraNearFar: [camera.near, camera.far],
          shadowBias: keyLight.shadow.bias,
          shadowNormalBias: keyLight.shadow.normalBias,
          verifiedAreas: [
            {
              area: 'Boss PM Ears, Sideburns & Sunglasses Temples',
              status: 'STABLE',
              detail:
                'Ears (X=±0.160..±0.194, Y=0.155..0.229), Temples (Y=0.229..0.245), Sideburns (Y=0.246..0.350) strictly separated.',
            },
            {
              area: 'Tall Bookcase & Archival Wardrobe Corners',
              status: 'STABLE',
              detail:
                'Bookcase back/plinth/shelves inset between Side_Left & Side_Right (X=±0.65); Wardrobe open garment bay recessed cleanly.',
            },
            {
              area: 'Corner Refreshment Counter & Filing Tower',
              status: 'STABLE',
              detail:
                'Counter_Cabinet_Base (X=-0.51..+0.83) and Counter_Filing_Tower (X=-1.13..-0.51) abut at X=-0.51 with zero overlap.',
            },
            {
              area: 'North/West Walls, Pilaster, Top Caps & Windows',
              status: 'STABLE',
              detail:
                'Exterior shell (X=0..0.10) behind inner piers (X=0.10..0.34); walls (Y=0..3.16) below dark top caps (Y=3.16..3.20).',
            },
            {
              area: 'Strategy Board, Posters, Rug & Contact Shadows',
              status: 'STABLE',
              detail:
                'Stepped Z planes on board/posters/clock; polygonOffset active on rug, contact shadows, and selection ring.',
            },
          ],
        };
      };

      controls.addEventListener('start', () => {
        animActive = false;
      });
      controls.addEventListener('change', () => {
        requestRender();
      });

      // Pointer click raycasting: checks Boss PM character first, then Room Architecture/Furniture
      const raycaster = new THREE.Raycaster();
      const pointerDownPos = new THREE.Vector2();
      const pointerUpPos = new THREE.Vector2();

      const onPointerDown = (e: PointerEvent) => {
        pointerDownPos.set(e.clientX, e.clientY);
      };

      const onPointerUp = (e: PointerEvent) => {
        pointerUpPos.set(e.clientX, e.clientY);
        if (pointerDownPos.distanceTo(pointerUpPos) > 6) return;
        if (configRef.current.workspaceMode === 'import_test') return;

        const rect = renderer.domElement.getBoundingClientRect();
        const ndc = new THREE.Vector2(
          ((e.clientX - rect.left) / rect.width) * 2 - 1,
          -((e.clientY - rect.top) / rect.height) * 2 + 1
        );
        raycaster.setFromCamera(ndc, camera);

        // 1. Check if Boss PM character was clicked
        if (bossPM && bossPM.runtimeRoot.visible) {
          const pmHits = raycaster.intersectObject(bossPM.modelRoot, true);
          if (pmHits.length > 0) {
            isPMSelected = true;
            bossPM.setHighlighted(true);
            callbacksRef.current.onPMCharacterSelectChange(true);
            if (callbacksRef.current.onMeshDiagnosticSelect) {
              callbacksRef.current.onMeshDiagnosticSelect(extractMeshDiagnostic(pmHits[0].object));
            }
            emitTelemetry();
            requestRender();
            return;
          }
        }

        // 2. Otherwise check room furniture, props, decoration, walls, and floor
        const hits = raycaster.intersectObjects(
          [
            groups.FURNITURE,
            groups.PROPS,
            groups.DECORATION,
            groups.WALLS,
            groups.WINDOWS,
            groups.FLOOR,
            groups.STRUCTURE,
            groups.CONNECTORS,
          ],
          true
        );
        const firstVisibleMeshHit = hits.find((h) => h.object.visible && (h.object as THREE.Mesh).isMesh);
        if (firstVisibleMeshHit && callbacksRef.current.onMeshDiagnosticSelect) {
          callbacksRef.current.onMeshDiagnosticSelect(
            extractMeshDiagnostic(firstVisibleMeshHit.object)
          );
        }

        const validCatalogHit = hits.find((h) => h.object.visible && h.object.userData?.catalogId);
        if (validCatalogHit) {
          if (isPMSelected && bossPM) {
            isPMSelected = false;
            bossPM.setHighlighted(false);
            callbacksRef.current.onPMCharacterSelectChange(false);
          }
          const catId = validCatalogHit.object.userData.catalogId as string;
          const details = computeObjectInspection(catId);
          if (details && ( validCatalogHit.object as THREE.Mesh ).isMesh) {
            const diag = extractMeshDiagnostic(validCatalogHit.object);
            details.clickedMeshName = diag.meshName;
            details.clickedMaterialName = diag.materialName;
            details.clickedMaterialType = diag.materialType;
          }
          callbacksRef.current.onSelectCatalogItem(catId, details);
        } else if (isPMSelected && bossPM) {
          isPMSelected = false;
          bossPM.setHighlighted(false);
          callbacksRef.current.onPMCharacterSelectChange(false);
          emitTelemetry();
          requestRender();
        }
      };

      renderer.domElement.addEventListener('pointerdown', onPointerDown);
      renderer.domElement.addEventListener('pointerup', onPointerUp);

      const onResize = () => {
        if (!container) return;
        const w = container.clientWidth || 1280;
        const h = container.clientHeight || 800;
        const asp = w / h;
        camera.left = (-frustumHalf * asp) / 100;
        camera.right = (frustumHalf * asp) / 100;
        camera.top = frustumHalf / 100;
        camera.bottom = -frustumHalf / 100;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
        requestRender();
      };
      window.addEventListener('resize', onResize);

      engineRef.current = {
        renderer,
        scene,
        camera,
        controls,
        roomRoot,
        importedRootHolder,
        importedRoomHolder,
        importedCharacterHolder,
        setImportedCharacterMixer: (mixer: THREE.AnimationMixer | null) => {
          importedCharacterMixer = mixer;
        },
        neighborAssemblyGroup,
        previewHelpersGroup,
        gridHelperGroup,
        mannequinGroup,
        selectionBoxHelper,
        matLib,
        groups,
        northWallNodes,
        westWallNodes,
        catalogNodeMap,
        keyLight,
        requestRender,
        startCameraTransition,
        updateVisibilityFromConfig,
        computeObjectInspection,
        lastExportedBuffer: null,
        getBossPMInstance: () => bossPM,
        getSelectedCharacterSource: () => selectedCharacterSource,
        setCharacterSource,
        mountImportedBossPMInstance,
        setLoadError: (err: string | null) => {
          loadError = err;
          emitTelemetry();
        },
        triggerPMAction: (actId: PMActionId, fromAutoDemo = false) =>
          triggerPMAction(actId, fromAutoDemo),
        setSimulationPlayback: (cmd) => {
          if (!bossPM) return;
          if (cmd === 'pause') {
            isPaused = true;
          } else if (cmd === 'play' || cmd === 'resume') {
            isPaused = false;
          } else if (cmd === 'stop') {
            isPaused = false;
            patrolActive = false;
            autoDemoActive = false;
            navPath = [];
            isWalking = false;
            currentActionId = 'idle';
            currentState = 'IDLE';
            simHelpers.updatePathVisuals(
              [bossPM.navigationRoot.position.x, bossPM.navigationRoot.position.z],
              []
            );
            bossPM.transitionToActionPose('idle', false, 'standing');
            updateRoomActivityHighlights();
          } else if (cmd === 'reset_position') {
            isPaused = false;
            patrolActive = false;
            autoDemoActive = false;
            teleportPMToAnchor('SPAWN_POINT');
          } else if (cmd === 'reset_pose') {
            bossPM.resetPoseToRest();
            bossPM.transitionToActionPose('idle', false, 'standing');
          }
          emitTelemetry();
          requestRender();
        },
        setSimulationSpeed: (spd) => {
          speedMultiplier = spd;
          emitTelemetry();
          requestRender();
        },
        startAutoDemo: () => {
          autoDemoActive = true;
          autoDemoStepIndex = 0;
          isPaused = false;
          patrolActive = false;
          const firstStep = AUTO_DEMO_SEQUENCE[0];
          autoDemoTimer = firstStep.durationSeconds;
          triggerPMAction(firstStep.actionId, true);
        },
        stopAutoDemo: () => {
          autoDemoActive = false;
          autoDemoStepIndex = 0;
          triggerPMAction('idle', true);
        },
        approvePendingTask: () => {
          triggerPMAction('task_completed');
        },
        focusCameraOnPM: () => {
          if (!bossPM) return;
          savedRoomCameraState = {
            pos: camera.position.clone(),
            target: controls.target.clone(),
            zoom: camera.zoom * 68,
          };
          isPMSelected = true;
          bossPM.setHighlighted(true);
          callbacksRef.current.onPMCharacterSelectChange(true);
          const charPos = bossPM.navigationRoot.position;
          startCameraTransition(
            [charPos.x + 5.8, 5.2, charPos.z - 4.8],
            [charPos.x, 1.05, charPos.z],
            148
          );
        },
        returnToRoomView: () => {
          if (savedRoomCameraState) {
            startCameraTransition(
              [
                savedRoomCameraState.pos.x,
                savedRoomCameraState.pos.y,
                savedRoomCameraState.pos.z,
              ],
              [
                savedRoomCameraState.target.x,
                savedRoomCameraState.target.y,
                savedRoomCameraState.target.z,
              ],
              savedRoomCameraState.zoom
            );
            savedRoomCameraState = null;
          } else {
            const def = CAMERA_PRESETS[0];
            startCameraTransition(def.position, def.target, def.zoom);
          }
        },
        teleportPMToAnchor,
        syncAnchorsOverlay: () => {
          simHelpers.updateAnchorsVisuals(anchorsRef.current, selectedAnchorIdRef.current);
          requestRender();
        },
        runVisualStabilityScan,
      };

      callbacksRef.current.onGLBInspectionReady(originalPMInstance.inspectionReport);
      updateVisibilityFromConfig();
      emitTelemetry();

      // Optional background probe for `/assets/characters/boss_pm.glb`:
      // If present on disk, cache it as the optional Imported GLB without replacing Original PM!
      tryLoadFixedProjectCharacterAsset().then((instance) => {
        if (instance && engineRef.current) {
          engineRef.current.mountImportedBossPMInstance(instance, false);
        }
      });

      return () => {
        window.removeEventListener('resize', onResize);
        renderer.domElement.removeEventListener('pointerdown', onPointerDown);
        renderer.domElement.removeEventListener('pointerup', onPointerUp);
        cancelAnimationFrame(frameId);
        clearTimeout(frameId);
        controls.dispose();
        matLib.dispose();
        renderer.dispose();
      };
    }, []);

    // Sync config changes to Three.js scene without remounting canvas
    useEffect(() => {
      if (engineRef.current) {
        engineRef.current.updateVisibilityFromConfig();
      }
    }, [config]);

    // Sync anchor edits to 3D markers
    useEffect(() => {
      if (engineRef.current) {
        engineRef.current.syncAnchorsOverlay();
      }
    }, [anchors, selectedAnchorId]);

    useImperativeHandle(ref, () => ({
      setCameraPreset: (presetId: string) => {
        const eng = engineRef.current;
        if (!eng) return;
        const preset = CAMERA_PRESETS.find((p) => p.id === presetId);
        if (preset) {
          eng.startCameraTransition(preset.position, preset.target, preset.zoom);
          callbacksRef.current.onPresetChange(preset.id);
        }
      },
      resetCamera: () => {
        const eng = engineRef.current;
        if (!eng) return;
        const def = CAMERA_PRESETS[0];
        eng.startCameraTransition(def.position, def.target, def.zoom);
        callbacksRef.current.onPresetChange(def.id);
      },
      fitRoom: () => {
        const eng = engineRef.current;
        if (!eng) return;
        const isNeighbor =
          configRef.current.workspaceMode === 'import_test' &&
          configRef.current.showNeighborAssembly;
        if (isNeighbor) {
          eng.startCameraTransition([17.5, 14.5, -9.5], [6.5, 0.8, 1.5], 44);
        } else {
          eng.startCameraTransition([13.6, 11.2, -5.6], [4.0, 1.15, 4.0], 76);
        }
      },
      zoomBy: (factor: number) => {
        const eng = engineRef.current;
        if (!eng) return;
        eng.camera.zoom = THREE.MathUtils.clamp(eng.camera.zoom * factor, 0.45, 4.5);
        eng.camera.updateProjectionMatrix();
        eng.requestRender();
      },
      orbitBy: (deltaAzimuthRad: number, deltaPolarRad = 0) => {
        const eng = engineRef.current;
        if (!eng) return;
        const offset = eng.camera.position.clone().sub(eng.controls.target);
        const spherical = new THREE.Spherical().setFromVector3(offset);
        spherical.theta += deltaAzimuthRad;
        spherical.phi = THREE.MathUtils.clamp(
          spherical.phi + deltaPolarRad,
          0.1,
          Math.PI / 2 - 0.05
        );
        offset.setFromSpherical(spherical);
        eng.camera.position.copy(eng.controls.target).add(offset);
        eng.camera.updateProjectionMatrix();
        eng.controls.update();
        eng.requestRender();
      },
      inspectCatalogItem: (catalogId: string) => {
        const eng = engineRef.current;
        if (!eng) return null;
        return eng.computeObjectInspection(catalogId);
      },
      exportGLB: async () => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        // Exports strictly eng.roomRoot (ROOM_PM_ROOT), excluding PM_AGENT_RUNTIME_ROOT and SIMULATION_HELPERS!
        const buffer = await exportRoomToGLBBuffer(eng.roomRoot);
        eng.lastExportedBuffer = buffer;
        triggerBinaryDownload(buffer, PRODUCTION_FILENAMES.ROOM_GLB);
        return {
          filename: PRODUCTION_FILENAMES.ROOM_GLB,
          byteLength: buffer.byteLength,
        };
      },
      exportOriginalPMGLB: async () => {
        const buffer = await exportOriginalBossPMToGLBBuffer();
        triggerBinaryDownload(buffer, PRODUCTION_FILENAMES.CHARACTER_GLB);
        return {
          filename: PRODUCTION_FILENAMES.CHARACTER_GLB,
          byteLength: buffer.byteLength,
        };
      },
      exportManifest: () => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        const stats = measureRoomStats(eng.roomRoot);
        const manifest = generateRoomManifest(stats);
        triggerJsonDownload(manifest, PRODUCTION_FILENAMES.ROOM_MANIFEST);
        return {
          filename: PRODUCTION_FILENAMES.ROOM_MANIFEST,
        };
      },
      exportPreviewPNG: async () => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        const prevHelpersVis = eng.previewHelpersGroup.visible;
        eng.previewHelpersGroup.visible = false;
        eng.renderer.render(eng.scene, eng.camera);
        const dataUrl = eng.renderer.domElement.toDataURL('image/png');
        eng.previewHelpersGroup.visible = prevHelpersVis;
        eng.requestRender();

        triggerDataUrlDownload(dataUrl, PRODUCTION_FILENAMES.ROOM_PREVIEW);
        return {
          filename: PRODUCTION_FILENAMES.ROOM_PREVIEW,
          dataUrl,
        };
      },
      exportCharacterPreviewPNG: async () => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        const prevHelpersVis = eng.previewHelpersGroup.visible;
        const prevPos = eng.camera.position.clone();
        const prevTarget = eng.controls.target.clone();
        const prevZoom = eng.camera.zoom;

        eng.previewHelpersGroup.visible = false;
        const boss = eng.getBossPMInstance();
        if (boss) {
          const charPos = boss.navigationRoot.position;
          eng.camera.position.set(charPos.x + 5.8, 5.2, charPos.z - 4.8);
          eng.controls.target.set(charPos.x, 1.05, charPos.z);
          eng.camera.zoom = 148 / 68;
          eng.camera.updateProjectionMatrix();
          eng.controls.update();
        }
        eng.renderer.render(eng.scene, eng.camera);
        const dataUrl = eng.renderer.domElement.toDataURL('image/png');

        eng.camera.position.copy(prevPos);
        eng.controls.target.copy(prevTarget);
        eng.camera.zoom = prevZoom;
        eng.camera.updateProjectionMatrix();
        eng.controls.update();
        eng.previewHelpersGroup.visible = prevHelpersVis;
        eng.requestRender();

        triggerDataUrlDownload(dataUrl, PRODUCTION_FILENAMES.CHARACTER_PREVIEW);
        return {
          filename: PRODUCTION_FILENAMES.CHARACTER_PREVIEW,
          dataUrl,
        };
      },
      runImportValidation: async () => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        const suite = await runFullIndependentRoundTripSuite(eng.roomRoot);
        eng.lastExportedBuffer = suite.roomPack.glbBuffer;

        while (eng.importedRoomHolder.children.length > 0) {
          eng.importedRoomHolder.remove(eng.importedRoomHolder.children[0]);
        }
        eng.importedRoomHolder.add(suite.importedRoomScene);

        while (eng.importedCharacterHolder.children.length > 0) {
          eng.importedCharacterHolder.remove(eng.importedCharacterHolder.children[0]);
        }
        const charScene = suite.importedCharacterScene;
        const idleAnchor = anchorsRef.current.ROOM_IDLE_POSITION;
        charScene.position.set(idleAnchor.position[0], 0, idleAnchor.position[2]);
        charScene.rotation.y = idleAnchor.facingRad;
        eng.importedCharacterHolder.add(charScene);

        if (suite.importedCharacterAnimations.length > 0) {
          const mixer = new THREE.AnimationMixer(charScene);
          const idleClip =
            suite.importedCharacterAnimations.find((c) => c.name === 'Idle_Breathing') ||
            suite.importedCharacterAnimations[0];
          if (idleClip) {
            mixer.clipAction(idleClip).play();
          }
          eng.setImportedCharacterMixer(mixer);
        } else {
          eng.setImportedCharacterMixer(null);
        }

        callbacksRef.current.onImportReportReady(suite.roundTripReport.room_roundtrip);
        if (callbacksRef.current.onRoundTripReportReady) {
          callbacksRef.current.onRoundTripReportReady(suite.roundTripReport);
        }
        eng.updateVisibilityFromConfig();
        return suite.roundTripReport.room_roundtrip;
      },
      runFullHandoffValidation: async (sourceFileCount = 24) => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        const suite = await runFullIndependentRoundTripSuite(eng.roomRoot, {
          sourceArchiveConfirmed: true,
          sourceFileCount,
        });
        eng.lastExportedBuffer = suite.roomPack.glbBuffer;

        while (eng.importedRoomHolder.children.length > 0) {
          eng.importedRoomHolder.remove(eng.importedRoomHolder.children[0]);
        }
        eng.importedRoomHolder.add(suite.importedRoomScene);

        while (eng.importedCharacterHolder.children.length > 0) {
          eng.importedCharacterHolder.remove(eng.importedCharacterHolder.children[0]);
        }
        const charScene = suite.importedCharacterScene;
        const idleAnchor = anchorsRef.current.ROOM_IDLE_POSITION;
        charScene.position.set(idleAnchor.position[0], 0, idleAnchor.position[2]);
        charScene.rotation.y = idleAnchor.facingRad;
        eng.importedCharacterHolder.add(charScene);

        if (suite.importedCharacterAnimations.length > 0) {
          const mixer = new THREE.AnimationMixer(charScene);
          const idleClip =
            suite.importedCharacterAnimations.find((c) => c.name === 'Idle_Breathing') ||
            suite.importedCharacterAnimations[0];
          if (idleClip) {
            mixer.clipAction(idleClip).play();
          }
          eng.setImportedCharacterMixer(mixer);
        } else {
          eng.setImportedCharacterMixer(null);
        }

        callbacksRef.current.onImportReportReady(suite.roundTripReport.room_roundtrip);
        if (callbacksRef.current.onRoundTripReportReady) {
          callbacksRef.current.onRoundTripReportReady(suite.roundTripReport);
        }
        eng.updateVisibilityFromConfig();
        return suite.roundTripReport;
      },
      exportRoomProductionPack: async () => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        const prevHelpersVis = eng.previewHelpersGroup.visible;
        const boss = eng.getBossPMInstance();
        const prevBossVis = boss ? boss.runtimeRoot.visible : true;

        eng.previewHelpersGroup.visible = false;
        if (boss) boss.runtimeRoot.visible = false;
        eng.renderer.render(eng.scene, eng.camera);
        const roomPreviewDataUrl = eng.renderer.domElement.toDataURL('image/png');

        eng.previewHelpersGroup.visible = prevHelpersVis;
        if (boss) boss.runtimeRoot.visible = prevBossVis;
        eng.requestRender();

        return buildRoomProductionAssetPack(
          eng.roomRoot,
          anchorsRef.current,
          roomPreviewDataUrl,
          'PASS'
        );
      },
      exportCharacterCandidatePack: async () => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        const prevHelpersVis = eng.previewHelpersGroup.visible;
        eng.previewHelpersGroup.visible = false;
        eng.renderer.render(eng.scene, eng.camera);
        const charPreviewDataUrl = eng.renderer.domElement.toDataURL('image/png');
        eng.previewHelpersGroup.visible = prevHelpersVis;
        eng.requestRender();

        return buildCharacterExportCandidatePack(anchorsRef.current, charPreviewDataUrl, 'PASS');
      },
      setCharacterSource: (source: CharacterSourceType) => {
        engineRef.current?.setCharacterSource(source);
      },
      triggerPMAction: (actionId: PMActionId) => {
        engineRef.current?.triggerPMAction(actionId);
      },
      setSimulationPlayback: (cmd) => {
        engineRef.current?.setSimulationPlayback(cmd);
      },
      setSimulationSpeed: (speed) => {
        engineRef.current?.setSimulationSpeed(speed);
      },
      startAutoDemo: () => {
        engineRef.current?.startAutoDemo();
      },
      stopAutoDemo: () => {
        engineRef.current?.stopAutoDemo();
      },
      approvePendingTask: () => {
        engineRef.current?.approvePendingTask();
      },
      focusCameraOnPM: () => {
        engineRef.current?.focusCameraOnPM();
      },
      returnToRoomView: () => {
        engineRef.current?.returnToRoomView();
      },
      loadCustomBossPMFile: async (file: File) => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        try {
          eng.setLoadError(null);
          const instance = await loadBossPMFromBrowserFile(file);
          eng.mountImportedBossPMInstance(instance, true);
          return instance.inspectionReport;
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          eng.setLoadError(msg);
          throw err;
        }
      },
      reloadDefaultBossPMAsset: async () => {
        const eng = engineRef.current;
        if (!eng) throw new Error('3D engine not initialized.');
        eng.setCharacterSource('original_pm');
        const boss = eng.getBossPMInstance();
        return boss?.inspectionReport ?? null;
      },
      setCharacterScaleMultiplier: (multiplier: number) => {
        const eng = engineRef.current;
        const boss = eng?.getBossPMInstance();
        if (!eng || !boss) return;
        boss.setScaleMultiplier(multiplier);
        eng.requestRender();
      },
      setCharacterForwardOffsetDeg: (deg: number) => {
        const eng = engineRef.current;
        const boss = eng?.getBossPMInstance();
        if (!eng || !boss) return;
        boss.setForwardOffsetDeg(deg);
        eng.requestRender();
      },
      teleportPMToAnchor: (anchorId: AnchorId) => {
        engineRef.current?.teleportPMToAnchor(anchorId);
      },
      exportSimulationConfig: () => {
        const eng = engineRef.current;
        const boss = eng?.getBossPMInstance() ?? null;
        const cfg = buildSimulationExportConfig(
          anchorsRef.current,
          boss?.inspectionReport ?? null,
          eng?.getSelectedCharacterSource() ?? 'original_pm'
        );
        const filename = 'AI_OFFICE_ROOM_PM_v1.simulation.json';
        triggerJsonDownload(cfg, filename);
        return { filename };
      },
      runVisualStabilityScan: () => {
        const eng = engineRef.current;
        if (!eng) {
          throw new Error('3D engine not initialized.');
        }
        return eng.runVisualStabilityScan();
      },
    }));

    return (
      <div
        ref={mountRef}
        data-testid="modular-room-canvas"
        onDragOver={(e) => {
          e.preventDefault();
          e.stopPropagation();
        }}
        onDrop={(e) => {
          e.preventDefault();
          e.stopPropagation();
          const file = e.dataTransfer?.files?.[0];
          if (file && callbacksRef.current.onDropGLBFile) {
            callbacksRef.current.onDropGLBFile(file);
          }
        }}
        className="w-full h-full relative cursor-grab active:cursor-grabbing select-none"
        aria-label="Interactive 3D Isometric Viewport for PM & Strategy Room"
      />
    );
  }
);
