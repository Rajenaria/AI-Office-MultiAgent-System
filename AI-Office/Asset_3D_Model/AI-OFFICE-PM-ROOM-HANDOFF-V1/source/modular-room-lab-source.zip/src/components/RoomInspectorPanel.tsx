import React, { useState } from 'react';
import {
  Activity,
  Archive,
  Box,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Download,
  Eye,
  EyeOff,
  FileCode2,
  Focus,
  Image as ImageIcon,
  Layers,
  PackageCheck,
  ShieldCheck,
  Sliders,
} from 'lucide-react';
import {
  FURNITURE_CATALOG,
  MODULE_CONSTANTS,
  RoomExportStats,
  generateRoomManifest,
} from '../domain/modularRoomSpec';
import {
  ActivityAnchor,
  AnchorId,
  CharacterSourceType,
  GLBInspectionReport,
  PMActionId,
} from '../domain/pmSimulationSpec';
import {
  ClickedMeshDiagnostic,
  PMSimulationRuntimeTelemetry,
  SelectedObjectInspection,
  ViewerDisplayConfig,
  VisualStabilityDiagnosticReport,
} from './ModularRoomCanvas';
import { PMSimulationPanel } from './PMSimulationPanel';
import { ImportValidationReport } from '../three/RoomExportAndImportManager';
import { VisualStyleMode } from '../three/PixelMaterialLibrary';
import { IndependentRoundTripReportV1 } from '../export/AssetValidation';
import {
  PRODUCTION_FILENAMES,
  buildPMRoomAnchorsJsonV1,
} from '../export/AssetManifestBuilder';

export type InspectorTabId = 'simulation' | 'controls' | 'assets' | 'validation' | 'manifest';

interface RoomInspectorPanelProps {
  activeTab: InspectorTabId;
  onTabChange: (tab: InspectorTabId) => void;
  config: ViewerDisplayConfig;
  stats: RoomExportStats | null;
  selectedDetails: SelectedObjectInspection | null;
  importReport: ImportValidationReport | null;
  roundTripReport: IndependentRoundTripReportV1 | null;
  telemetry: PMSimulationRuntimeTelemetry;
  glbInspectionReport: GLBInspectionReport | null;
  anchors: Record<AnchorId, ActivityAnchor>;
  selectedAnchorId: AnchorId | null;
  onUpdateConfig: (partial: Partial<ViewerDisplayConfig>) => void;
  onSelectCatalogItem: (catalogId: string | null) => void;
  onRunImportTest: () => void;
  onExportGLB: () => void;
  onExportOriginalPMGLB: () => void;
  onExportManifest: () => void;
  onExportRoomManifestAndAnchors: () => void;
  onExportCharacterManifestAndBehavior: () => void;
  onExportPNG: () => void;
  onExportCharacterPNG: () => void;
  onDownloadRoomPackZip: () => void;
  onDownloadCharacterPackZip: () => void;
  onDownloadSourceZip: () => void;
  onDownloadCompleteHandoffZip: () => void;
  onDownloadRoundTripReport: () => void;
  onFitRoom: () => void;
  // Simulation callbacks
  onCharacterSourceChange: (source: CharacterSourceType) => void;
  onTriggerAction: (actionId: PMActionId) => void;
  onPlaybackCommand: (
    cmd: 'play' | 'pause' | 'resume' | 'stop' | 'reset_position' | 'reset_pose'
  ) => void;
  onSpeedChange: (speed: 0.5 | 1 | 1.5) => void;
  onStartAutoDemo: () => void;
  onStopAutoDemo: () => void;
  onApproveTask: () => void;
  onFocusPM: () => void;
  onReturnRoomView: () => void;
  onSelectAnchor: (anchorId: AnchorId | null) => void;
  onUpdateAnchor: (anchorId: AnchorId, updated: ActivityAnchor) => void;
  onResetAnchors: () => void;
  onTeleportToAnchor: (anchorId: AnchorId) => void;
  onUploadCustomGLB: (file: File) => void;
  onScaleMultiplierChange: (multiplier: number) => void;
  onForwardOffsetChange: (deg: number) => void;
  onExportSimConfig: () => void;
  // Visual Stability & Mesh Diagnostic props
  clickedMeshDiagnostic: ClickedMeshDiagnostic | null;
  stabilityReport: VisualStabilityDiagnosticReport | null;
  onRunStabilityScan: () => void;
}

export const RoomInspectorPanel: React.FC<RoomInspectorPanelProps> = ({
  activeTab,
  onTabChange,
  config,
  stats,
  selectedDetails,
  importReport,
  roundTripReport,
  telemetry,
  glbInspectionReport,
  anchors,
  selectedAnchorId,
  onUpdateConfig,
  onSelectCatalogItem,
  onRunImportTest,
  onExportGLB,
  onExportOriginalPMGLB,
  onExportManifest,
  onExportRoomManifestAndAnchors,
  onExportCharacterManifestAndBehavior,
  onExportPNG,
  onExportCharacterPNG,
  onDownloadRoomPackZip,
  onDownloadCharacterPackZip,
  onDownloadSourceZip,
  onDownloadCompleteHandoffZip,
  onDownloadRoundTripReport,
  onFitRoom,
  onCharacterSourceChange,
  onTriggerAction,
  onPlaybackCommand,
  onSpeedChange,
  onStartAutoDemo,
  onStopAutoDemo,
  onApproveTask,
  onFocusPM,
  onReturnRoomView,
  onSelectAnchor,
  onUpdateAnchor,
  onResetAnchors,
  onTeleportToAnchor,
  onUploadCustomGLB,
  onScaleMultiplierChange,
  onForwardOffsetChange,
  onExportSimConfig,
  clickedMeshDiagnostic,
  stabilityReport,
  onRunStabilityScan,
}) => {
  const [showRefImage, setShowRefImage] = useState<boolean>(true);
  const [showDebugInspection, setShowDebugInspection] = useState<boolean>(true);
  const [showHandoffSection, setShowHandoffSection] = useState<boolean>(true);
  const [showValidationMatrix, setShowValidationMatrix] = useState<boolean>(true);
  const [manifestDocTab, setManifestDocTab] = useState<'room_manifest' | 'room_anchors' | 'roundtrip'>('room_manifest');

  const visualModes: Array<{ id: VisualStyleMode; label: string; desc: string }> = [
    {
      id: 'reference',
      label: 'Reference Match',
      desc: 'Default cozy pixel-art textures & warm studio lighting',
    },
    {
      id: 'clean',
      label: 'Clean Geometry',
      desc: 'Untextured clay shading to inspect 3D mesh silhouettes',
    },
    {
      id: 'pixel',
      label: 'Pixel-Art Detail',
      desc: 'Crisp nearest-neighbor pixel texture emphasis',
    },
  ];

  const toggleCatalogItemHidden = (id: string) => {
    const exists = config.hiddenCatalogIds.includes(id);
    const next = exists
      ? config.hiddenCatalogIds.filter((item) => item !== id)
      : [...config.hiddenCatalogIds, id];
    onUpdateConfig({ hiddenCatalogIds: next });
  };

  const toggleIsolateCatalogItem = (id: string) => {
    onUpdateConfig({
      isolatedCatalogId: config.isolatedCatalogId === id ? null : id,
    });
  };

  const manifestPreview = stats ? generateRoomManifest(stats) : null;

  return (
    <aside
      aria-label="Room Inspector and Simulation Controls"
      className="w-92 shrink-0 bg-[#181920] border-l border-[#2B2D38] flex flex-col h-full select-none z-20"
    >
      {/* Inspector Navigation Tabs */}
      <div className="p-2 border-b border-[#2B2D38] bg-[#14151B]">
        <div className="grid grid-cols-5 gap-1 p-1 bg-[#1E2029] rounded-lg">
          <button
            type="button"
            onClick={() => onTabChange('simulation')}
            className={`px-1.5 py-1.5 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1 ${
              activeTab === 'simulation'
                ? 'bg-[#D99252] text-[#14151B] font-semibold shadow-xs'
                : 'text-[#D6D1C7] hover:text-[#F5F2EB]'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>PM Sim</span>
          </button>
          <button
            type="button"
            onClick={() => onTabChange('controls')}
            className={`px-1.5 py-1.5 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1 ${
              activeTab === 'controls'
                ? 'bg-[#2E3240] text-[#F5F2EB] shadow-xs'
                : 'text-[#9CA3AF] hover:text-[#F5F2EB]'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Display</span>
          </button>
          <button
            type="button"
            onClick={() => onTabChange('assets')}
            className={`px-1.5 py-1.5 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1 ${
              activeTab === 'assets'
                ? 'bg-[#2E3240] text-[#F5F2EB] shadow-xs'
                : 'text-[#9CA3AF] hover:text-[#F5F2EB]'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>Room</span>
          </button>
          <button
            type="button"
            onClick={() => {
              onTabChange('validation');
              if (!importReport) onRunImportTest();
            }}
            className={`px-1.5 py-1.5 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1 ${
              activeTab === 'validation'
                ? 'bg-[#2E3240] text-[#F5F2EB] shadow-xs'
                : 'text-[#9CA3AF] hover:text-[#F5F2EB]'
            }`}
          >
            <PackageCheck className="w-3.5 h-3.5" />
            <span>GLB Test</span>
          </button>
          <button
            type="button"
            onClick={() => onTabChange('manifest')}
            className={`px-1.5 py-1.5 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1 ${
              activeTab === 'manifest'
                ? 'bg-[#2E3240] text-[#F5F2EB] shadow-xs'
                : 'text-[#9CA3AF] hover:text-[#F5F2EB]'
            }`}
          >
            <FileCode2 className="w-3.5 h-3.5" />
            <span>Manifest</span>
          </button>
        </div>
      </div>

      {/* Scrollable Inspector Body */}
      <div className="flex-1 overflow-y-auto p-3.5 space-y-5 text-sm">
        {activeTab === 'simulation' && (
          <PMSimulationPanel
            config={config}
            telemetry={telemetry}
            inspectionReport={glbInspectionReport}
            anchors={anchors}
            selectedAnchorId={selectedAnchorId}
            onUpdateConfig={onUpdateConfig}
            onCharacterSourceChange={onCharacterSourceChange}
            onTriggerAction={onTriggerAction}
            onPlaybackCommand={onPlaybackCommand}
            onSpeedChange={onSpeedChange}
            onStartAutoDemo={onStartAutoDemo}
            onStopAutoDemo={onStopAutoDemo}
            onApproveTask={onApproveTask}
            onFocusPM={onFocusPM}
            onReturnRoomView={onReturnRoomView}
            onSelectAnchor={onSelectAnchor}
            onUpdateAnchor={onUpdateAnchor}
            onResetAnchors={onResetAnchors}
            onTeleportToAnchor={onTeleportToAnchor}
            onUploadCustomGLB={onUploadCustomGLB}
            onScaleMultiplierChange={onScaleMultiplierChange}
            onForwardOffsetChange={onForwardOffsetChange}
            onExportOriginalPMGLB={onExportOriginalPMGLB}
            onExportSimConfig={onExportSimConfig}
          />
        )}

        {activeTab === 'controls' && (
          <>
            {/* Visual Style Mode Selector */}
            <section className="space-y-2">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-semibold text-[#D6D1C7]">Visual Mode</h2>
                <span className="text-xs text-[#8E95A5] font-mono tabular-nums">
                  {config.visualStyle === 'reference'
                    ? 'Reference Match'
                    : config.visualStyle === 'clean'
                    ? 'Clean Geometry'
                    : 'Pixel-Art Detail'}
                </span>
              </div>
              <div className="space-y-1.5">
                {visualModes.map((m) => {
                  const active = config.visualStyle === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => onUpdateConfig({ visualStyle: m.id })}
                      className={`w-full text-left px-3 py-2 rounded-lg border transition-colors ${
                        active
                          ? 'bg-[#262936] border-[#D99252] text-[#F5F2EB]'
                          : 'bg-[#1D1F28] border-[#2A2D3A] text-[#9CA3AF] hover:border-[#3D4254] hover:text-[#E5E0D8]'
                      }`}
                    >
                      <div className="text-xs font-semibold">{m.label}</div>
                      <div className="text-[11px] text-[#8E95A5] leading-snug mt-0.5">{m.desc}</div>
                    </button>
                  );
                })}
              </div>
            </section>

            {/* Scene Layer & Visibility Toggles */}
            <section className="space-y-2 pt-3 border-t border-[#262833]">
              <h2 className="text-xs font-semibold text-[#D6D1C7]">Scene Layers & Helpers</h2>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  {
                    key: 'showBossPM' as const,
                    label: 'Boss PM Character',
                    active: config.showBossPM,
                  },
                  {
                    key: 'showGrid' as const,
                    label: 'Modular Grid (8×8)',
                    active: config.showGrid,
                  },
                  {
                    key: 'autoCutawayWalls' as const,
                    label: 'Auto Cutaway Walls',
                    active: config.autoCutawayWalls,
                  },
                  {
                    key: 'showWallsAndWindows' as const,
                    label: 'Walls & Windows',
                    active: config.showWallsAndWindows,
                  },
                  {
                    key: 'showFurniture' as const,
                    label: 'Furniture Group',
                    active: config.showFurniture,
                  },
                  {
                    key: 'showPropsAndDecor' as const,
                    label: 'Props & Decor',
                    active: config.showPropsAndDecor,
                  },
                  {
                    key: 'showMannequin' as const,
                    label: 'Scale Mannequin',
                    active: config.showMannequin,
                  },
                  {
                    key: 'showTextures' as const,
                    label: 'Pixel Textures',
                    active: config.showTextures,
                  },
                  {
                    key: 'showShadows' as const,
                    label: 'Soft Shadows',
                    active: config.showShadows,
                  },
                  {
                    key: 'showWireframe' as const,
                    label: 'Wireframe Mode',
                    active: config.showWireframe,
                  },
                  {
                    key: 'showSimulationAnchors' as const,
                    label: 'Activity Anchors',
                    active: config.showSimulationAnchors,
                  },
                ].map((toggle) => (
                  <button
                    key={toggle.key}
                    type="button"
                    aria-pressed={toggle.active}
                    onClick={() => onUpdateConfig({ [toggle.key]: !toggle.active })}
                    className={`px-2.5 py-2 rounded-lg border text-xs font-medium flex items-center justify-between transition-colors whitespace-nowrap shrink-0 ${
                      toggle.active
                        ? 'bg-[#252834] border-[#4B5563] text-[#F3EFEA]'
                        : 'bg-[#191B22] border-[#262833] text-[#7D8494] hover:text-[#D1D5DB]'
                    }`}
                  >
                    <span className="truncate">{toggle.label}</span>
                    <span className="text-[11px] font-mono ml-1.5">
                      {toggle.active ? 'ON' : 'OFF'}
                    </span>
                  </button>
                ))}
              </div>
            </section>

            {/* Collapsible Developer Debug Inspection & Visual Stability Mode */}
            <section className="space-y-2 pt-3 border-t border-[#262833]">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-semibold text-[#D6D1C7]">
                  Debug Inspection & Visual Stability
                </h2>
                <button
                  type="button"
                  onClick={() => setShowDebugInspection((v) => !v)}
                  className="text-xs text-[#D99252] hover:underline whitespace-nowrap shrink-0"
                >
                  {showDebugInspection ? 'Collapse' : 'Expand'}
                </button>
              </div>

              {showDebugInspection && (
                <div className="bg-[#14151B] border border-[#262833] rounded-lg p-3 space-y-2.5 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] text-[#8E95A5]">
                      Inspect Selected Mesh & Coplanar Stability
                    </span>
                    <button
                      type="button"
                      onClick={onRunStabilityScan}
                      className="px-2 py-1 rounded bg-[#262936] hover:bg-[#323646] border border-[#D99252]/50 text-[#FBBF24] text-[11px] font-medium whitespace-nowrap shrink-0"
                    >
                      Scan Visual Stability
                    </button>
                  </div>

                  {/* Quick Wireframe & Shadow Diagnostic Toggles */}
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => onUpdateConfig({ showWireframe: !config.showWireframe })}
                      className={`px-2 py-1.5 rounded border text-[11px] font-mono flex items-center justify-between ${
                        config.showWireframe
                          ? 'bg-[#2E3240] border-[#D99252] text-[#F5F2EB]'
                          : 'bg-[#191B22] border-[#262833] text-[#8E95A5]'
                      }`}
                    >
                      <span>Wireframe</span>
                      <span>{config.showWireframe ? 'ON' : 'OFF'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onUpdateConfig({ showShadows: !config.showShadows })}
                      className={`px-2 py-1.5 rounded border text-[11px] font-mono flex items-center justify-between ${
                        config.showShadows
                          ? 'bg-[#2E3240] border-[#6EE7B7] text-[#F5F2EB]'
                          : 'bg-[#191B22] border-[#262833] text-[#8E95A5]'
                      }`}
                    >
                      <span>Shadows</span>
                      <span>{config.showShadows ? 'ON' : 'OFF'}</span>
                    </button>
                  </div>

                  {/* Clicked Mesh & Material Readout */}
                  <div className="p-2 rounded bg-[#1A1C24] border border-[#262833] space-y-1 font-mono text-[11px]">
                    <div className="text-[#D99252] font-semibold">Selected Mesh Readout</div>
                    {clickedMeshDiagnostic ? (
                      <>
                        <div className="flex justify-between gap-2">
                          <span className="text-[#8E95A5]">Mesh Name</span>
                          <span className="text-[#F3EFEA] truncate">
                            {clickedMeshDiagnostic.meshName}
                          </span>
                        </div>
                        <div className="flex justify-between gap-2">
                          <span className="text-[#8E95A5]">Material</span>
                          <span className="text-[#6EE7B7] truncate">
                            {clickedMeshDiagnostic.materialName}
                          </span>
                        </div>
                        <div className="flex justify-between gap-2">
                          <span className="text-[#8E95A5]">Material Type</span>
                          <span className="text-[#7DD3FC]">
                            {clickedMeshDiagnostic.materialType}
                          </span>
                        </div>
                        <div className="flex justify-between gap-2">
                          <span className="text-[#8E95A5]">Parent Group</span>
                          <span className="text-[#D6D1C7] truncate">
                            {clickedMeshDiagnostic.parentName}
                          </span>
                        </div>
                      </>
                    ) : (
                      <div className="text-[#8E95A5] font-sans">
                        Click any surface on the Boss PM character, cabinets, walls, or props to inspect its exact sub-mesh name and material type.
                      </div>
                    )}
                  </div>

                  {/* Stability Audit Report */}
                  {stabilityReport && (
                    <div className="pt-2 border-t border-[#262833] space-y-1.5 font-mono text-[11px]">
                      <div className="flex items-center justify-between text-[#6EE7B7] font-semibold">
                        <span>Zero Coplanar / Z-Fight Conflicts</span>
                        <span>{stabilityReport.timestamp}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#8E95A5]">Room / PM Meshes</span>
                        <span className="text-[#F3EFEA]">
                          {stabilityReport.totalRoomMeshes} / {stabilityReport.totalCharacterMeshes}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#8E95A5]">Duplicate Mesh Refs</span>
                        <span className="text-[#6EE7B7]">
                          {stabilityReport.duplicateRoomMeshNames.length +
                            stabilityReport.duplicateCharacterMeshNames.length}{' '}
                          (Clean)
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#8E95A5]">Camera Near / Far</span>
                        <span className="text-[#F3EFEA]">
                          [{stabilityReport.cameraNearFar[0]}u .. {stabilityReport.cameraNearFar[1]}u]
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#8E95A5]">Shadow Bias / Normal</span>
                        <span className="text-[#F3EFEA]">
                          {stabilityReport.shadowBias} / {stabilityReport.shadowNormalBias}
                        </span>
                      </div>
                      <div className="pt-1 space-y-1 font-sans">
                        {stabilityReport.verifiedAreas.map((v, idx) => (
                          <div
                            key={idx}
                            className="p-1.5 rounded bg-[#181A22] border border-[#262833] text-[10px]"
                          >
                            <div className="flex items-center justify-between font-semibold text-[#A7F3D0]">
                              <span>{v.area}</span>
                              <span className="font-mono">{v.status}</span>
                            </div>
                            <div className="text-[#9CA3AF] mt-0.5 leading-snug">{v.detail}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </section>

            {/* Modular Room Standard Specification Readout */}
            <section className="space-y-2 pt-3 border-t border-[#262833]">
              <h2 className="text-xs font-semibold text-[#D6D1C7]">Modular Block Specification</h2>
              <div className="bg-[#14151B] border border-[#262833] rounded-lg p-3 space-y-2 text-xs font-mono tabular-nums">
                <div className="flex justify-between">
                  <span className="text-[#8E95A5]">Root Node</span>
                  <span className="text-[#F3EFEA]">{MODULE_CONSTANTS.ROOT_NODE_NAME}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8E95A5]">SW Origin</span>
                  <span className="text-[#F3EFEA]">[0.0, 0.0, 0.0]</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8E95A5]">Footprint Bounds</span>
                  <span className="text-[#F3EFEA]">X: 0..8 · Z: 0..8</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8E95A5]">Wall / Floor Y</span>
                  <span className="text-[#F3EFEA]">3.20u / -0.16u</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8E95A5]">Connector A (East)</span>
                  <span className="text-[#7DD3FC]">[8, 0, 4] · +X · 2u</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8E95A5]">Connector B (South)</span>
                  <span className="text-[#6EE7B7]">[4, 0, 0] · -Z · 2u</span>
                </div>
                {stats && (
                  <div className="pt-1.5 border-t border-[#262833] flex justify-between text-[#D99252]">
                    <span>Room Geometry</span>
                    <span>
                      {stats.meshCount} meshes · {stats.triangleCount.toLocaleString()} tris
                    </span>
                  </div>
                )}
              </div>
            </section>

            {/* Authoritative Reference Image Comparison */}
            <section className="space-y-2 pt-3 border-t border-[#262833]">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-semibold text-[#D6D1C7]">Art Direction Reference</h2>
                <button
                  type="button"
                  onClick={() => setShowRefImage((v) => !v)}
                  className="text-xs text-[#D99252] hover:underline whitespace-nowrap shrink-0"
                >
                  {showRefImage ? 'Hide Reference' : 'Show Reference'}
                </button>
              </div>
              {showRefImage && (
                <div className="bg-[#14151B] border border-[#262833] rounded-lg overflow-hidden">
                  <img
                    src="/assets/aistudio/Screenshot_2026-10-28_024156_e1b906a9.png"
                    alt="Approved Isometric Pixel-Art Room Reference"
                    referrerPolicy="no-referrer"
                    className="w-full h-38 object-cover"
                  />
                  <div className="px-2.5 py-1.5 text-[11px] text-[#8E95A5]">
                    Target Style: Premium Cozy Isometric Pixel-Art 3D · Translated to PM & Strategy Office
                  </div>
                </div>
              )}
            </section>
          </>
        )}

        {activeTab === 'assets' && (
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-semibold text-[#D6D1C7]">
                Room Asset Inspector ({FURNITURE_CATALOG.length})
              </h2>
              {(config.isolatedCatalogId || config.hiddenCatalogIds.length > 0) && (
                <button
                  type="button"
                  onClick={() =>
                    onUpdateConfig({
                      isolatedCatalogId: null,
                      hiddenCatalogIds: [],
                      selectedCatalogId: null,
                    })
                  }
                  className="text-xs text-[#D99252] hover:underline whitespace-nowrap shrink-0"
                >
                  Reset Visibility
                </button>
              )}
            </div>

            {selectedDetails ? (
              <div className="bg-[#14151B] border border-[#D99252]/60 rounded-lg p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-xs font-semibold text-[#F5F2EB]">
                      {selectedDetails.catalogItem.name}
                    </div>
                    <div className="text-[11px] text-[#8E95A5] mt-0.5">
                      {selectedDetails.catalogItem.category} · {selectedDetails.catalogItem.area}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSelectCatalogItem(null)}
                    className="text-xs text-[#9CA3AF] hover:text-white px-1.5 py-0.5"
                  >
                    Clear
                  </button>
                </div>
                <p className="text-xs text-[#B4BAC6] leading-relaxed">
                  {selectedDetails.catalogItem.description}
                </p>
                <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-[#262833] text-[11px] font-mono tabular-nums">
                  <div>
                    <span className="text-[#8E95A5] block">Local Position</span>
                    <span className="text-[#F3EFEA]">
                      [{selectedDetails.catalogItem.position.join(', ')}]
                    </span>
                  </div>
                  <div>
                    <span className="text-[#8E95A5] block">Measured Size</span>
                    <span className="text-[#F3EFEA]">
                      {selectedDetails.worldBox.size.join(' × ')}u
                    </span>
                  </div>
                  <div>
                    <span className="text-[#8E95A5] block">Sub-Meshes</span>
                    <span className="text-[#F3EFEA]">{selectedDetails.meshCount} parts</span>
                  </div>
                  <div>
                    <span className="text-[#8E95A5] block">Polygon Count</span>
                    <span className="text-[#F3EFEA]">{selectedDetails.triangleCount} tris</span>
                  </div>
                </div>
                <div className="text-[11px] text-[#8E95A5] pt-1">
                  Materials: <span className="text-[#D6D1C7]">{selectedDetails.catalogItem.materialSummary}</span>
                </div>
                {selectedDetails.clickedMeshName && (
                  <div className="text-[11px] text-[#8E95A5] font-mono pt-0.5">
                    Clicked Sub-Mesh:{' '}
                    <span className="text-[#6EE7B7]">{selectedDetails.clickedMeshName}</span> (
                    <span className="text-[#7DD3FC]">{selectedDetails.clickedMaterialType}</span>)
                  </div>
                )}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => toggleIsolateCatalogItem(selectedDetails.catalogItem.id)}
                    className={`flex-1 py-1.5 px-2.5 rounded-md text-xs font-medium border transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
                      config.isolatedCatalogId === selectedDetails.catalogItem.id
                        ? 'bg-[#D99252] text-[#14151B] border-[#D99252]'
                        : 'bg-[#1F222D] text-[#E5E0D8] border-[#323646] hover:border-[#4B5563]'
                    }`}
                  >
                    <Focus className="w-3.5 h-3.5" />
                    <span>
                      {config.isolatedCatalogId === selectedDetails.catalogItem.id
                        ? 'Un-Isolate'
                        : 'Isolate Asset'}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleCatalogItemHidden(selectedDetails.catalogItem.id)}
                    className="py-1.5 px-2.5 rounded-md text-xs font-medium bg-[#1F222D] text-[#E5E0D8] border border-[#323646] hover:border-[#4B5563] whitespace-nowrap shrink-0 flex items-center gap-1.5"
                  >
                    {config.hiddenCatalogIds.includes(selectedDetails.catalogItem.id) ? (
                      <>
                        <Eye className="w-3.5 h-3.5" />
                        <span>Show</span>
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>Hide</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-[#14151B] border border-[#262833] rounded-lg p-3 text-xs text-[#8E95A5]">
                Click any furniture object in the 3D room or select an item below to inspect its position, scale, material, and polygon count.
              </div>
            )}

            <div className="space-y-1.5">
              {FURNITURE_CATALOG.map((item) => {
                const isSelected = config.selectedCatalogId === item.id;
                const isHidden = config.hiddenCatalogIds.includes(item.id);
                const isIsolated = config.isolatedCatalogId === item.id;
                return (
                  <div
                    key={item.id}
                    className={`flex items-center justify-between gap-2 px-2.5 py-2 rounded-lg border transition-colors ${
                      isSelected
                        ? 'bg-[#262936] border-[#D99252]'
                        : 'bg-[#1B1D26] border-[#262833] hover:border-[#3A3E50]'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => onSelectCatalogItem(item.id)}
                      className="flex-1 text-left min-w-0"
                    >
                      <div className="text-xs font-medium text-[#F3EFEA] truncate">
                        {item.name}
                      </div>
                      <div className="text-[11px] text-[#8E95A5] truncate">
                        {item.area} · [{item.position.join(', ')}]
                      </div>
                    </button>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        aria-label={`Isolate ${item.name}`}
                        onClick={() => toggleIsolateCatalogItem(item.id)}
                        className={`p-1.5 rounded-md border text-xs transition-colors ${
                          isIsolated
                            ? 'bg-[#D99252] text-[#14151B] border-[#D99252]'
                            : 'bg-[#14151B] text-[#8E95A5] border-[#2A2D3A] hover:text-white'
                        }`}
                      >
                        <Focus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label={isHidden ? `Show ${item.name}` : `Hide ${item.name}`}
                        onClick={() => toggleCatalogItemHidden(item.id)}
                        className={`p-1.5 rounded-md border text-xs transition-colors ${
                          isHidden
                            ? 'bg-[#372228] text-[#FCA5A5] border-[#7F1D1D]'
                            : 'bg-[#14151B] text-[#8E95A5] border-[#2A2D3A] hover:text-white'
                        }`}
                      >
                        {isHidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {activeTab === 'validation' && (
          <section className="space-y-3">
            {/* Section 12: Asset Export & Integration Handoff */}
            <div className="bg-[#14151B] border border-[#D99252]/70 rounded-lg overflow-hidden">
              <button
                type="button"
                onClick={() => setShowHandoffSection((v) => !v)}
                className="w-full px-3 py-2.5 flex items-center justify-between text-left hover:bg-[#1B1D26] transition-colors"
              >
                <span className="text-xs font-semibold text-[#F5F2EB] flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#D99252]" />
                  <span>Asset Export & Integration Handoff</span>
                </span>
                {showHandoffSection ? (
                  <ChevronDown className="w-4 h-4 text-[#8E95A5]" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-[#8E95A5]" />
                )}
              </button>

              {showHandoffSection && (
                <div className="p-3 pt-2 border-t border-[#262833] space-y-2 text-xs">
                  <div className="text-[11px] text-[#9CA3AF] leading-snug">
                    Deliverable A (PM Room), Deliverable B (Room-Native Boss PM Candidate), & Deliverable C (Full Source Project).
                  </div>

                  {/* Primary Handoff Controls required by Section 12 */}
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={onExportGLB}
                      className="px-2.5 py-2 rounded-md bg-[#262936] hover:bg-[#313546] border border-[#D99252]/50 text-[#F5F2EB] text-[11px] font-medium flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <Download className="w-3.5 h-3.5 text-[#D99252] shrink-0" />
                      <span>Export PM Room GLB</span>
                    </button>
                    <button
                      type="button"
                      onClick={onExportRoomManifestAndAnchors}
                      className="px-2.5 py-2 rounded-md bg-[#1D1F28] hover:bg-[#282B38] border border-[#2E3242] text-[#E5E0D8] text-[11px] font-medium flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <FileCode2 className="w-3.5 h-3.5 text-[#7DD3FC] shrink-0" />
                      <span>Manifest + Anchors</span>
                    </button>
                    <button
                      type="button"
                      onClick={onExportOriginalPMGLB}
                      className="px-2.5 py-2 rounded-md bg-[#262936] hover:bg-[#313546] border border-[#38BDF8]/50 text-[#F5F2EB] text-[11px] font-medium flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <Download className="w-3.5 h-3.5 text-[#38BDF8] shrink-0" />
                      <span>Export Boss PM GLB</span>
                    </button>
                    <button
                      type="button"
                      onClick={onExportCharacterManifestAndBehavior}
                      className="px-2.5 py-2 rounded-md bg-[#1D1F28] hover:bg-[#282B38] border border-[#2E3242] text-[#E5E0D8] text-[11px] font-medium flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <FileCode2 className="w-3.5 h-3.5 text-[#6EE7B7] shrink-0" />
                      <span>PM Manifest + Behavior</span>
                    </button>
                    <button
                      type="button"
                      onClick={onExportPNG}
                      className="px-2.5 py-2 rounded-md bg-[#1D1F28] hover:bg-[#282B38] border border-[#2E3242] text-[#E5E0D8] text-[11px] font-medium flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <ImageIcon className="w-3.5 h-3.5 text-[#FBBF24] shrink-0" />
                      <span>Export Preview PNG</span>
                    </button>
                    <button
                      type="button"
                      onClick={onExportCharacterPNG}
                      className="px-2.5 py-2 rounded-md bg-[#1D1F28] hover:bg-[#282B38] border border-[#2E3242] text-[#E5E0D8] text-[11px] font-medium flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <ImageIcon className="w-3.5 h-3.5 text-[#A78BFA] shrink-0" />
                      <span>Export PM Preview PNG</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={onRunImportTest}
                      className="px-2.5 py-2 rounded-md bg-[#D99252] hover:bg-[#E49F60] text-[#14151B] text-[11px] font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <PackageCheck className="w-3.5 h-3.5 shrink-0" />
                      <span>Validate Exported GLB</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowValidationMatrix((v) => !v)}
                      className="px-2.5 py-2 rounded-md bg-[#1E293B] hover:bg-[#334155] border border-[#38BDF8]/40 text-[#7DD3FC] text-[11px] font-medium flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      <span>
                        {showValidationMatrix ? 'Hide Validation Report' : 'Show Validation Report'}
                      </span>
                    </button>
                  </div>

                  {/* Packaged ZIP Archives (Deliverables A, B, C & Full Handoff Bundle) */}
                  <div className="pt-2 border-t border-[#262833] space-y-1.5">
                    <div className="text-[10px] font-mono uppercase text-[#8E95A5]">
                      Production Asset Packs & Full Source (.ZIP)
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        onClick={onDownloadRoomPackZip}
                        className="px-2 py-1.5 rounded bg-[#1B1E28] hover:bg-[#252A38] border border-[#2F3446] text-[#E5E0D8] text-[11px] flex items-center justify-center gap-1 whitespace-nowrap"
                      >
                        <Archive className="w-3 h-3 text-[#D99252] shrink-0" />
                        <span>Deliverable A (.zip)</span>
                      </button>
                      <button
                        type="button"
                        onClick={onDownloadCharacterPackZip}
                        className="px-2 py-1.5 rounded bg-[#1B1E28] hover:bg-[#252A38] border border-[#2F3446] text-[#E5E0D8] text-[11px] flex items-center justify-center gap-1 whitespace-nowrap"
                      >
                        <Archive className="w-3 h-3 text-[#38BDF8] shrink-0" />
                        <span>Deliverable B (.zip)</span>
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={onDownloadSourceZip}
                      className="w-full py-1.5 px-2.5 rounded bg-[#1B1E28] hover:bg-[#252A38] border border-[#6EE7B7]/40 text-[#A7F3D0] text-[11px] font-medium flex items-center justify-center gap-1.5"
                    >
                      <Archive className="w-3.5 h-3.5 text-[#6EE7B7] shrink-0" />
                      <span>Deliverable C: modular-room-lab-source.zip</span>
                    </button>
                    <button
                      type="button"
                      onClick={onDownloadCompleteHandoffZip}
                      className="w-full py-2 px-3 rounded-md bg-[#10B981] hover:bg-[#059669] text-[#0B1310] text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <Archive className="w-3.5 h-3.5 shrink-0" />
                      <span>Download AI-OFFICE-PM-ROOM-HANDOFF-V1.zip</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Scene Source & Independent Re-Import Target Switcher */}
            <div className="p-2.5 rounded-lg bg-[#14151B] border border-[#262833] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#D6D1C7] font-medium">Viewer Scene Source</span>
                <span className="text-xs font-mono text-[#6EE7B7]">
                  {config.workspaceMode === 'import_test' ? 'Loaded from .GLB' : 'Live Builder'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => onUpdateConfig({ workspaceMode: 'builder' })}
                  className={`py-1.5 px-2 rounded-md text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                    config.workspaceMode === 'builder'
                      ? 'bg-[#2E3240] text-white border-[#4B5563]'
                      : 'bg-[#1A1C24] text-[#8E95A5] border-[#262833]'
                  }`}
                >
                  Builder Scene
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onUpdateConfig({ workspaceMode: 'import_test' });
                    if (!roundTripReport) onRunImportTest();
                  }}
                  className={`py-1.5 px-2 rounded-md text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                    config.workspaceMode === 'import_test'
                      ? 'bg-[#2E3240] text-white border-[#6EE7B7]'
                      : 'bg-[#1A1C24] text-[#8E95A5] border-[#262833]'
                  }`}
                >
                  Test Exported GLB
                </button>
              </div>

              {config.workspaceMode === 'import_test' && (
                <div className="pt-1 space-y-1">
                  <div className="text-[10px] font-mono text-[#8E95A5]">
                    Re-Imported GLB Inspection Target:
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    {(
                      [
                        { id: 'both_reimported', label: 'Room + PM' },
                        { id: 'room_only', label: 'Room Only' },
                        { id: 'character_only', label: 'PM Only' },
                      ] as const
                    ).map((opt) => {
                      const cur = config.importTestTarget || 'both_reimported';
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => onUpdateConfig({ importTestTarget: opt.id })}
                          className={`py-1 px-1.5 rounded text-[10px] font-medium border ${
                            cur === opt.id
                              ? 'bg-[#262936] border-[#D99252] text-[#F5F2EB]'
                              : 'bg-[#181A22] border-[#262833] text-[#8E95A5]'
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <button
                type="button"
                onClick={() => {
                  const next = !config.showNeighborAssembly;
                  onUpdateConfig({
                    workspaceMode: 'import_test',
                    showNeighborAssembly: next,
                  });
                  setTimeout(onFitRoom, 60);
                }}
                className={`w-full py-2 px-2.5 rounded-md text-xs font-medium border flex items-center justify-between transition-colors ${
                  config.showNeighborAssembly && config.workspaceMode === 'import_test'
                    ? 'bg-[#1E3A34] border-[#34D399] text-[#A7F3D0]'
                    : 'bg-[#1A1C24] border-[#2B2F3C] text-[#9CA3AF] hover:text-white'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5" />
                  <span>Neighbor Module Snap Proof</span>
                </span>
                <span className="font-mono text-[11px]">
                  {config.showNeighborAssembly && config.workspaceMode === 'import_test'
                    ? 'ACTIVE'
                    : 'OFF'}
                </span>
              </button>
            </div>

            {/* 19-Row Required Validation Matrix & Round-Trip Reports */}
            {showValidationMatrix && roundTripReport && (
              <div className="bg-[#14151B] border border-[#34D399]/60 rounded-lg p-3 space-y-2.5 text-xs">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[#6EE7B7] font-semibold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>
                      Validation Matrix ({roundTripReport.overall_status})
                    </span>
                  </span>
                  <button
                    type="button"
                    onClick={onDownloadRoundTripReport}
                    className="px-2 py-0.5 rounded bg-[#1E293B] hover:bg-[#334155] text-[#7DD3FC] text-[10px] font-mono"
                  >
                    roundtrip-report.json
                  </button>
                </div>

                {/* Boss PM Character GLB Round-Trip Summary */}
                <div className="p-2 rounded bg-[#191B22] border border-[#262833] space-y-1 font-mono text-[11px]">
                  <div className="text-[#38BDF8] font-semibold">
                    Character GLB Round-Trip ({roundTripReport.character_roundtrip.filename})
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Binary / SHA-256</span>
                    <span className="text-[#F3EFEA]">
                      {roundTripReport.character_roundtrip.fileSizeKB} ·{' '}
                      {roundTripReport.character_roundtrip.sha256.slice(0, 10)}…
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Source / Exported Meshes</span>
                    <span className="text-[#F3EFEA]">
                      {roundTripReport.character_roundtrip.sourceTotalMeshes} /{' '}
                      {roundTripReport.character_roundtrip.importedMeshCount} rest-pose
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Embedded Clips in GLB</span>
                    <span className="text-[#6EE7B7]">
                      {roundTripReport.character_roundtrip.embeddedClipsVerified.count} / 11 VERIFIED
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Bounds / Feet Y</span>
                    <span className="text-[#F3EFEA]">
                      H={roundTripReport.character_roundtrip.boundingBox.size[1]}u · minY=
                      {roundTripReport.character_roundtrip.boundingBox.min[1]}
                    </span>
                  </div>
                </div>

                {/* 19-Point Validation Matrix Rows */}
                <div className="space-y-1 max-h-72 overflow-y-auto pr-1">
                  {roundTripReport.validation_matrix.map((row) => (
                    <div
                      key={row.id}
                      className="p-2 rounded bg-[#181A22] border border-[#262833] space-y-0.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-[#E5E0D8] text-[11px]">
                          {row.area}
                        </span>
                        <span
                          className={`px-1.5 py-0.5 rounded font-mono text-[10px] font-semibold ${
                            row.status === 'PASS'
                              ? 'bg-[#064E3B] text-[#6EE7B7]'
                              : row.status === 'FAIL'
                              ? 'bg-[#7F1D1D] text-[#FCA5A5]'
                              : 'bg-[#374151] text-[#FDE68A]'
                          }`}
                        >
                          {row.status}
                        </span>
                      </div>
                      <div className="text-[10px] font-mono text-[#7DD3FC]">
                        {row.measured_result}
                      </div>
                      <div className="text-[10px] text-[#9CA3AF] leading-snug">{row.details}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Room GLB Round-Trip Summary Card */}
            {importReport ? (
              <div className="bg-[#14151B] border border-[#262833] rounded-lg p-3 space-y-2.5 text-xs">
                <div className="flex items-center gap-2 text-[#6EE7B7] font-semibold">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Room GLB Round-Trip Verified ({importReport.fileSizeKB})</span>
                </div>

                <div className="space-y-1.5 font-mono tabular-nums text-[11px] pt-1 border-t border-[#262833]">
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Asset File</span>
                    <span className="text-[#F3EFEA]">{PRODUCTION_FILENAMES.ROOM_GLB}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Binary Size</span>
                    <span className="text-[#F3EFEA]">
                      {importReport.fileSizeKB} ({importReport.fileSizeBytes.toLocaleString()} B)
                    </span>
                  </div>
                  {roundTripReport && (
                    <div className="flex justify-between">
                      <span className="text-[#8E95A5]">SHA-256</span>
                      <span className="text-[#7DD3FC]">
                        {roundTripReport.room_roundtrip.sha256.slice(0, 16)}…
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Imported Meshes</span>
                    <span className="text-[#F3EFEA]">{importReport.meshCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Imported Materials</span>
                    <span className="text-[#F3EFEA]">{importReport.materialCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Triangles</span>
                    <span className="text-[#F3EFEA]">{importReport.triangleCount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Textures Survived</span>
                    <span className="text-[#6EE7B7]">
                      Yes ({importReport.embeddedTexturesCount} embedded)
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Bounds Min</span>
                    <span className="text-[#F3EFEA]">[{importReport.boundingBox.min.join(', ')}]</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Bounds Max</span>
                    <span className="text-[#F3EFEA]">[{importReport.boundingBox.max.join(', ')}]</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Connectors Valid</span>
                    <span className="text-[#6EE7B7]">
                      {importReport.connectorsVerified.alignmentValid ? 'East [8,0,4] · South [4,0,0]' : 'Check'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8E95A5]">Preview / Agent Excluded</span>
                    <span className="text-[#6EE7B7]">
                      {importReport.previewObjectsExcluded ? 'Verified Room-Only' : 'Failed'}
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-[#262833] space-y-1">
                  <div className="text-[11px] font-semibold text-[#D6D1C7]">Diagnostic Log</div>
                  {importReport.diagnostics.map((d, i) => (
                    <div key={i} className="text-[11px] text-[#9CA3AF] leading-snug">
                      · {d}
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-[#14151B] border border-[#262833] rounded-lg p-3 text-xs text-[#8E95A5]">
                Click "Validate Exported GLB" above to serialize both pm_room.glb and boss_pm.glb with GLTFExporter and parse their binary ArrayBuffers back through an independent GLTFLoader.
              </div>
            )}
          </section>
        )}

        {activeTab === 'manifest' && manifestPreview && (
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-semibold text-[#D6D1C7]">
                Handoff JSON Manifests & Anchors
              </h2>
              <button
                type="button"
                onClick={onExportRoomManifestAndAnchors}
                className="px-2.5 py-1 rounded-md text-xs font-medium bg-[#2E3240] text-[#F3EFEA] hover:bg-[#3B4052] transition-colors whitespace-nowrap shrink-0"
              >
                Download JSONs
              </button>
            </div>

            <div className="grid grid-cols-3 gap-1 bg-[#14151B] p-1 rounded-lg border border-[#262833]">
              {(
                [
                  { id: 'room_manifest', label: 'pm_room.manifest' },
                  { id: 'room_anchors', label: 'pm_room.anchors' },
                  { id: 'roundtrip', label: 'roundtrip-report' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setManifestDocTab(tab.id)}
                  className={`py-1 px-1.5 rounded text-[10px] font-mono transition-colors truncate ${
                    manifestDocTab === tab.id
                      ? 'bg-[#D99252] text-[#14151B] font-semibold'
                      : 'text-[#8E95A5] hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <pre className="bg-[#121318] border border-[#262833] rounded-lg p-2.5 text-[11px] font-mono text-[#D6D1C7] overflow-x-auto max-h-96 leading-relaxed">
              {manifestDocTab === 'room_manifest'
                ? JSON.stringify(manifestPreview, null, 2)
                : manifestDocTab === 'room_anchors'
                ? JSON.stringify(buildPMRoomAnchorsJsonV1(anchors), null, 2)
                : JSON.stringify(
                    roundTripReport || {
                      note: 'Click "Validate Exported GLB" in the GLB Test tab to generate the full roundtrip-report.json.',
                    },
                    null,
                    2
                  )}
            </pre>
          </section>
        )}
      </div>

      {/* Bottom Pipeline Export Actions Footer */}
      <div className="p-3 border-t border-[#2B2D38] bg-[#14151B] space-y-2">
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={onExportRoomManifestAndAnchors}
            className="px-2.5 py-1.5 rounded-lg text-[11px] font-medium bg-[#222530] hover:bg-[#2C303E] text-[#E5E0D8] border border-[#323646] transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5"
          >
            <FileCode2 className="w-3.5 h-3.5 text-[#7DD3FC]" />
            <span>Room Manifest+Anchors</span>
          </button>
          <button
            type="button"
            onClick={onExportPNG}
            className="px-2.5 py-1.5 rounded-lg text-[11px] font-medium bg-[#222530] hover:bg-[#2C303E] text-[#E5E0D8] border border-[#323646] transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5"
          >
            <ImageIcon className="w-3.5 h-3.5 text-[#FBBF24]" />
            <span>Export Preview PNG</span>
          </button>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={onExportGLB}
            className="py-2 px-2.5 rounded-lg text-[11px] font-semibold bg-[#D99252] hover:bg-[#E49F60] text-[#14151B] transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 shadow-xs"
          >
            <PackageCheck className="w-3.5 h-3.5 shrink-0" />
            <span>Export pm_room.glb</span>
          </button>
          <button
            type="button"
            onClick={onExportOriginalPMGLB}
            className="py-2 px-2.5 rounded-lg text-[11px] font-semibold bg-[#38BDF8] hover:bg-[#7DD3FC] text-[#14151B] transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 shadow-xs"
          >
            <Download className="w-3.5 h-3.5 shrink-0" />
            <span>Export boss_pm.glb</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
